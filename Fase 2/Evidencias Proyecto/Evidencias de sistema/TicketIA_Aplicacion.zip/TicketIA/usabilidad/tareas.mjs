// Prueba de tareas de usabilidad: ejecuta las tareas principales de cada rol y mide pasos, tiempo y éxito.
// Uso: BASE_URL=http://127.0.0.1:5000 node usabilidad/tareas.mjs   (con la aplicación en marcha y datos de demostración)
import fs from 'fs'; import path from 'path';
const BASE = process.env.BASE_URL || 'http://127.0.0.1:5000';
const SALIDA = process.env.SALIDA || 'usabilidad/resultados/tareas.json';
async function abrirNavegador() {
  try { const p = await import('puppeteer'); return await p.default.launch({ headless: 'shell', args: ['--no-sandbox'] }); }
  catch (e) { const p = (await import('puppeteer-core')).default; const c = (await import('@sparticuz/chromium')).default;
    return await p.launch({ args: [...c.args.filter(a => !['--single-process', '--no-zygote'].includes(a)), '--no-sandbox'], executablePath: await c.executablePath(), headless: 'shell' }); }
}
const navegador = await abrirNavegador();
const resultados = [];
async function tarea(rol, nombre, cuenta, ejecutar, esperado) {
  const ctx = await navegador.createBrowserContext(); const page = await ctx.newPage(); await page.setViewport({ width: 1280, height: 800 });
  let pasos = 0; const paso = () => { pasos++; };
  const ir = async r => { await page.goto(BASE + r, { waitUntil: 'networkidle0' }); };
  const clic = async (sel) => { paso(); await Promise.all([page.waitForNavigation({ waitUntil: 'networkidle0' }), page.click(sel)]); };
  const escribir = async (sel, txt) => { paso(); await page.type(sel, txt); };
  const elegir = async (sel, valorTexto) => { paso(); await page.evaluate((s, t) => { const e = document.querySelector(s); const o = [...e.options].find(x => x.text.includes(t)); e.value = o.value; e.dispatchEvent(new Event('change')); }, sel, valorTexto); };
  // inicio de sesión (no cuenta como parte de la tarea)
  await ir('/login'); await page.type('input[name=email]', cuenta[0]); await page.type('input[name=password]', cuenta[1]);
  await Promise.all([page.waitForNavigation({ waitUntil: 'networkidle0' }), page.click('button[type=submit]')]);
  const t0 = Date.now(); let exito = false, error = null;
  try { await ejecutar({ ir, clic, escribir, elegir, page }); exito = (await page.content()).includes(esperado); } catch (e) { error = String(e).slice(0, 120); }
  resultados.push({ rol, tarea: nombre, pasos, segundos: +((Date.now() - t0) / 1000).toFixed(1), exito, error });
  await ctx.close();
}
await tarea('Funcionario', 'Crear una solicitud de soporte', ['pedro.funcionario@municipalidad.cl', 'usuario123'], async ({ clic, escribir, page }) => {
  await clic('a[href$="/tickets/nuevo"]'); await escribir('#campo_titulo', 'La impresora no imprime'); await escribir('#campo_descripcion', 'Aparece un error de papel atascado.'); await clic('form button[type=submit]');
}, 'Ticket creado correctamente');
await tarea('Funcionario', 'Ver el detalle de una solicitud', ['pedro.funcionario@municipalidad.cl', 'usuario123'], async ({ clic }) => { await clic('a[href*="/tickets/"]'); }, 'Descripción');
await tarea('Administrador', 'Asignar un técnico a un ticket', ['jade.admin@municipalidad.cl', 'admin123'], async ({ clic, elegir, ir }) => {
  await ir('/tickets/3'); await elegir('form[action$="/asignar"] select', 'Kiara'); await clic('form[action$="/asignar"] button[type=submit]'); }, 'Ticket asignado');
await tarea('Administrador', 'Crear un usuario', ['jade.admin@municipalidad.cl', 'admin123'], async ({ clic, escribir, elegir, ir }) => {
  await ir('/admin/usuarios'); await clic('a[href$="/admin/usuarios/nuevo"]'); await escribir('#campo_nombre', 'Carlos Mena'); await escribir('#campo_email', 'carlos.mena@municipalidad.cl');
  await elegir('#campo_rol', 'Técnico'); await escribir('#campo_password', 'clave123'); await clic('form button[type=submit]'); }, 'Usuario creado correctamente');
await tarea('Administrador', 'Crear una categoría', ['jade.admin@municipalidad.cl', 'admin123'], async ({ clic, escribir, ir }) => {
  await ir('/admin/categorias'); await clic('a[href$="/admin/categorias/nueva"]'); await escribir('#campo_nombre', 'Impresoras'); await clic('form button[type=submit]'); }, 'Categoría creada correctamente');
await tarea('Técnico', 'Registrar la solución y resolver un ticket', ['kiara.tecnico@municipalidad.cl', 'tecnico123'], async ({ clic, escribir, elegir, ir, page }) => {
  await ir('/tickets/1'); await elegir('#selectEstado', 'En revisión'); await clic('#formEstado button[type=submit]');
  await escribir('form[action$="/solucion"] textarea', 'Se reemplazó el rodillo de la impresora.'); await clic('form[action$="/solucion"] button[type=submit]');
  await elegir('#selectEstado', 'Resuelto'); await clic('#formEstado button[type=submit]'); }, 'Estado actualizado');
await navegador.close();
fs.mkdirSync(path.dirname(SALIDA), { recursive: true }); fs.writeFileSync(SALIDA, JSON.stringify(resultados, null, 1));
for (const r of resultados) console.log(`${r.rol.padEnd(13)} ${r.tarea.padEnd(44)} pasos=${r.pasos} tiempo=${r.segundos}s éxito=${r.exito}${r.error ? ' error=' + r.error : ''}`);
