# Pruebas de usabilidad y accesibilidad de TicketIA

**Tipo de prueba:** accesibilidad (WCAG 2.1 niveles A y AA), diseño adaptable a teléfonos y tareas principales de cada rol.
**Herramientas:** [axe-core](https://github.com/dequelabs/axe-core) y un navegador automatizado (Puppeteer).

## Contenido
- `preparar_datos_demo.py`: crea la base `ticketia_usabilidad` con los usuarios de demostración y 3 tickets de ejemplo.
- `accesibilidad.mjs`: revisa 16 pantallas de los 4 perfiles con axe-core y comprueba que no haya desplazamiento horizontal en 375 px.
- `tareas.mjs`: ejecuta las 6 tareas principales y mide pasos, tiempo y éxito.
- `resultados/`: JSON de la medición inicial (`accesibilidad_antes.json`), la final (`accesibilidad_despues.json`) y las tareas (`tareas.json`).

## Cómo ejecutarlas (Windows, PowerShell; con el entorno virtual activado y PostgreSQL en marcha)
1. Instalar las herramientas (una sola vez): `cd usabilidad` · `npm install` · `cd ..`
2. Preparar los datos: `python usabilidad\preparar_datos_demo.py` (no toca tu base de desarrollo).
3. Iniciar la aplicación con esa base, en una terminal aparte: `$env:DB_NAME="ticketia_usabilidad"; python app.py`
4. En otra terminal, desde la carpeta del proyecto:
   ```powershell
   $env:BASE_URL="http://127.0.0.1:5000"
   node usabilidad\accesibilidad.mjs
   node usabilidad\tareas.mjs
   ```
En Linux o Mac: `DB_NAME=ticketia_usabilidad python app.py` y `BASE_URL=http://127.0.0.1:5000 node usabilidad/accesibilidad.mjs`.

> `accesibilidad.mjs` solo lee. `tareas.mjs` crea registros (un usuario, una categoría y un ticket): si lo repites,
> vuelve a ejecutar antes `preparar_datos_demo.py` y reinicia la aplicación.
> Cada ejecución guarda su resultado en `usabilidad/resultados/accesibilidad.json` y `tareas.json`.

## Resultado de referencia
Antes de corregir: 19 violaciones de accesibilidad y 5 pantallas que se desbordaban en un teléfono.
Después: 0 violaciones y 0 desbordes. Las 6 tareas se completaron en 1 a 6 pasos.
Informe completo: `docs/pruebas/Informe_Pruebas_de_Usabilidad_y_Accesibilidad_TicketIA.docx`.

## Revisión en un navegador real (Sprint 4)
`accesibilidad_navegador.py` revisa 12 pantallas con los tres roles, en escritorio (1280 px) y en celular (375 px), con Chromium y axe-core (WCAG 2.1 A y AA), y comprueba que no haya desborde horizontal.

1. Instalar (una vez): `pip install playwright`, `playwright install chromium` y `npm install axe-core`.
2. Cargar tickets de ejemplo en la base: `python usabilidad/preparar_datos_sprint4.py` (borra los tickets de esa base).
3. Iniciar el sistema con `MOSTRAR_CUENTAS_DEMO=1` y `SESSION_COOKIE_SECURE=0`, y ejecutar: `python usabilidad/accesibilidad_navegador.py --url http://127.0.0.1:5000`.

El resultado queda en `usabilidad/resultados/sprint4_accesibilidad.json`.
Resultado de referencia del Sprint 4: antes de corregir, 16 violaciones en 18 vistas (5 problemas distintos); después, 0 violaciones en 24 vistas y 0 desbordes.
