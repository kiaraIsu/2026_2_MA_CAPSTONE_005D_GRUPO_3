// Pruebas de accesibilidad (WCAG 2.1 A y AA) y de diseño adaptable de TicketIA, con axe-core y un navegador automatizado.
//
// Uso (con la aplicación en marcha y datos de demostración):
//   npm install puppeteer axe-core
//   BASE_URL=http://127.0.0.1:5000 node usabilidad/accesibilidad.mjs
//
// Genera usabilidad/resultados/accesibilidad.json con las violaciones encontradas y el resultado del diseño adaptable.
import fs from 'fs'; import path from 'path'; import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const BASE = process.env.BASE_URL || 'http://127.0.0.1:5000';
const AXE = fs.readFileSync(require.resolve('axe-core/axe.min.js'), 'utf8');
const SALIDA = process.env.SALIDA || 'usabilidad/resultados/accesibilidad.json';

async function abrirNavegador() {
  try { const p = await import('puppeteer'); return await p.default.launch({ headless: 'shell', args: ['--no-sandbox'] }); }
  catch (e) {
    const p = (await import('puppeteer-core')).default; const c = (await import('@sparticuz/chromium')).default;
    return await p.launch({ args: [...c.args.filter(a => !['--single-process', '--no-zygote'].includes(a)), '--no-sandbox'], executablePath: await c.executablePath(), headless: 'shell' });
  }
}
const ROLES = {
  publico: { paginas: ['/login', '/registro'] },
  funcionario: { cuenta: ['pedro.funcionario@municipalidad.cl', 'usuario123'], paginas: ['/dashboard', '/tickets', '/tickets/nuevo', '/tickets/1'] },
  tecnico: { cuenta: ['kiara.tecnico@municipalidad.cl', 'tecnico123'], paginas: ['/dashboard', '/tickets', '/tickets/1'] },
  administrador: { cuenta: ['jade.admin@municipalidad.cl', 'admin123'], paginas: ['/dashboard', '/tickets', '/tickets/3', '/admin/usuarios', '/admin/usuarios/nuevo', '/admin/categorias', '/admin/categorias/nueva'] },
};
const navegador = await abrirNavegador();
const resultado = { base: BASE, fecha: new Date().toISOString(), paginas: [], responsive: [] };
for (const [rol, cfg] of Object.entries(ROLES)) {
  const ctx = await navegador.createBrowserContext(); const page = await ctx.newPage(); await page.setViewport({ width: 1280, height: 800 });
  if (cfg.cuenta) {
    await page.goto(BASE + '/login', { waitUntil: 'networkidle0' }); await page.type('input[name=email]', cfg.cuenta[0]); await page.type('input[name=password]', cfg.cuenta[1]);
    await Promise.all([page.waitForNavigation({ waitUntil: 'networkidle0' }), page.click('button[type=submit]')]);
  }
  for (const ruta of cfg.paginas) {
    await page.setViewport({ width: 1280, height: 800 }); await page.goto(BASE + ruta, { waitUntil: 'networkidle0' });
    await page.evaluate(AXE);
    const r = await page.evaluate(async () => (await axe.run(document, { runOnly: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] })).violations.map(v => ({ id: v.id, impacto: v.impact, ayuda: v.help, nodos: v.nodes.length, ejemplo: v.nodes[0].target.join(' ') })));
    resultado.paginas.push({ rol, ruta, violaciones: r });
    // diseño adaptable: en un teléfono (375 px) no debe haber desplazamiento horizontal
    await page.setViewport({ width: 375, height: 700 });
    const ancho = await page.evaluate(() => ({ contenido: document.documentElement.scrollWidth, ventana: window.innerWidth }));
    resultado.responsive.push({ rol, ruta, ...ancho, desborda: ancho.contenido > ancho.ventana + 1 });
  }
  await ctx.close();
}
await navegador.close();
fs.mkdirSync(path.dirname(SALIDA), { recursive: true }); fs.writeFileSync(SALIDA, JSON.stringify(resultado, null, 1));
const total = resultado.paginas.reduce((n, p) => n + p.violaciones.length, 0);
console.log(`páginas revisadas: ${resultado.paginas.length} | violaciones: ${total} | páginas que desbordan en 375 px: ${resultado.responsive.filter(r => r.desborda).length}`);
