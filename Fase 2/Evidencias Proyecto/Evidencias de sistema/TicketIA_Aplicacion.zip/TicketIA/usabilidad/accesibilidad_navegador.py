"""
accesibilidad_navegador.py — revisa la accesibilidad (WCAG 2.1 A y AA) de las pantallas de TicketIA en un navegador real.

Revisa 12 pantallas con los tres roles, en escritorio (1280 px) y en celular (375 px), y comprueba que no haya desborde horizontal.

Requisitos (una vez):     pip install playwright   y   playwright install chromium   y   npm install axe-core
Pasos:
  1. Cargar los datos de ejemplo:      python usabilidad/preparar_datos_sprint4.py
  2. Iniciar el sistema (por ejemplo en el puerto 5000) con MOSTRAR_CUENTAS_DEMO=1 y SESSION_COOKIE_SECURE=0
  3. Ejecutar:                         python usabilidad/accesibilidad_navegador.py --url http://127.0.0.1:5000
Escribe usabilidad/resultados/sprint4_accesibilidad.json y termina con error si hay violaciones.
"""
import argparse
import json
import os
import sys

from playwright.sync_api import sync_playwright

CUENTAS = {"admin": ("jade.admin@municipalidad.cl", "admin123"), "tecnico": ("kiara.tecnico@municipalidad.cl", "tecnico123"), "func": ("pedro.funcionario@municipalidad.cl", "usuario123")}
PAGINAS = [("admin", "/dashboard", "Panel del administrador (HU-16)"), ("admin", "/tickets", "Listado sin filtros (HU-15)"), ("admin", "/tickets?estado=en_progreso&prioridad=alta", "Listado con filtros (HU-15)"),
           ("admin", "/tickets/1", "Detalle del ticket para el administrador"), ("tecnico", "/dashboard", "Tablero Kanban del técnico (HU-17)"), ("tecnico", "/tickets/1", "Detalle con corrección de la clasificación (HU-14)"),
           ("func", "/dashboard", "Panel del funcionario"), ("func", "/tickets/4", "Detalle de un ticket resuelto: evaluar y reabrir (HU-18, HU-20)"), ("func", "/tickets/5", "Detalle de un ticket cerrado, ya evaluado (HU-18)"),
           ("func", "/tickets/nuevo", "Nuevo ticket"), ("admin", "/admin/usuarios", "Administración de usuarios"), ("admin", "/admin/categorias", "Administración de categorías")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:5000")
    ap.add_argument("--axe", default=os.path.join("node_modules", "axe-core", "axe.min.js"))
    a = ap.parse_args()
    if not os.path.exists(a.axe):
        sys.exit(f"No se encuentra axe-core en {a.axe}. Ejecuta: npm install axe-core")
    resultados = []
    with sync_playwright() as p:
        nav = p.chromium.launch()
        for ancho, nombre in ((1280, "escritorio"), (375, "celular")):
            contextos = {}
            for rol, ruta, titulo in PAGINAS:
                if rol not in contextos:
                    # La política de contenido del sistema bloquea scripts externos; se omite solo en este navegador de prueba para poder medir.
                    ctx = nav.new_context(viewport={"width": ancho, "height": 900}, bypass_csp=True)
                    pg = ctx.new_page(); pg.goto(a.url + "/login")
                    pg.fill("input[name=email]", CUENTAS[rol][0]); pg.fill("input[name=password]", CUENTAS[rol][1]); pg.click("button[type=submit]"); pg.wait_for_load_state()
                    contextos[rol] = (ctx, pg)
                pg = contextos[rol][1]; pg.goto(a.url + ruta); pg.add_script_tag(path=a.axe)
                r = pg.evaluate("async () => await axe.run(document, {runOnly: {type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']}})")
                desborde = pg.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth")
                resultados.append({"ancho": nombre, "pagina": titulo, "violaciones": [(v["id"], v["impact"], len(v["nodes"]), v["nodes"][0]["html"][:110]) for v in r["violations"]], "desborde": desborde})
            for ctx, _ in contextos.values():
                ctx.close()
        nav.close()
    total = sum(len(r["violaciones"]) for r in resultados)
    for r in resultados:
        print(f"{r['ancho']:10s} {r['pagina'][:60]:62s} violaciones: {len(r['violaciones'])} | desborde horizontal: {r['desborde']}")
        for v in r["violaciones"]:
            print("      ->", v)
    print(f"TOTAL de violaciones: {total} | vistas revisadas: {len(resultados)}")
    os.makedirs(os.path.join("usabilidad", "resultados"), exist_ok=True)
    with open(os.path.join("usabilidad", "resultados", "sprint4_accesibilidad.json"), "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=1)
    sys.exit(1 if total or any(r["desborde"] for r in resultados) else 0)


if __name__ == "__main__":
    main()
