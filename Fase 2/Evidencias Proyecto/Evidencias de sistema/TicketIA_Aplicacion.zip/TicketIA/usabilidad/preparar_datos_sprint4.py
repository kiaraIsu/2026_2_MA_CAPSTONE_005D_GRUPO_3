"""
preparar_datos_sprint4.py — carga tickets de ejemplo en distintos estados para revisar las pantallas del Sprint 4.

Antes: el sistema debe haberse iniciado al menos una vez, para que existan las cuentas de demostración.
Uso (desde la carpeta del proyecto):    python usabilidad/preparar_datos_sprint4.py
Usa las variables DB_HOST, DB_PORT, DB_NAME, DB_USER y DB_PASSWORD. ¡Borra los tickets que existan en esa base!
"""
import datetime as dt
import os

import psycopg2


def main():
    c = psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"), dbname=os.environ.get("DB_NAME", "ticketia"),
                         user=os.environ.get("DB_USER", "ticketia_user"), password=os.environ.get("DB_PASSWORD", "ticketia_pass"))
    c.autocommit = True
    cur = c.cursor()
    uno = lambda sql, a=(): (cur.execute(sql, a), cur.fetchone())[1][0]
    uid = lambda email: uno("SELECT id FROM usuarios WHERE email = %s", (email,))
    pedro, ana = uid("pedro.funcionario@municipalidad.cl"), uid("ana.funcionaria@municipalidad.cl")
    kiara, marcela = uid("kiara.tecnico@municipalidad.cl"), uid("marcela.tecnico@municipalidad.cl")
    cur.execute("DELETE FROM historial; DELETE FROM comentarios; DELETE FROM evaluaciones; DELETE FROM adjuntos; DELETE FROM tickets")
    ahora = dt.datetime.now(dt.timezone.utc)

    def ticket(titulo, desc, categoria, prioridad, estado, solicitante, tecnico, ia, horas, solucion=None):
        t = ahora - dt.timedelta(hours=horas)
        cur.execute(
            "INSERT INTO tickets (titulo, descripcion, categoria_id, prioridad_id, estado_id, usuario_id, tecnico_id, clasificado_por_ia, solucion, reapertura_solicitada, creado_en, actualizado_en) "
            "VALUES (%s, %s, (SELECT id FROM categorias WHERE nombre = %s), (SELECT id FROM prioridades WHERE codigo = %s), (SELECT id FROM estados WHERE codigo = %s), %s, %s, %s, %s, FALSE, %s, %s) RETURNING id",
            (titulo, desc, categoria, prioridad, estado, solicitante, tecnico, ia, solucion, t, t))
        tid = cur.fetchone()[0]
        cur.execute("INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, 'Ticket creado', %s)", (tid, solicitante, t))
        if ia:
            cur.execute("INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, %s, %s)",
                        (tid, solicitante, f"Clasificado automáticamente por IA (categoría '{categoria}', prioridad '{prioridad.capitalize()}')", t + dt.timedelta(seconds=1)))
        return tid

    a = ticket("La impresora del segundo piso no imprime", "Sale papel atascado y la luz roja parpadea. Necesitamos imprimir certificados.", "Hardware", "alta", "en_progreso", pedro, kiara, True, 30)
    ticket("No puedo ingresar al correo institucional", "Outlook me pide la contraseña a cada rato y no abre mis mensajes.", "Correo Electrónico", "media", "pendiente", ana, None, True, 20)
    ticket("Internet muy lento en la Dirección de Obras", "Con varios equipos conectados no se puede abrir el sistema de permisos.", "Redes e Internet", "media", "en_revision", ana, marcela, True, 28)
    ticket("Instalar Zoom para la reunión del jueves", "Necesito Zoom instalado en mi computador.", "Software", "baja", "resuelto", pedro, kiara, True, 52, "Se instaló Zoom y se probó la cámara.")
    e = ticket("Clave olvidada del sistema de patentes", "No recuerdo mi contraseña y el sistema me bloqueó.", "Cuentas y Accesos", "media", "cerrado", ana, marcela, False, 90, "Se restableció la contraseña.")
    f = ticket("Pantalla azul al abrir Excel", "Cada vez que abro una planilla grande se reinicia el computador.", "Software", "alta", "resuelto", pedro, marcela, True, 70, "Se actualizó el controlador de video.")
    cur.execute("INSERT INTO evaluaciones (ticket_id, puntaje, comentario, creado_en) VALUES (%s, 4, 'Atendieron rápido', now()), (%s, 5, 'Excelente', now())", (e, f))
    cur.execute("INSERT INTO comentarios (ticket_id, usuario_id, contenido, creado_en) VALUES (%s, %s, 'Ya revisé el equipo, mañana reviso el cable.', now()), (%s, %s, 'Gracias, quedo atento.', now())", (a, kiara, a, pedro))
    print("Datos de ejemplo cargados: 6 tickets en distintos estados, con comentarios y evaluaciones.")


if __name__ == "__main__":
    main()
