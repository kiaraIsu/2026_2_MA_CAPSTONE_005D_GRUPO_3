"""Prepara una base de datos SEPARADA ("ticketia_usabilidad") con los datos de demostración que usan las pruebas de usabilidad.

Crea los usuarios de demostración y 3 tickets de ejemplo:
  - tickets 1 y 2: de Pedro, asignados al técnico Kiara y en progreso;
  - ticket 3: de Pedro, pendiente y sin técnico (se usa para la tarea "Asignar un técnico").

Uso (desde la carpeta del proyecto, con PostgreSQL en marcha):
    python usabilidad/preparar_datos_demo.py
No toca tu base de desarrollo. Las pruebas de tareas crean registros (un usuario, una categoría y un ticket),
así que vuelve a ejecutar este script antes de repetir `tareas.mjs`.
"""
import os
import sys
from datetime import datetime, timedelta, timezone

import psycopg2

os.environ["DB_NAME"] = os.environ.get("USABILIDAD_DB_NAME", "ticketia_usabilidad")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database as db  # noqa: E402


def asegurar_base():
    conn = psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"), dbname="postgres",
                            user=os.environ.get("DB_USER", "ticketia_user"), password=os.environ.get("DB_PASSWORD", "ticketia_pass"))
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (os.environ["DB_NAME"],))
        if cur.fetchone() is None:
            cur.execute('CREATE DATABASE "%s"' % os.environ["DB_NAME"])
    conn.close()


def main():
    asegurar_base()
    db.reset_db()
    db.init_db()
    conn = db.get_db()
    uid = lambda email: db.query_one(conn, "SELECT id FROM usuarios WHERE email = %s", (email,))["id"]
    cid = lambda nombre: db.query_one(conn, "SELECT id FROM categorias WHERE nombre = %s", (nombre,))["id"]
    ahora = datetime.now(timezone.utc)
    tickets = [
        ("La impresora del segundo piso no imprime", "Aparece un error de papel atascado y no funciona.", "Hardware", "alta", "en_progreso", "kiara.tecnico@municipalidad.cl", ahora - timedelta(days=3)),
        ("No puedo ingresar al correo institucional", "El sistema dice que mi contraseña expiró.", "Correo Electrónico", "media", "en_progreso", "kiara.tecnico@municipalidad.cl", ahora - timedelta(days=1)),
        ("Solicitud de instalación de software", "Necesito instalar el programa de planillas.", "Software", "baja", "pendiente", None, ahora),
    ]
    for titulo, descripcion, categoria, prioridad, estado, tecnico, creado in tickets:
        db.execute(conn,
                   "INSERT INTO tickets (titulo, descripcion, categoria_id, prioridad_id, estado_id, usuario_id, tecnico_id, creado_en, actualizado_en) "
                   "VALUES (%s, %s, %s, (SELECT id FROM prioridades WHERE codigo = %s), (SELECT id FROM estados WHERE codigo = %s), %s, %s, %s, %s)",
                   (titulo, descripcion, cid(categoria), prioridad, estado, uid("pedro.funcionario@municipalidad.cl"), uid(tecnico) if tecnico else None, creado, creado))
    conn.commit()
    conn.close()
    print(f"Base '{os.environ['DB_NAME']}' lista con los datos de demostración.")


if __name__ == "__main__":
    main()
