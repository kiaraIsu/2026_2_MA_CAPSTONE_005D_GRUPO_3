"""HU-08 — Asignar o reasignar técnico (E2). Criterios CA1 a CA3."""
import pytest

from tests.conftest import (ADMIN, FUNCIONARIO, TECNICO, TECNICO_2, crear_ticket, historial_de, sql_exec, tecnico_de, usuario_id)

pytestmark = pytest.mark.hu08


def _asignar(cliente, ticket_id, tecnico_id):
    return cliente.post(f"/tickets/{ticket_id}/asignar", data={"tecnico_id": tecnico_id})


# ------------------------------------------------------------------ CA1
def test_ca1_el_administrador_asigna_un_tecnico_activo_a_un_ticket_sin_responsable(admin):
    tid = crear_ticket(FUNCIONARIO)
    r = _asignar(admin, tid, usuario_id(TECNICO))
    assert r.status_code == 302
    assert tecnico_de(tid) == usuario_id(TECNICO)


def test_ca1_la_asignacion_queda_registrada_en_el_historial(admin):
    tid = crear_ticket(FUNCIONARIO)
    _asignar(admin, tid, usuario_id(TECNICO))
    acciones = [h["accion"] for h in historial_de(tid)]
    assert any("Asignó el ticket" in a and "Kiara Isuiza" in a for a in acciones)
    assert historial_de(tid)[-1]["usuario_id"] == usuario_id(ADMIN)


def test_ca1_no_se_puede_asignar_un_tecnico_deshabilitado(admin):
    sql_exec("UPDATE usuarios SET activo = FALSE WHERE email = %s", (TECNICO[0],))
    tid = crear_ticket(FUNCIONARIO)
    _asignar(admin, tid, usuario_id(TECNICO))
    assert tecnico_de(tid) is None


def test_ca1_no_se_puede_asignar_a_un_usuario_que_no_es_tecnico(admin):
    tid = crear_ticket(FUNCIONARIO)
    r = _asignar(admin, tid, usuario_id(FUNCIONARIO))
    assert r.status_code == 404
    assert tecnico_de(tid) is None


def test_ca1_sin_seleccionar_tecnico_no_se_modifica_el_ticket(admin):
    tid = crear_ticket(FUNCIONARIO)
    admin.post(f"/tickets/{tid}/asignar", data={"tecnico_id": ""})
    assert tecnico_de(tid) is None and historial_de(tid) == []


def test_ca1_asignar_un_ticket_inexistente_responde_404(app, admin, monkeypatch):
    monkeypatch.setitem(app.config, "PROPAGATE_EXCEPTIONS", False)
    r = _asignar(admin, 99999, usuario_id(TECNICO))
    assert r.status_code == 404


# ------------------------------------------------------------------ CA2
def test_ca2_la_reasignacion_actualiza_al_responsable(admin):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    _asignar(admin, tid, usuario_id(TECNICO_2))
    assert tecnico_de(tid) == usuario_id(TECNICO_2)


def test_ca2_la_reasignacion_conserva_el_historial_anterior(admin):
    tid = crear_ticket(FUNCIONARIO)
    _asignar(admin, tid, usuario_id(TECNICO))
    _asignar(admin, tid, usuario_id(TECNICO_2))
    acciones = [h["accion"] for h in historial_de(tid)]
    asignaciones = [a for a in acciones if "Asignó el ticket" in a]
    assert len(asignaciones) == 2
    assert "Kiara Isuiza" in asignaciones[0] and "Marcela Soto" in asignaciones[1]


def test_ca2_reasignar_no_cambia_el_estado_de_un_ticket_en_progreso(admin):
    tid = crear_ticket(FUNCIONARIO, estado="en_revision", tecnico=TECNICO)
    _asignar(admin, tid, usuario_id(TECNICO_2))
    from tests.conftest import estado_de
    assert estado_de(tid) == "en_revision"


# ------------------------------------------------------------------ CA3
def test_ca3_un_funcionario_no_puede_asignar_tickets(funcionario):
    tid = crear_ticket(FUNCIONARIO)
    r = _asignar(funcionario, tid, usuario_id(TECNICO))
    assert r.status_code == 403 and tecnico_de(tid) is None


def test_ca3_un_tecnico_no_puede_asignar_ni_reasignar_tickets(tecnico):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    r = _asignar(tecnico, tid, usuario_id(TECNICO_2))
    assert r.status_code == 403 and tecnico_de(tid) == usuario_id(TECNICO)


def test_ca3_sin_sesion_no_se_puede_asignar(client):
    tid = crear_ticket(FUNCIONARIO)
    r = _asignar(client, tid, usuario_id(TECNICO))
    assert r.status_code == 302 and "/login" in r.headers["Location"] and tecnico_de(tid) is None
