"""HU-11 — Consultar historial de trazabilidad (E2). Criterios CA1 a CA3."""
import html as _html
import re

import pytest

from tests.conftest import (FUNCIONARIO, TECNICO, crear_ticket, estado_de, historial_de, sql, sql_exec, sql_uno, usuario_id)

pytestmark = pytest.mark.hu11


def _crear_por_ui(cliente, titulo, descripcion, **extra):
    data = {"titulo": titulo, "descripcion": descripcion}
    data.update(extra)
    assert cliente.post("/tickets/nuevo", data=data).status_code == 302
    return sql_uno("SELECT id FROM tickets ORDER BY id DESC LIMIT 1")["id"]


def _asignar(admin, tid, credenciales=TECNICO):
    return admin.post(f"/tickets/{tid}/asignar", data={"tecnico_id": usuario_id(credenciales)})


def _ticket_en_atencion():
    return crear_ticket(FUNCIONARIO, titulo="Equipo no enciende", estado="en_progreso", tecnico=TECNICO)


def _acciones(tid):
    return [h["accion"] for h in historial_de(tid)]


# ------------------------------------------------------------------ CA1
def test_ca1_el_historial_muestra_fecha_responsable_y_descripcion(funcionario, admin, tecnico):
    tid = _crear_por_ui(funcionario, "Computador no enciende", "No prende desde ayer")
    _asignar(admin, tid)
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "en_progreso"})
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    historial = html[html.index("Historial"):]
    assert "Ticket creado" in historial and "Pedro Fuentes" in historial
    assert "Kiara Isuiza" in historial or "Jade" in historial
    assert re.search(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}", historial)


def test_ca1_los_eventos_aparecen_en_orden_cronologico(funcionario, admin, tecnico):
    tid = _crear_por_ui(funcionario, "Computador no enciende", "No prende desde ayer")
    _asignar(admin, tid)
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "en_revision"})
    tecnico.post(f"/tickets/{tid}/comentar", data={"contenido": "Reviso mañana"})
    html = _html.unescape(funcionario.get(f"/tickets/{tid}").get_data(as_text=True))
    historial = html[html.index("Historial"):]
    orden = [historial.index("Ticket creado"), historial.index("Asignó el ticket"), historial.index("a 'En revisión'"), historial.index("Agregó un comentario")]
    assert orden == sorted(orden)


def test_ca1_los_eventos_con_la_misma_hora_se_ordenan_por_registro(funcionario):
    tid = _ticket_en_atencion()
    instante = "2026-11-03 10:00:00+00"
    for texto in ("Evento A", "Evento B", "Evento C"):
        sql_exec("INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, %s, %s)", (tid, usuario_id(TECNICO), texto, instante))
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert html.index("Evento A") < html.index("Evento B") < html.index("Evento C")


def test_ca1_cada_evento_muestra_a_su_responsable(funcionario, tecnico):
    tid = _ticket_en_atencion()
    tecnico.post(f"/tickets/{tid}/comentar", data={"contenido": "Reviso mañana"})
    funcionario.post(f"/tickets/{tid}/comentar", data={"contenido": "Gracias"})
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    historial = html[html.index("Historial"):]
    assert "Kiara Isuiza" in historial and "Pedro Fuentes" in historial


# ------------------------------------------------------------------ CA2
def test_ca2_la_clasificacion_automatica_queda_registrada_con_categoria_y_prioridad(funcionario):
    tid = _crear_por_ui(funcionario, "La impresora no imprime", "Sin tinta desde ayer")
    evento = [a for a in _acciones(tid) if "lasific" in a]
    assert evento, "la clasificación automática no quedó en el historial"
    assert "Hardware" in evento[0]
    assert "Media" in evento[0] or "Alta" in evento[0] or "Baja" in evento[0]


def test_ca2_la_asignacion_queda_registrada(admin):
    tid = crear_ticket(FUNCIONARIO, titulo="Equipo no enciende")
    _asignar(admin, tid)
    assert any("asign" in a.lower() and "Kiara Isuiza" in a for a in _acciones(tid))


def test_ca2_la_reasignacion_queda_registrada(admin):
    tid = crear_ticket(FUNCIONARIO, titulo="Equipo no enciende", estado="en_progreso", tecnico=TECNICO)
    antes = len(_acciones(tid))
    from tests.conftest import TECNICO_2
    _asignar(admin, tid, TECNICO_2)
    nuevas = _acciones(tid)[antes:]
    assert len(nuevas) == 1 and "Marcela" in nuevas[0]


def test_ca2_el_cambio_de_estado_queda_registrado(tecnico):
    tid = _ticket_en_atencion()
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "en_revision"})
    assert any("de 'En progreso' a 'En revisión'" in a for a in _acciones(tid))


def test_ca2_un_comentario_queda_registrado(funcionario):
    tid = _ticket_en_atencion()
    funcionario.post(f"/tickets/{tid}/comentar", data={"contenido": "Hola"})
    assert any("comentario" in a.lower() for a in _acciones(tid))


def test_ca2_la_reapertura_queda_registrada(funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Equipo no enciende", estado="resuelto", tecnico=TECNICO)
    funcionario.post(f"/tickets/{tid}/solicitar-reapertura", data={"motivo": "El problema volvió"})
    assert any("eapertura" in a and "El problema volvió" in a for a in _acciones(tid))


def test_ca2_la_asignacion_que_cambia_el_estado_registra_ambos_eventos(admin):
    tid = crear_ticket(FUNCIONARIO, titulo="Equipo no enciende")          # pendiente
    _asignar(admin, tid)
    assert estado_de(tid) == "en_progreso"
    acciones = _acciones(tid)
    assert any("Asignó el ticket" in a for a in acciones)
    assert any("de 'Pendiente' a 'En progreso'" in a for a in acciones), "el cambio automático de estado no quedó registrado"


def test_ca2_la_reasignacion_sin_cambio_de_estado_deja_un_solo_evento(admin):
    from tests.conftest import TECNICO_2
    tid = crear_ticket(FUNCIONARIO, titulo="Equipo no enciende", estado="en_progreso", tecnico=TECNICO)
    antes = len(_acciones(tid))
    _asignar(admin, tid, TECNICO_2)
    assert len(_acciones(tid)) == antes + 1


# ------------------------------------------------------------------ CA3
def test_ca3_quienes_tienen_permiso_ven_el_historial(funcionario, tecnico, admin):
    tid = _ticket_en_atencion()
    for cliente in (funcionario, tecnico, admin):
        r = cliente.get(f"/tickets/{tid}")
        assert r.status_code == 200 and "Historial" in r.get_data(as_text=True)


def test_ca3_un_usuario_sin_permisos_no_ve_el_historial(funcionaria2, tecnico2):
    tid = _ticket_en_atencion()
    sql_exec("INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, %s, now())", (tid, usuario_id(TECNICO), "Evento reservado"))
    for cliente in (funcionaria2, tecnico2):
        r = cliente.get(f"/tickets/{tid}")
        assert r.status_code == 403
        assert "Evento reservado" not in r.get_data(as_text=True)


def test_ca3_sin_sesion_se_pide_iniciar_sesion(client):
    tid = _ticket_en_atencion()
    r = client.get(f"/tickets/{tid}")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_ca3_el_historial_de_un_ticket_inexistente_responde_404(funcionario):
    assert funcionario.get("/tickets/99999").status_code == 404
