"""HU-06 — Visualizar detalle de un ticket (E2). Criterios CA1 a CA3."""
import pytest

from tests.conftest import FUNCIONARIO, TECNICO, crear_ticket, sql_exec, usuario_id

pytestmark = pytest.mark.hu06


def _ticket_completo():
    tid = crear_ticket(FUNCIONARIO, titulo="Servidor lento", descripcion="El sistema tarda mucho en abrir las carpetas compartidas",
                       prioridad="alta", estado="en_progreso", tecnico=TECNICO, categoria="Redes e Internet",
                       solucion="Se reinició el servidor de archivos")
    sql_exec("INSERT INTO adjuntos (ticket_id, nombre_archivo, ruta, creado_en) VALUES (%s, 'captura_error.png', 'x.png', NOW())", (tid,))
    sql_exec("INSERT INTO comentarios (ticket_id, usuario_id, contenido, creado_en) VALUES (%s, %s, 'Estamos revisando el equipo', NOW())",
             (tid, usuario_id(TECNICO)))
    sql_exec("INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, 'Ticket creado', NOW())",
             (tid, usuario_id(FUNCIONARIO)))
    return tid


def _html(r):
    return r.get_data(as_text=True)


# ------------------------------------------------------------------ CA1
def test_ca1_el_solicitante_ve_todos_los_datos_del_ticket(funcionario):
    tid = _ticket_completo()
    r = funcionario.get(f"/tickets/{tid}")
    assert r.status_code == 200
    html = _html(r)
    for esperado in ("El sistema tarda mucho en abrir las carpetas compartidas", "En progreso", "Redes e Internet", "Alta",
                     "Kiara Isuiza", "captura_error.png", "Estamos revisando el equipo", "Se reinició el servidor de archivos",
                     "Ticket creado"):
        assert esperado in html, f"falta '{esperado}' en el detalle"


def test_ca1_el_tecnico_asignado_puede_ver_el_detalle(tecnico):
    tid = _ticket_completo()
    assert tecnico.get(f"/tickets/{tid}").status_code == 200


def test_ca1_el_administrador_puede_ver_cualquier_ticket(admin):
    tid = _ticket_completo()
    assert admin.get(f"/tickets/{tid}").status_code == 200


# ------------------------------------------------------------------ CA2
def test_ca2_otro_funcionario_no_puede_ver_el_detalle(funcionaria2):
    tid = _ticket_completo()
    assert funcionaria2.get(f"/tickets/{tid}").status_code == 403


def test_ca2_un_tecnico_no_asignado_no_puede_ver_el_detalle(tecnico2):
    tid = _ticket_completo()
    assert tecnico2.get(f"/tickets/{tid}").status_code == 403


def test_ca2_sin_sesion_se_pide_iniciar_sesion(client):
    tid = _ticket_completo()
    r = client.get(f"/tickets/{tid}")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_ca2_un_ticket_inexistente_responde_404(funcionario):
    assert funcionario.get("/tickets/99999").status_code == 404


# ------------------------------------------------------------------ CA3
def test_ca3_un_ticket_sin_tecnico_informa_que_no_esta_asignado_sin_errores(funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Recién creado")
    r = funcionario.get(f"/tickets/{tid}")
    assert r.status_code == 200
    assert "Sin asignar" in _html(r)


def test_ca3_un_ticket_sin_solucion_informa_que_aun_no_hay_solucion(funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Recién creado")
    html = _html(funcionario.get(f"/tickets/{tid}"))
    assert "Aún no se ha registrado una solución" in html


def test_ca3_un_ticket_sin_adjuntos_ni_comentarios_ni_historial_no_genera_errores(funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Ticket mínimo")
    r = funcionario.get(f"/tickets/{tid}")
    assert r.status_code == 200
    html = _html(r)
    assert "Aún no hay comentarios" in html and "Sin movimientos registrados" in html
