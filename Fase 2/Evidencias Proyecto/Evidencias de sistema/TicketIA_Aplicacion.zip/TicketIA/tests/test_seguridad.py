"""Pruebas de seguridad de TicketIA (aplicadas a las historias del Sprint 1: sesión, usuarios, categorías y tickets con adjuntos).

Ámbitos: autenticación, control de acceso, inyección SQL, XSS, archivos adjuntos, cabeceras y configuración, y CSRF.
"""
import io
import os
import re

import pytest

import app as appmod
from tests.conftest import (ADMIN, FUNCIONARIA_2, FUNCIONARIO, TECNICO, TECNICO_2, crear_ticket, login, sql, sql_exec, sql_uno, usuario_id)

pytestmark = pytest.mark.seguridad
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _html(r):
    return r.get_data(as_text=True)


def _tablas_intactas():
    return sql_uno("SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_name IN ('usuarios', 'tickets', 'categorias')")["n"] == 3


def _subir_ticket_con_adjunto(cliente, titulo="Ticket con archivo", nombre="informe.txt"):
    cliente.post("/tickets/nuevo", data={"titulo": titulo, "descripcion": "Con adjunto", "categoria_id": "1", "prioridad": "media",
                                          "adjuntos": (io.BytesIO(b"contenido confidencial"), nombre)}, content_type="multipart/form-data")
    fila = sql_uno("SELECT a.ruta, a.ticket_id FROM adjuntos a ORDER BY a.id DESC LIMIT 1")
    return fila["ruta"], fila["ticket_id"]


# =================================================================== autenticación
def test_la_contrasena_se_guarda_con_hash_y_no_en_texto_plano(app):
    fila = sql_uno("SELECT password_hash FROM v_usuarios WHERE email = %s", (ADMIN[0],))
    assert fila["password_hash"] != ADMIN[1] and ":" in fila["password_hash"] or fila["password_hash"].startswith(("scrypt", "pbkdf2"))
    assert ADMIN[1] not in fila["password_hash"]


@pytest.mark.parametrize("carga", ["' OR '1'='1", "admin@x.cl' --", "'; DROP TABLE usuarios; --", "\" OR \"\"=\""])
def test_inyeccion_sql_en_el_login_no_permite_entrar(client, carga):
    r = client.post("/login", data={"email": carga, "password": carga})
    assert "user_id" not in client.get("/dashboard").request.environ.get("HTTP_COOKIE", "") or r.status_code in (200, 429)
    assert client.get("/dashboard").status_code == 302
    assert _tablas_intactas()


def test_el_mensaje_de_error_no_revela_si_el_correo_existe(client):
    a = _html(client.post("/login", data={"email": ADMIN[0], "password": "incorrecta"}))
    b = _html(client.post("/login", data={"email": "no.existe@municipalidad.cl", "password": "incorrecta"}))
    assert "Correo o contraseña incorrectos" in a and "Correo o contraseña incorrectos" in b


def test_tras_varios_intentos_fallidos_el_acceso_se_bloquea_temporalmente(client):
    for _ in range(5):
        client.post("/login", data={"email": ADMIN[0], "password": "incorrecta"})
    r = client.post("/login", data={"email": ADMIN[0], "password": ADMIN[1]})      # aunque ahora use la clave correcta
    assert r.status_code == 429 and "Demasiados intentos" in _html(r)
    assert client.get("/dashboard").status_code == 302


def test_un_inicio_de_sesion_correcto_reinicia_el_contador_de_intentos(client):
    for _ in range(3):
        client.post("/login", data={"email": ADMIN[0], "password": "incorrecta"})
    assert client.post("/login", data={"email": ADMIN[0], "password": ADMIN[1]}).status_code == 302
    client.get("/logout")
    for _ in range(3):
        client.post("/login", data={"email": ADMIN[0], "password": "incorrecta"})
    assert client.post("/login", data={"email": ADMIN[0], "password": ADMIN[1]}).status_code == 302


def test_la_cookie_de_sesion_es_httponly_y_samesite(client):
    r = client.post("/login", data={"email": ADMIN[0], "password": ADMIN[1]})
    cookie = r.headers.get("Set-Cookie", "")
    assert "HttpOnly" in cookie and "SameSite=Lax" in cookie


def test_no_existe_el_registro_publico_de_cuentas(client):
    assert client.get("/registro").status_code == 404
    assert client.post("/registro", data={"nombre": "Intruso", "email": "intruso@municipalidad.cl", "password": "clave123", "direccion": "X", "rol": "administrador"}).status_code == 404
    assert sql_uno("SELECT id FROM v_usuarios WHERE email = 'intruso@municipalidad.cl'") is None
    assert "Regístrate" not in _html(client.get("/login"))


def test_la_creacion_de_cuentas_rechaza_contrasenas_cortas(admin):
    admin.post("/admin/usuarios/nuevo", data={"nombre": "Corta", "email": "corta@municipalidad.cl", "password": "123", "rol": "usuario", "direccion": "X"})
    assert sql_uno("SELECT id FROM v_usuarios WHERE email = 'corta@municipalidad.cl'") is None


def test_una_cuenta_creada_por_el_administrador_puede_iniciar_sesion_con_el_rol_indicado(admin, client):
    admin.post("/admin/usuarios/nuevo", data={"nombre": "Nueva", "email": "nueva@municipalidad.cl", "password": "clave123", "rol": "usuario", "direccion": "DIDECO"})
    assert sql_uno("SELECT rol FROM v_usuarios WHERE email = 'nueva@municipalidad.cl'")["rol"] == "usuario"
    r = login(client, ("nueva@municipalidad.cl", "clave123"))
    assert r.status_code == 302 and r.headers["Location"].endswith("/dashboard")


# =================================================================== control de acceso
RUTAS_GET_PROTEGIDAS = ["/dashboard", "/tickets", "/tickets/nuevo", "/tickets/1", "/admin/usuarios", "/admin/usuarios/nuevo", "/admin/categorias", "/admin/categorias/nueva", "/adjuntos/archivo.txt"]


@pytest.mark.parametrize("ruta", RUTAS_GET_PROTEGIDAS)
def test_las_rutas_protegidas_exigen_iniciar_sesion(client, ruta):
    r = client.get(ruta)
    assert r.status_code == 302 and "/login" in r.headers["Location"]


@pytest.mark.parametrize("ruta", ["/admin/usuarios", "/admin/usuarios/nuevo", "/admin/categorias", "/admin/categorias/nueva"])
def test_las_rutas_de_administracion_estan_prohibidas_para_funcionarios_y_tecnicos(funcionario, tecnico, ruta):
    assert funcionario.get(ruta).status_code == 403
    assert tecnico.get(ruta).status_code == 403


def test_un_funcionario_no_puede_descargar_el_adjunto_de_otro(app, funcionario, funcionaria2):
    ruta, _ = _subir_ticket_con_adjunto(funcionario)
    assert funcionaria2.get(f"/adjuntos/{ruta}").status_code == 403


def test_el_solicitante_el_tecnico_asignado_y_el_administrador_si_pueden_descargar_el_adjunto(app, funcionario, admin, tecnico):
    ruta, tid = _subir_ticket_con_adjunto(funcionario)
    sql_exec("UPDATE tickets SET tecnico_id = %s WHERE id = %s", (usuario_id(TECNICO), tid))
    assert funcionario.get(f"/adjuntos/{ruta}").status_code == 200
    assert admin.get(f"/adjuntos/{ruta}").status_code == 200
    assert tecnico.get(f"/adjuntos/{ruta}").status_code == 200


def test_un_tecnico_no_asignado_no_puede_descargar_el_adjunto(app, funcionario, tecnico2):
    ruta, _ = _subir_ticket_con_adjunto(funcionario)
    assert tecnico2.get(f"/adjuntos/{ruta}").status_code == 403


def test_la_descarga_no_permite_salir_de_la_carpeta_de_adjuntos(admin):
    for ruta in ("../app.py", "..%2Fapp.py", "../../etc/passwd", "%2e%2e/%2e%2e/etc/passwd"):
        assert admin.get(f"/adjuntos/{ruta}").status_code in (403, 404)


def test_un_adjunto_inexistente_responde_404(admin):
    assert admin.get("/adjuntos/no_existe.txt").status_code == 404


# =================================================================== inyección SQL y XSS
def test_inyeccion_sql_en_los_filtros_del_listado_no_altera_la_consulta(funcionario):
    crear_ticket(FUNCIONARIO, titulo="Ticket visible")
    r = funcionario.get("/tickets", query_string={"estado": "' OR '1'='1", "prioridad": "1; DROP TABLE tickets; --"})
    assert r.status_code == 200 and "Ticket visible" not in _html(r)
    assert _tablas_intactas()


def test_inyeccion_sql_en_el_formulario_de_tickets_se_guarda_como_texto(funcionario):
    titulo = "x'); DROP TABLE tickets; --"
    funcionario.post("/tickets/nuevo", data={"titulo": titulo, "descripcion": "prueba", "categoria_id": "1", "prioridad": "media"})
    assert sql_uno("SELECT titulo FROM v_tickets ORDER BY id DESC LIMIT 1")["titulo"] == titulo
    assert _tablas_intactas()


def test_xss_el_titulo_y_la_descripcion_se_escapan(funcionario):
    funcionario.post("/tickets/nuevo", data={"titulo": "<script>alert(1)</script>", "descripcion": "<img src=x onerror=alert(2)>", "categoria_id": "1", "prioridad": "media"})
    tid = sql_uno("SELECT id FROM v_tickets ORDER BY id DESC LIMIT 1")["id"]
    for ruta in ("/dashboard", "/tickets", f"/tickets/{tid}"):
        html = _html(funcionario.get(ruta))
        assert "<script>alert(1)</script>" not in html and "<img src=x onerror" not in html


def test_xss_los_comentarios_y_la_solucion_se_escapan(admin):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    admin.post(f"/tickets/{tid}/comentar", data={"contenido": "<script>alert('c')</script>"})
    admin.post(f"/tickets/{tid}/solucion", data={"solucion": "<b onmouseover=alert(3)>solución</b>"})
    html = _html(admin.get(f"/tickets/{tid}"))
    assert "<script>alert('c')</script>" not in html and "<b onmouseover" not in html


def test_xss_el_nombre_de_usuario_se_escapa_en_el_listado_de_usuarios(admin):
    admin.post("/admin/usuarios/nuevo", data={"nombre": "<script>alert(9)</script>", "email": "xss@municipalidad.cl", "password": "clave123", "rol": "usuario", "direccion": "X"})
    assert "<script>alert(9)</script>" not in _html(admin.get("/admin/usuarios"))


# =================================================================== archivos adjuntos
@pytest.mark.parametrize("nombre", ["programa.exe", "pagina.html", "imagen.svg", "script.php", "tarea.sh", "macro.js", "doble.txt.exe"])
def test_no_se_aceptan_extensiones_peligrosas(funcionario, nombre):
    funcionario.post("/tickets/nuevo", data={"titulo": "Archivo peligroso", "descripcion": "x", "categoria_id": "1", "prioridad": "media",
                                              "adjuntos": (io.BytesIO(b"x"), nombre)}, content_type="multipart/form-data")
    assert sql_uno("SELECT id FROM v_tickets WHERE titulo = 'Archivo peligroso'") is None


def test_un_nombre_de_archivo_con_ruta_se_sanea(funcionario):
    funcionario.post("/tickets/nuevo", data={"titulo": "Ruta maliciosa", "descripcion": "x", "categoria_id": "1", "prioridad": "media",
                                              "adjuntos": (io.BytesIO(b"x"), "../../evil.txt")}, content_type="multipart/form-data")
    fila = sql_uno("SELECT ruta, nombre_archivo FROM adjuntos ORDER BY id DESC LIMIT 1")
    assert ".." not in fila["ruta"] and "/" not in fila["ruta"] and "/" not in fila["nombre_archivo"]
    assert os.path.exists(os.path.join(appmod.UPLOAD_DIR, fila["ruta"]))


def test_los_adjuntos_se_descargan_como_archivo_y_no_se_ejecutan_en_el_navegador(funcionario):
    ruta, _ = _subir_ticket_con_adjunto(funcionario)
    r = funcionario.get(f"/adjuntos/{ruta}")
    assert "attachment" in r.headers.get("Content-Disposition", "")


def test_los_nombres_de_los_adjuntos_no_son_adivinables(funcionario):
    ruta, tid = _subir_ticket_con_adjunto(funcionario, nombre="informe.txt")
    assert not re.fullmatch(rf"{tid}_\d{{10}}_informe\.txt", ruta), "el nombre guardado es predecible (id + hora + nombre original)"


# =================================================================== cabeceras y configuración
def test_las_respuestas_incluyen_cabeceras_de_seguridad(funcionario):
    h = funcionario.get("/dashboard").headers
    assert h.get("X-Content-Type-Options") == "nosniff"
    assert h.get("X-Frame-Options") in ("DENY", "SAMEORIGIN")
    assert "Referrer-Policy" in h and "Content-Security-Policy" in h


def test_la_politica_de_contenido_no_permite_scripts_en_linea_sin_nonce(funcionario):
    r = funcionario.get("/tickets/nuevo")
    csp = r.headers["Content-Security-Policy"]
    script_src = re.search(r"script-src ([^;]+)", csp).group(1)
    assert "'unsafe-inline'" not in script_src and "object-src 'none'" in csp
    nonce = re.search(r"'nonce-([^']+)'", script_src).group(1)
    for etiqueta in re.findall(r"<script(?![^>]*src=)[^>]*>", _html(r)):
        assert f'nonce="{nonce}"' in etiqueta, "hay un script en línea sin nonce"
    assert not re.search(r' on(click|change|submit|load)=', _html(r))


def test_la_interfaz_no_depende_de_servidores_externos(funcionario):
    r = funcionario.get("/dashboard")
    assert "cdn.jsdelivr.net" not in _html(r) and "https://" not in r.headers["Content-Security-Policy"]
    for recurso in ("vendor/bootstrap/bootstrap.min.css", "vendor/bootstrap/bootstrap.bundle.min.js", "vendor/bootstrap-icons/bootstrap-icons.css"):
        assert funcionario.get(f"/static/{recurso}").status_code == 200


def test_las_paginas_de_error_no_muestran_detalles_internos(client, funcionario):
    for r in (funcionario.get("/tickets/99999"), funcionario.get("/admin/usuarios"), client.get("/no-existe")):
        html = _html(r)
        assert "Traceback" not in html and "werkzeug" not in html.lower()


def test_docker_compose_no_activa_el_modo_debug_ni_deja_una_clave_fija():
    texto = open(os.path.join(RAIZ, "docker-compose.yml"), encoding="utf-8").read()
    assert 'FLASK_DEBUG: "1"' not in texto
    assert "SECRET_KEY: cambia-esta-clave-en-produccion" not in texto


def test_el_modo_debug_esta_desactivado_por_defecto():
    codigo = open(os.path.join(RAIZ, "app.py"), encoding="utf-8").read()
    assert 'os.environ.get("FLASK_DEBUG", "1")' not in codigo


# =================================================================== CSRF
@pytest.fixture()
def csrf(app):
    app.config["CSRF_ACTIVO"] = True
    return app


def _token(cliente, ruta):
    m = re.search(r'name="csrf_token" value="([^"]+)"', _html(cliente.get(ruta)))
    assert m, f"la página {ruta} no incluye el token CSRF"
    return m.group(1)


@pytest.mark.parametrize("ruta", ["/login"])
def test_los_formularios_publicos_incluyen_el_token_csrf(client, ruta):
    assert 'name="csrf_token"' in _html(client.get(ruta))


def test_los_formularios_de_sesion_incluyen_el_token_csrf(funcionario, admin):
    assert 'name="csrf_token"' in _html(funcionario.get("/tickets/nuevo"))
    assert 'name="csrf_token"' in _html(admin.get("/admin/usuarios"))
    assert 'name="csrf_token"' in _html(admin.get("/admin/categorias/nueva"))


def test_una_solicitud_post_sin_token_csrf_es_rechazada(admin, csrf):
    assert admin.get("/admin/usuarios").status_code == 200          # la sesión es válida y trae su token
    uid = usuario_id(FUNCIONARIA_2)
    r = admin.post(f"/admin/usuarios/{uid}/estado")                # sin token
    assert r.status_code == 400
    assert admin.get("/admin/usuarios").status_code == 200          # sigue con sesión: el rechazo fue por el CSRF
    assert sql_uno("SELECT activo FROM v_usuarios WHERE id = %s", (uid,))["activo"] is True


def test_una_solicitud_post_con_token_invalido_es_rechazada(admin, csrf):
    assert admin.get("/admin/usuarios").status_code == 200
    r = admin.post(f"/admin/usuarios/{usuario_id(FUNCIONARIA_2)}/estado", data={"csrf_token": "falso"})
    assert r.status_code == 400


def test_una_solicitud_post_con_token_valido_funciona(admin, csrf):
    token = _token(admin, "/admin/usuarios")
    uid = usuario_id(FUNCIONARIA_2)
    r = admin.post(f"/admin/usuarios/{uid}/estado", data={"csrf_token": token})
    assert r.status_code == 302
    assert sql_uno("SELECT activo FROM v_usuarios WHERE id = %s", (uid,))["activo"] is False


def test_el_inicio_de_sesion_tambien_exige_el_token_csrf(client, csrf):
    r = client.post("/login", data={"email": ADMIN[0], "password": ADMIN[1]})
    assert r.status_code == 400
    token = _token(client, "/login")
    assert client.post("/login", data={"email": ADMIN[0], "password": ADMIN[1], "csrf_token": token}).status_code == 302


# =================================================================== validación de datos de entrada (hallazgos del escáner Wapiti)
@pytest.fixture()
def sin_propagar_errores(app):
    """Hace que un error interno se vea como una respuesta HTTP 500 (en pruebas, Flask lo propaga como excepción)."""
    app.config["PROPAGATE_EXCEPTIONS"] = False
    return app


@pytest.mark.parametrize("ruta,datos", [("/tickets?estado=a%00b", None), ("/tickets?prioridad=%00", None),
                                         ("/login", {"email": "a\x00b", "password": "x"}), ("/admin/usuarios/nuevo", {"nombre": "a\x00b", "email": "x@y.cl", "password": "clave123", "rol": "usuario"})])
def test_los_datos_con_caracteres_nulos_se_rechazan_sin_error_del_servidor(sin_propagar_errores, funcionario, admin, client, ruta, datos):
    cliente = funcionario if ruta.startswith("/tickets") else admin if ruta.startswith("/admin") else client
    r = cliente.get(ruta) if datos is None else cliente.post(ruta, data=datos)
    assert r.status_code == 400


def test_un_comentario_con_caracter_nulo_se_rechaza_sin_error_del_servidor(sin_propagar_errores, funcionario):
    tid = crear_ticket(FUNCIONARIO)
    assert funcionario.post(f"/tickets/{tid}/comentar", data={"contenido": "hola\x00mundo"}).status_code == 400


def test_un_identificador_de_categoria_no_numerico_no_provoca_error_del_servidor(sin_propagar_errores, funcionario):
    r = funcionario.post("/tickets/nuevo", data={"titulo": "Categoría rara", "descripcion": "x", "categoria_id": "abc", "prioridad": "media"})
    assert r.status_code != 500
    assert sql_uno("SELECT id FROM v_tickets WHERE titulo = 'Categoría rara'") is None or r.status_code in (200, 302)


def test_un_identificador_de_tecnico_no_numerico_no_provoca_error_del_servidor(sin_propagar_errores, admin):
    tid = crear_ticket(FUNCIONARIO)
    r = admin.post(f"/tickets/{tid}/asignar", data={"tecnico_id": "abc"})
    assert r.status_code != 500
    from tests.conftest import tecnico_de
    assert tecnico_de(tid) is None


# =================================================================== condiciones de carrera (hallazgo del escáner Wapiti)
def _simular_carrera(monkeypatch, texto_sql):
    """Hace que la verificación previa no encuentre el duplicado, como ocurre cuando dos solicitudes llegan a la vez."""
    original = appmod.db.query_one

    def falso(conn, consulta, params=None):
        return None if texto_sql in consulta else original(conn, consulta, params)

    monkeypatch.setattr(appmod.db, "query_one", falso)


def test_dos_solicitudes_simultaneas_con_el_mismo_correo_no_provocan_error_del_servidor(sin_propagar_errores, admin, monkeypatch):
    _simular_carrera(monkeypatch, "SELECT id FROM v_usuarios WHERE email")
    r = admin.post("/admin/usuarios/nuevo", data={"nombre": "Duplicado", "email": FUNCIONARIO[0], "password": "clave123", "rol": "usuario", "direccion": "X"})
    assert r.status_code == 200 and "Ya existe un usuario con ese correo" in _html(r)


def test_dos_solicitudes_simultaneas_con_la_misma_categoria_no_provocan_error_del_servidor(sin_propagar_errores, admin, monkeypatch):
    _simular_carrera(monkeypatch, "SELECT id FROM categorias WHERE lower(nombre)")
    r = admin.post("/admin/categorias/nueva", data={"nombre": "Hardware"})
    assert r.status_code == 200 and "Ya existe una categoría con ese nombre" in _html(r)


# =================================================================== token CSRF con caracteres no ASCII (hallazgo del escáner Wapiti)
@pytest.mark.parametrize("token", ["ñandú", "tókén-con-tilde", "日本語", "emoji-😀"])
def test_un_token_csrf_con_caracteres_no_ascii_se_rechaza_sin_error_del_servidor(sin_propagar_errores, client, csrf, token):
    client.get("/login")                      # abre la sesión y recibe su token, como hace un navegador
    r = client.post("/login", data={"email": ADMIN[0], "password": ADMIN[1], "csrf_token": token})
    assert r.status_code == 400


# =================================================================== autenticación: cuentas de demostración
def test_la_pantalla_de_inicio_de_sesion_no_publica_las_cuentas_de_demostracion_por_defecto(app, client, monkeypatch):
    monkeypatch.setitem(app.config, "MOSTRAR_CUENTAS_DEMO", False)
    html = _html(client.get("/login"))
    assert "Cuentas de demostración" not in html
    for clave in ("admin123", "tecnico123", "usuario123"):
        assert clave not in html


def test_las_cuentas_de_demostracion_solo_se_muestran_si_se_activan_expresamente(app, client, monkeypatch):
    monkeypatch.setitem(app.config, "MOSTRAR_CUENTAS_DEMO", True)
    assert "Cuentas de demostración" in _html(client.get("/login"))
