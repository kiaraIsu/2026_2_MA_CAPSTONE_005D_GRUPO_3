"""HU-13 — Clasificar automáticamente categoría y prioridad (E3). Criterios CA1 a CA4."""
import csv
import os

import pytest

import ai_classifier as ia
from tests.conftest import FUNCIONARIO, sql, sql_exec, sql_uno

pytestmark = pytest.mark.hu13

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATEGORIAS = {"Hardware": 1, "Software": 2, "Redes e Internet": 3, "Correo Electrónico": 4, "Cuentas y Accesos": 5, "Otros": 6}
PRIORIDADES = {"alta", "media", "baja"}
META = 0.80


def _leer(nombre):
    with open(os.path.join(RAIZ, "validacion_ia", nombre), newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def _exactitud(filas):
    por_id = {v: k for k, v in CATEGORIAS.items()}
    cat = pri = 0
    for f in filas:
        r = ia.clasificar_ticket(f["titulo"], f["descripcion"], CATEGORIAS)
        cat += por_id[r["categoria_id"]] == f["categoria_esperada"]
        pri += r["prioridad"] == f["prioridad_esperada"]
    return cat / len(filas), pri / len(filas)


def _crear_por_ui(cliente, titulo, descripcion, **extra):
    data = {"titulo": titulo, "descripcion": descripcion}
    data.update(extra)
    r = cliente.post("/tickets/nuevo", data=data)
    return r, sql_uno("SELECT * FROM v_tickets ORDER BY id DESC LIMIT 1")


# ------------------------------------------------------------------ CA1
@pytest.mark.parametrize("titulo,descripcion", [
    ("La impresora no imprime", "Sale papel atascado"), ("No tengo internet", "Desde esta mañana"), ("No puedo entrar a mi cuenta", "Olvidé la clave"),
    ("Outlook no abre", "No veo mis correos"), ("Excel se cierra solo", "Al abrir la planilla"), ("Consulta sobre capacitación", "Para el equipo"),
])
def test_ca1_propone_una_categoria_activa_y_una_prioridad_valida(titulo, descripcion):
    r = ia.clasificar_ticket(titulo, descripcion, CATEGORIAS)
    assert r["categoria_id"] in CATEGORIAS.values() and r["prioridad"] in PRIORIDADES


@pytest.mark.parametrize("activas", [["Software", "Redes e Internet"], ["Otros"], ["Software"], ["Hardware", "Correo Electrónico", "Cuentas y Accesos"]])
def test_ca1_nunca_propone_una_categoria_desactivada(activas):
    disponibles = {n: CATEGORIAS[n] for n in activas}
    for titulo, desc in (("La impresora no imprime", "Sin tinta"), ("Sin internet", "Todo el piso"), ("Clave olvidada", "No entro"), ("Hola", "Mensaje sin sentido")):
        assert ia.clasificar_ticket(titulo, desc, disponibles)["categoria_id"] in disponibles.values()


@pytest.mark.parametrize("titulo,descripcion", [("", ""), ("   ", "   "), ("ñandú ✓ 日本語", "emoji 😀 y acentos áéíóú"), ("a" * 5000, "b" * 5000), ("1234567890", "!!!???")])
def test_ca1_textos_vacios_o_extranos_no_rompen_el_clasificador(titulo, descripcion):
    r = ia.clasificar_ticket(titulo, descripcion, CATEGORIAS)
    assert r["categoria_id"] in CATEGORIAS.values() and r["prioridad"] in PRIORIDADES


def test_ca1_un_ticket_nuevo_queda_con_una_categoria_activa(funcionario):
    sql_exec("UPDATE categorias SET activa = FALSE WHERE nombre = 'Hardware'")
    r, t = _crear_por_ui(funcionario, "La impresora no imprime", "Sin tinta desde ayer")
    assert r.status_code == 302
    assert sql_uno("SELECT activa FROM categorias WHERE id = %s", (t["categoria_id"],))["activa"]


def test_ca1_sin_categorias_activas_no_provoca_un_error_del_servidor(funcionario):
    sql_exec("UPDATE categorias SET activa = FALSE")
    r = funcionario.post("/tickets/nuevo", data={"titulo": "La impresora no imprime", "descripcion": "Sin tinta"})
    assert r.status_code != 500
    assert sql_uno("SELECT COUNT(*) AS n FROM tickets")["n"] == 0


def test_ca1_el_ticket_queda_con_una_prioridad_valida(funcionario):
    r, t = _crear_por_ui(funcionario, "Urgente: no hay internet", "Toda la oficina sin conexión")
    assert t["prioridad"] in PRIORIDADES


# ------------------------------------------------------------------ CA2
def test_ca2_el_detalle_identifica_la_clasificacion_automatica(funcionario):
    r, t = _crear_por_ui(funcionario, "La impresora no imprime", "Sin tinta desde ayer")
    assert t["clasificado_por_ia"]
    assert "Clasificado por IA" in funcionario.get(f"/tickets/{t['id']}").get_data(as_text=True)


def test_ca2_un_ticket_clasificado_a_mano_no_muestra_la_etiqueta(funcionario):
    cat = sql_uno("SELECT id FROM categorias WHERE nombre = 'Software'")["id"]
    r, t = _crear_por_ui(funcionario, "Excel se cierra", "Al abrir", categoria_id=str(cat), prioridad="alta")
    assert not t["clasificado_por_ia"]
    assert "Clasificado por IA" not in funcionario.get(f"/tickets/{t['id']}").get_data(as_text=True)


def test_ca2_la_clasificacion_automatica_queda_en_el_historial(funcionario):
    r, t = _crear_por_ui(funcionario, "La impresora no imprime", "Sin tinta desde ayer")
    historial = [h["accion"] for h in sql("SELECT accion FROM historial WHERE ticket_id = %s ORDER BY id", (t["id"],))]
    assert any("lasific" in a for a in historial)


# ------------------------------------------------------------------ CA3
def test_ca3_el_conjunto_de_validacion_esta_definido_con_100_casos_y_6_categorias():
    for nombre in ("set_validacion.csv", "set_prueba.csv"):
        filas = _leer(nombre)
        assert len(filas) == 100 and {f["categoria_esperada"] for f in filas} == set(CATEGORIAS)
        assert {f["prioridad_esperada"] for f in filas} == PRIORIDADES


def test_ca3_exactitud_de_la_categoria_en_el_conjunto_de_prueba():
    cat, _ = _exactitud(_leer("set_prueba.csv"))
    assert cat >= META, f"exactitud de la categoría: {cat:.0%}"


def test_ca3_exactitud_de_la_prioridad_en_el_conjunto_de_prueba():
    _, pri = _exactitud(_leer("set_prueba.csv"))
    assert pri >= META, f"exactitud de la prioridad: {pri:.0%}"


def test_ca3_exactitud_en_el_conjunto_de_desarrollo():
    cat, pri = _exactitud(_leer("set_validacion.csv"))
    assert cat >= META and pri >= META, f"categoría {cat:.0%} y prioridad {pri:.0%}"


# ------------------------------------------------------------------ CA4
def _valido(titulo, descripcion, categorias):
    return {"categoria_id": 2, "prioridad": "alta"}


def test_ca4_sin_motor_avanzado_se_usan_las_reglas():
    r = ia.clasificar_ticket("La impresora no imprime", "Sin tinta", CATEGORIAS)
    assert r["motor"] == "reglas"


def test_ca4_si_el_motor_avanzado_responde_bien_se_usa(monkeypatch):
    monkeypatch.setattr(ia, "MOTOR_AVANZADO", _valido)
    r = ia.clasificar_ticket("La impresora no imprime", "Sin tinta", CATEGORIAS)
    assert r == {"categoria_id": 2, "prioridad": "alta", "motor": "avanzado"}


@pytest.mark.parametrize("falla", [
    lambda t, d, c: (_ for _ in ()).throw(TimeoutError("sin respuesta")),
    lambda t, d, c: (_ for _ in ()).throw(ConnectionError("servicio caído")),
    lambda t, d, c: (_ for _ in ()).throw(RuntimeError("error interno")),
])
def test_ca4_si_el_motor_avanzado_falla_se_usa_el_respaldo_por_reglas(monkeypatch, falla):
    monkeypatch.setattr(ia, "MOTOR_AVANZADO", falla)
    r = ia.clasificar_ticket("La impresora no imprime", "Sin tinta", CATEGORIAS)
    assert r["motor"] == "reglas" and r["categoria_id"] == CATEGORIAS["Hardware"]


@pytest.mark.parametrize("respuesta", [None, {}, {"categoria_id": 999, "prioridad": "alta"}, {"categoria_id": 1, "prioridad": "urgentisima"}, "texto", {"categoria_id": 1}])
def test_ca4_si_el_motor_avanzado_responde_algo_invalido_se_usa_el_respaldo(monkeypatch, respuesta):
    monkeypatch.setattr(ia, "MOTOR_AVANZADO", lambda t, d, c: respuesta)
    r = ia.clasificar_ticket("La impresora no imprime", "Sin tinta", CATEGORIAS)
    assert r["motor"] == "reglas" and r["categoria_id"] in CATEGORIAS.values() and r["prioridad"] in PRIORIDADES


def test_ca4_la_creacion_del_ticket_no_se_impide_si_el_motor_falla(funcionario, monkeypatch):
    def caido(t, d, c):
        raise ConnectionError("servicio caído")
    monkeypatch.setattr(ia, "MOTOR_AVANZADO", caido)
    r, t = _crear_por_ui(funcionario, "La impresora no imprime", "Sin tinta desde ayer")
    assert r.status_code == 302 and t is not None and t["clasificado_por_ia"]
