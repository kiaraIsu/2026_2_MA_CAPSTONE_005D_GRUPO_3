"""HU-10 — Registrar comentarios en un ticket (E2). Criterios CA1 a CA3."""
import re
from datetime import datetime, timedelta, timezone

import pytest

from tests.conftest import (FUNCIONARIO, TECNICO, crear_ticket, historial_de, sql, usuario_id)

pytestmark = pytest.mark.hu10


def _comentar(cliente, ticket_id, texto):
    return cliente.post(f"/tickets/{ticket_id}/comentar", data={"contenido": texto})


def _ticket():
    return crear_ticket(FUNCIONARIO, titulo="Impresora sin tinta", estado="en_progreso", tecnico=TECNICO)


def _comentarios(ticket_id):
    return sql("SELECT usuario_id, contenido, creado_en FROM comentarios WHERE ticket_id = %s ORDER BY id", (ticket_id,))


# ------------------------------------------------------------------ CA1
def test_ca1_el_solicitante_registra_un_comentario(funcionario):
    tid = _ticket()
    r = _comentar(funcionario, tid, "Sigue sin imprimir")
    assert r.status_code == 302
    assert [c["contenido"] for c in _comentarios(tid)] == ["Sigue sin imprimir"]


def test_ca1_el_tecnico_asignado_registra_un_comentario(tecnico):
    tid = _ticket()
    assert _comentar(tecnico, tid, "Voy a revisar el cabezal").status_code == 302
    assert len(_comentarios(tid)) == 1


def test_ca1_el_administrador_registra_un_comentario(admin):
    tid = _ticket()
    assert _comentar(admin, tid, "Priorizar este caso").status_code == 302
    assert len(_comentarios(tid)) == 1


def test_ca1_el_comentario_queda_con_autor_fecha_y_hora(funcionario):
    tid = _ticket()
    _comentar(funcionario, tid, "Sigue sin imprimir")
    c = _comentarios(tid)[0]
    assert c["usuario_id"] == usuario_id(FUNCIONARIO)
    assert c["creado_en"] is not None
    assert abs(datetime.now(timezone.utc) - c["creado_en"]) < timedelta(minutes=1)


def test_ca1_el_comentario_se_muestra_con_su_autor_fecha_y_hora(tecnico):
    tid = _ticket()
    _comentar(tecnico, tid, "Voy a revisar el cabezal")
    html = tecnico.get(f"/tickets/{tid}").get_data(as_text=True)
    bloque = html[html.index("Voy a revisar el cabezal") - 400: html.index("Voy a revisar el cabezal") + 100]
    assert "Kiara Isuiza" in bloque
    assert re.search(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}", bloque)


def test_ca1_el_texto_se_guarda_sin_espacios_sobrantes(funcionario):
    tid = _ticket()
    _comentar(funcionario, tid, "   Sigue sin imprimir   ")
    assert _comentarios(tid)[0]["contenido"] == "Sigue sin imprimir"


def test_ca1_el_comentario_queda_en_el_historial(funcionario):
    tid = _ticket()
    _comentar(funcionario, tid, "Sigue sin imprimir")
    assert any("comentario" in h["accion"].lower() for h in historial_de(tid))


def test_ca1_un_comentario_con_html_se_muestra_como_texto(funcionario):
    tid = _ticket()
    _comentar(funcionario, tid, "<script>alert(1)</script>")
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;" in html


# ------------------------------------------------------------------ CA2
@pytest.mark.parametrize("texto", ["", "   ", "\n\t  ", "\u00a0 \u00a0"])
def test_ca2_un_comentario_vacio_o_solo_con_espacios_no_se_guarda(funcionario, texto):
    tid = _ticket()
    r = _comentar(funcionario, tid, texto)
    assert r.status_code == 302
    assert _comentarios(tid) == []


def test_ca2_se_informa_que_el_comentario_no_puede_estar_vacio(funcionario):
    tid = _ticket()
    r = funcionario.post(f"/tickets/{tid}/comentar", data={"contenido": "   "}, follow_redirects=True)
    assert "El comentario no puede estar vacío" in r.get_data(as_text=True)


def test_ca2_enviar_sin_el_campo_tambien_se_rechaza(funcionario):
    tid = _ticket()
    assert funcionario.post(f"/tickets/{tid}/comentar", data={}).status_code == 302
    assert _comentarios(tid) == []


def test_ca2_un_comentario_vacio_no_deja_evento_en_el_historial(funcionario):
    tid = _ticket()
    antes = len(historial_de(tid))
    _comentar(funcionario, tid, "   ")
    assert len(historial_de(tid)) == antes


# ------------------------------------------------------------------ CA3
def test_ca3_otro_usuario_autorizado_ve_el_comentario(funcionario, tecnico, admin):
    tid = _ticket()
    _comentar(funcionario, tid, "Sigue sin imprimir")
    for cliente in (tecnico, admin):
        html = cliente.get(f"/tickets/{tid}").get_data(as_text=True)
        assert "Sigue sin imprimir" in html and "Pedro Fuentes" in html


def test_ca3_los_comentarios_se_ordenan_cronologicamente(funcionario, tecnico):
    tid = _ticket()
    _comentar(funcionario, tid, "Primer mensaje")
    _comentar(tecnico, tid, "Segundo mensaje")
    _comentar(funcionario, tid, "Tercer mensaje")
    html = tecnico.get(f"/tickets/{tid}").get_data(as_text=True)
    assert html.index("Primer mensaje") < html.index("Segundo mensaje") < html.index("Tercer mensaje")


def test_ca3_sin_comentarios_se_informa(tecnico):
    tid = _ticket()
    assert "Aún no hay comentarios." in tecnico.get(f"/tickets/{tid}").get_data(as_text=True)


def test_ca3_un_usuario_ajeno_no_puede_comentar_ni_ver_el_hilo(funcionaria2, tecnico2):
    tid = _ticket()
    for cliente in (funcionaria2, tecnico2):
        assert _comentar(cliente, tid, "Intento ajeno").status_code == 403
        assert cliente.get(f"/tickets/{tid}").status_code == 403
    assert _comentarios(tid) == []


def test_ca3_sin_sesion_se_pide_iniciar_sesion(client):
    tid = _ticket()
    r = _comentar(client, tid, "Sin sesión")
    assert r.status_code == 302 and "/login" in r.headers["Location"]
    assert _comentarios(tid) == []


def test_ca3_comentar_un_ticket_inexistente_responde_404(funcionario):
    assert _comentar(funcionario, 99999, "Hola").status_code == 404
