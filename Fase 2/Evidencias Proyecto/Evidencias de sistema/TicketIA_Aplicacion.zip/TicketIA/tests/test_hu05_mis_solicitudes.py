"""HU-05 — Consultar mis solicitudes (E2). Criterios CA1 a CA3."""
from datetime import datetime, timedelta, timezone

import pytest

import app as appmod
from tests.conftest import FUNCIONARIA_2, FUNCIONARIO, crear_ticket, sql_uno

pytestmark = pytest.mark.hu05


def _html(respuesta):
    return respuesta.get_data(as_text=True)


# ------------------------------------------------------------------ CA1
def test_ca1_el_funcionario_ve_solo_sus_tickets_en_mis_solicitudes(funcionario):
    crear_ticket(FUNCIONARIO, titulo="Impresora del piso dos sin tinta")
    crear_ticket(FUNCIONARIO, titulo="Monitor parpadea mucho")
    crear_ticket(FUNCIONARIA_2, titulo="Teclado de Ana roto")
    html = _html(funcionario.get("/dashboard"))
    assert "Impresora del piso dos sin tinta" in html
    assert "Monitor parpadea mucho" in html
    assert "Teclado de Ana roto" not in html


def test_ca1_el_listado_de_tickets_tambien_muestra_solo_los_propios(funcionario):
    crear_ticket(FUNCIONARIO, titulo="Cuenta de correo bloqueada")
    crear_ticket(FUNCIONARIA_2, titulo="Escáner sin conexión")
    html = _html(funcionario.get("/tickets"))
    assert "Cuenta de correo bloqueada" in html
    assert "Escáner sin conexión" not in html


def test_ca1_mis_solicitudes_muestra_identificador_titulo_categoria_prioridad_estado_y_fecha(funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Router sin conexión", prioridad="alta", estado="en_progreso", categoria="Redes e Internet")
    html = _html(funcionario.get("/dashboard"))
    fecha = appmod.fmt_date(sql_uno("SELECT creado_en FROM v_tickets WHERE id = %s", (tid,))["creado_en"])
    for esperado in (f"#{tid}", "Router sin conexión", "Redes e Internet", "Alta", "En progreso", fecha):
        assert esperado in html, f"falta '{esperado}' en Mis solicitudes"


def test_ca1_el_listado_de_tickets_muestra_la_fecha_de_creacion(funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Software de planillas no abre")
    html = _html(funcionario.get("/tickets"))
    fecha = appmod.fmt_date(sql_uno("SELECT creado_en FROM v_tickets WHERE id = %s", (tid,))["creado_en"])
    assert fecha in html


def test_el_acceso_sin_sesion_redirige_al_inicio_de_sesion(client):
    r = client.get("/dashboard")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


# ------------------------------------------------------------------ CA2
def test_ca2_sin_tickets_muestra_estado_vacio_e_invita_a_crear(funcionaria2):
    html = _html(funcionaria2.get("/dashboard"))
    assert "Aún no has creado ninguna solicitud" in html
    assert 'href="/tickets/nuevo"' in html


# ------------------------------------------------------------------ CA3
def test_ca3_mis_solicitudes_ordena_del_mas_reciente_al_mas_antiguo(funcionario):
    ahora = datetime.now(timezone.utc)
    crear_ticket(FUNCIONARIO, titulo="Ticket intermedio", creado_en=ahora - timedelta(days=2))
    crear_ticket(FUNCIONARIO, titulo="Ticket reciente", creado_en=ahora)
    crear_ticket(FUNCIONARIO, titulo="Ticket antiguo", creado_en=ahora - timedelta(days=5))
    html = _html(funcionario.get("/dashboard"))
    assert html.index("Ticket reciente") < html.index("Ticket intermedio") < html.index("Ticket antiguo")


def test_ca3_el_listado_de_tickets_tambien_ordena_del_mas_reciente_al_mas_antiguo(funcionario):
    ahora = datetime.now(timezone.utc)
    crear_ticket(FUNCIONARIO, titulo="Caso viejo", creado_en=ahora - timedelta(days=9))
    crear_ticket(FUNCIONARIO, titulo="Caso nuevo", creado_en=ahora)
    html = _html(funcionario.get("/tickets"))
    assert html.index("Caso nuevo") < html.index("Caso viejo")


def test_ca3_con_la_misma_fecha_el_ticket_creado_despues_aparece_primero(funcionario):
    momento = datetime.now(timezone.utc)
    crear_ticket(FUNCIONARIO, titulo="Primero creado", creado_en=momento)
    crear_ticket(FUNCIONARIO, titulo="Segundo creado", creado_en=momento)
    html = _html(funcionario.get("/dashboard"))
    assert html.index("Segundo creado") < html.index("Primero creado")
