"""HU-21 — Administrar categorías de soporte (E5). Criterios CA1 a CA3."""
import pytest

from tests.conftest import FUNCIONARIO, sql, sql_uno

pytestmark = pytest.mark.hu21


def _crear_categoria(cliente, nombre):
    return cliente.post("/admin/categorias/nueva", data={"nombre": nombre})


def test_ca1_crear_categoria_valida_la_deja_disponible(admin, funcionario):
    """CA1: nombre válido y no duplicado -> la categoría queda disponible para clasificación y consulta."""
    r = _crear_categoria(admin, "Impresoras")
    assert r.status_code == 302 and r.headers["Location"].endswith("/admin/categorias")
    cat = sql_uno("SELECT * FROM categorias WHERE nombre = %s", ("Impresoras",))
    assert cat["activa"] is True
    assert "Impresoras" in admin.get("/admin/categorias").get_data(as_text=True)          # consulta
    assert "Impresoras" in funcionario.get("/tickets/nuevo").get_data(as_text=True)       # disponible al crear tickets
    t = funcionario.post("/tickets/nuevo", data={"titulo": "Toner agotado", "descripcion": "Sin toner",
                                                  "categoria_id": str(cat["id"]), "prioridad": "baja"})
    assert t.status_code == 302                                                           # clasificación con la nueva categoría
    assert sql_uno("SELECT categoria_id FROM v_tickets")["categoria_id"] == cat["id"]


def test_ca2_desactivar_categoria_no_la_ofrece_a_nuevos_tickets(admin, funcionario):
    """CA2: categoría desactivada deja de estar disponible para nuevos tickets."""
    cat = sql_uno("SELECT id FROM categorias WHERE nombre = %s", ("Otros",))
    assert "Otros" in funcionario.get("/tickets/nuevo").get_data(as_text=True)
    admin.post(f"/admin/categorias/{cat['id']}/estado")
    assert sql_uno("SELECT activa FROM categorias WHERE id = %s", (cat["id"],))["activa"] is False
    opciones = funcionario.get("/tickets/nuevo").get_data(as_text=True)
    assert f'value="{cat["id"]}"' not in opciones


def test_ca2_desactivar_no_elimina_la_referencia_en_tickets_historicos(admin, funcionario):
    cat = sql_uno("SELECT id FROM categorias WHERE nombre = %s", ("Hardware",))
    t = funcionario.post("/tickets/nuevo", data={"titulo": "Teclado dañado", "descripcion": "No responde",
                                                  "categoria_id": str(cat["id"]), "prioridad": "media"})
    ticket_id = int(t.headers["Location"].rsplit("/", 1)[1])
    admin.post(f"/admin/categorias/{cat['id']}/estado")                                   # se desactiva
    assert sql_uno("SELECT categoria_id FROM v_tickets WHERE id = %s", (ticket_id,))["categoria_id"] == cat["id"]
    detalle = funcionario.get(f"/tickets/{ticket_id}")
    assert detalle.status_code == 200 and "Hardware" in detalle.get_data(as_text=True)
    assert sql_uno("SELECT 1 AS n FROM categorias WHERE id = %s", (cat["id"],)) is not None   # sigue existiendo


def test_ca2_reactivar_la_categoria_la_vuelve_a_ofrecer(admin, funcionario):
    cat = sql_uno("SELECT id FROM categorias WHERE nombre = %s", ("Software",))
    admin.post(f"/admin/categorias/{cat['id']}/estado")
    admin.post(f"/admin/categorias/{cat['id']}/estado")
    assert f'value="{cat["id"]}"' in funcionario.get("/tickets/nuevo").get_data(as_text=True)


@pytest.mark.parametrize("nombre", ["Hardware", "hardware", "  HARDWARE  "])
def test_ca3_categoria_duplicada_se_rechaza(admin, nombre):
    """CA3: categoría duplicada (incluso con otra capitalización) -> se rechaza con mensaje."""
    antes = len(sql("SELECT 1 FROM categorias"))
    r = _crear_categoria(admin, nombre)
    assert r.status_code == 200 and "Ya existe una categoría con ese nombre" in r.get_data(as_text=True)
    assert len(sql("SELECT 1 FROM categorias")) == antes


@pytest.mark.parametrize("nombre", ["", "    "])
def test_ca3_categoria_sin_nombre_se_rechaza(admin, nombre):
    """CA3: categoría sin nombre -> se rechaza y muestra mensaje de validación."""
    antes = len(sql("SELECT 1 FROM categorias"))
    r = _crear_categoria(admin, nombre)
    assert r.status_code == 200 and "El nombre de la categoría es obligatorio" in r.get_data(as_text=True)
    assert len(sql("SELECT 1 FROM categorias")) == antes


def test_solo_el_administrador_gestiona_categorias(funcionario, tecnico, client):
    for ruta in ("/admin/categorias", "/admin/categorias/nueva"):
        assert funcionario.get(ruta).status_code == 403
        assert tecnico.get(ruta).status_code == 403
        assert client.get(ruta).status_code == 302
    assert funcionario.post("/admin/categorias/1/estado").status_code == 403
