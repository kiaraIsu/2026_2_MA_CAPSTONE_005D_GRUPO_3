"""Pruebas de la normalización de la base de datos (catálogos de roles, estados, prioridades y direcciones)
y de la migración desde el esquema anterior."""
import os

import psycopg2
import pytest

import app as appmod
import database as db
from tests.conftest import FUNCIONARIO, TECNICO, crear_ticket, sql, sql_exec, sql_uno, usuario_id

pytestmark = pytest.mark.normalizacion
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# =================================================================== estructura
def test_los_catalogos_tienen_los_valores_esperados(app):
    assert [r["codigo"] for r in sql("SELECT codigo FROM roles ORDER BY id")] == ["usuario", "tecnico", "administrador"]
    assert [e["codigo"] for e in sql("SELECT codigo FROM estados ORDER BY orden")] == ["pendiente", "en_progreso", "en_revision", "resuelto", "cerrado"]
    assert [p["codigo"] for p in sql("SELECT codigo FROM prioridades ORDER BY orden")] == ["alta", "media", "baja"]


def test_los_catalogos_coinciden_con_las_etiquetas_de_la_aplicacion(app):
    assert {e["codigo"]: e["nombre"] for e in sql("SELECT codigo, nombre FROM estados")} == appmod.ESTADOS_LABEL
    assert {p["codigo"]: p["nombre"] for p in sql("SELECT codigo, nombre FROM prioridades")} == appmod.PRIORIDAD_LABEL
    assert list(appmod.TRANSICIONES_PERMITIDAS) == [e["codigo"] for e in sql("SELECT codigo FROM estados ORDER BY orden")]


def _columnas(tabla):
    return {c["column_name"] for c in sql("SELECT column_name FROM information_schema.columns WHERE table_name = %s", (tabla,))}


def test_usuarios_y_tickets_ya_no_guardan_textos_repetidos(app):
    assert {"rol", "direccion"}.isdisjoint(_columnas("usuarios")) and {"rol_id", "direccion_id"} <= _columnas("usuarios")
    assert {"estado", "prioridad"}.isdisjoint(_columnas("tickets")) and {"estado_id", "prioridad_id"} <= _columnas("tickets")


def test_las_referencias_son_claves_foraneas(app):
    fks = {(f["tabla"], f["columna"], f["referencia"]) for f in sql(
        "SELECT cl.relname AS tabla, a.attname AS columna, rf.relname AS referencia FROM pg_constraint c "
        "JOIN pg_class cl ON cl.oid = c.conrelid JOIN pg_class rf ON rf.oid = c.confrelid "
        "JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY (c.conkey) WHERE c.contype = 'f'")}
    for esperado in (("usuarios", "rol_id", "roles"), ("usuarios", "direccion_id", "direcciones"), ("tickets", "estado_id", "estados"), ("tickets", "prioridad_id", "prioridades")):
        assert esperado in fks


def test_no_se_puede_guardar_un_ticket_con_estado_o_prioridad_inexistente(app):
    tid = crear_ticket(FUNCIONARIO)
    with pytest.raises(psycopg2.IntegrityError):
        sql_exec("UPDATE tickets SET estado_id = 999 WHERE id = %s", (tid,))
    with pytest.raises(psycopg2.IntegrityError):
        sql_exec("UPDATE tickets SET prioridad_id = 999 WHERE id = %s", (tid,))


def test_no_se_puede_guardar_un_usuario_con_rol_inexistente(app):
    with pytest.raises(psycopg2.IntegrityError):
        sql_exec("UPDATE usuarios SET rol_id = 999 WHERE email = %s", (FUNCIONARIO[0],))


def test_no_se_puede_borrar_un_estado_que_esta_en_uso(app):
    crear_ticket(FUNCIONARIO, estado="pendiente")
    with pytest.raises(psycopg2.IntegrityError):
        sql_exec("DELETE FROM estados WHERE codigo = 'pendiente'")


def test_iniciar_la_base_dos_veces_no_duplica_los_catalogos(app):
    db.init_db()
    assert (sql_uno("SELECT COUNT(*) AS n FROM roles")["n"], sql_uno("SELECT COUNT(*) AS n FROM estados")["n"], sql_uno("SELECT COUNT(*) AS n FROM prioridades")["n"]) == (3, 5, 3)


# =================================================================== direcciones
def _registrar(admin, nombre, email, direccion):
    admin.post("/admin/usuarios/nuevo", data={"nombre": nombre, "email": email, "password": "clave123", "rol": "usuario", "direccion": direccion})


def test_una_direccion_se_guarda_una_sola_vez_aunque_cambien_mayusculas_y_espacios(admin):
    _registrar(admin, "Uno", "uno@municipalidad.cl", "Tránsito")
    _registrar(admin, "Dos", "dos@municipalidad.cl", "  tránsito ")
    assert sql_uno("SELECT COUNT(*) AS n FROM direcciones WHERE lower(nombre) = 'tránsito'")["n"] == 1
    ids = {u["direccion_id"] for u in sql("SELECT direccion_id FROM usuarios WHERE email IN ('uno@municipalidad.cl', 'dos@municipalidad.cl')")}
    assert len(ids) == 1 and None not in ids


def test_un_usuario_sin_direccion_queda_sin_referencia(admin):
    _registrar(admin, "Sin dirección", "sindir@municipalidad.cl", "   ")
    assert sql_uno("SELECT direccion_id FROM usuarios WHERE email = 'sindir@municipalidad.cl'")["direccion_id"] is None
    assert sql_uno("SELECT direccion FROM v_usuarios WHERE email = 'sindir@municipalidad.cl'")["direccion"] is None


def test_cambiar_el_nombre_de_una_direccion_se_refleja_en_todos_sus_usuarios(admin):
    _registrar(admin, "Uno", "uno@municipalidad.cl", "Tránsito")
    _registrar(admin, "Dos", "dos@municipalidad.cl", "tránsito")
    sql_exec("UPDATE direcciones SET nombre = 'Dirección de Tránsito' WHERE lower(nombre) = 'tránsito'")
    nombres = {u["direccion"] for u in sql("SELECT direccion FROM v_usuarios WHERE email IN ('uno@municipalidad.cl', 'dos@municipalidad.cl')")}
    assert nombres == {"Dirección de Tránsito"}


def test_las_direcciones_de_demostracion_se_crean_una_sola_vez(app):
    assert sql_uno("SELECT COUNT(*) AS n FROM direcciones")["n"] == 3


def test_el_formulario_de_creacion_de_cuentas_sugiere_las_direcciones_existentes(admin):
    html = admin.get("/admin/usuarios/nuevo").get_data(as_text=True)
    assert 'list="lista_direcciones"' in html and "DIDECO" in html


# =================================================================== vistas
def test_las_vistas_muestran_codigos_y_nombres_legibles(app):
    u = sql_uno("SELECT rol, rol_nombre, direccion FROM v_usuarios WHERE email = %s", (FUNCIONARIO[0],))
    assert (u["rol"], u["rol_nombre"], u["direccion"]) == ("usuario", "Funcionario", "DIDECO")
    tid = crear_ticket(FUNCIONARIO, prioridad="alta", estado="en_revision", tecnico=TECNICO)
    t = sql_uno("SELECT estado, prioridad, estado_id, prioridad_id FROM v_tickets WHERE id = %s", (tid,))
    assert (t["estado"], t["prioridad"]) == ("en_revision", "alta")
    assert t["estado_id"] == sql_uno("SELECT id FROM estados WHERE codigo = 'en_revision'")["id"]


# =================================================================== migración desde el esquema anterior
BASE_MIGRACION = "ticketia_migracion_test"


@pytest.fixture()
def base_antigua():
    """Crea una base con el esquema ANTERIOR (texto en rol, dirección, estado y prioridad) y algunos datos."""
    adm = psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"), dbname="postgres",
                           user=os.environ.get("DB_USER", "ticketia_user"), password=os.environ.get("DB_PASSWORD", "ticketia_pass"))
    adm.autocommit = True
    with adm.cursor() as cur:
        cur.execute(f'DROP DATABASE IF EXISTS "{BASE_MIGRACION}"')
        cur.execute(f'CREATE DATABASE "{BASE_MIGRACION}"')
    adm.close()
    conn = psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"), dbname=BASE_MIGRACION,
                            user=os.environ.get("DB_USER", "ticketia_user"), password=os.environ.get("DB_PASSWORD", "ticketia_pass"))
    with conn, conn.cursor() as cur:
        cur.execute(ESQUEMA_ANTERIOR)
        cur.execute("INSERT INTO categorias (nombre) VALUES ('Hardware')")
        for nombre, mail, rol, direc in (("Admin", "a@x.cl", "administrador", "Informática"), ("Tec", "t@x.cl", "tecnico", "informática "), ("Uno", "u1@x.cl", "usuario", "DIDECO"),
                                         ("Dos", "u2@x.cl", "usuario", " dideco"), ("Tres", "u3@x.cl", "usuario", None), ("Cuatro", "u4@x.cl", "usuario", "")):
            cur.execute("INSERT INTO usuarios (nombre, email, password_hash, rol, direccion, creado_en) VALUES (%s, %s, 'h', %s, %s, NOW())", (nombre, mail, rol, direc))
        for i, (est, pri) in enumerate((("pendiente", "alta"), ("en_progreso", "media"), ("resuelto", "baja"), ("cerrado", "alta")), start=1):
            cur.execute("INSERT INTO tickets (titulo, descripcion, categoria_id, prioridad, estado, usuario_id, tecnico_id, creado_en, actualizado_en) "
                        "VALUES (%s, 'd', 1, %s, %s, 3, 2, NOW(), NOW())", (f"Ticket {i}", pri, est))
    yield conn
    conn.close()
    adm = psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"), dbname="postgres",
                           user=os.environ.get("DB_USER", "ticketia_user"), password=os.environ.get("DB_PASSWORD", "ticketia_pass"))
    adm.autocommit = True
    with adm.cursor() as cur:
        cur.execute(f'DROP DATABASE IF EXISTS "{BASE_MIGRACION}"')
    adm.close()


ESQUEMA_ANTERIOR = open(os.path.join(RAIZ, "tests", "esquema_anterior.sql"), encoding="utf-8").read()
SCRIPT = open(os.path.join(RAIZ, "migraciones", "001_normalizar_catalogos.sql"), encoding="utf-8").read()


def _migrar(conn):
    with conn, conn.cursor() as cur:
        cur.execute(SCRIPT)


def _fetch(conn, consulta):
    with conn.cursor() as cur:
        cur.execute(consulta)
        return cur.fetchall()


def test_la_migracion_conserva_los_datos_y_normaliza_el_esquema(base_antigua):
    _migrar(base_antigua)
    assert _fetch(base_antigua, "SELECT rol, COUNT(*) FROM v_usuarios GROUP BY rol ORDER BY rol") == [("administrador", 1), ("tecnico", 1), ("usuario", 4)]
    assert _fetch(base_antigua, "SELECT titulo, estado, prioridad FROM v_tickets ORDER BY id") == [("Ticket 1", "pendiente", "alta"), ("Ticket 2", "en_progreso", "media"), ("Ticket 3", "resuelto", "baja"), ("Ticket 4", "cerrado", "alta")]
    columnas = {c[0] for c in _fetch(base_antigua, "SELECT column_name FROM information_schema.columns WHERE table_name IN ('usuarios', 'tickets')")}
    assert {"rol", "direccion", "estado", "prioridad"}.isdisjoint(columnas)


def test_la_migracion_une_las_direcciones_repetidas_y_respeta_las_vacias(base_antigua):
    _migrar(base_antigua)
    assert sorted(d[0].lower() for d in _fetch(base_antigua, "SELECT nombre FROM direcciones")) == ["didecO".lower(), "informática"]
    asignadas = dict(_fetch(base_antigua, "SELECT email, direccion FROM v_usuarios"))
    assert asignadas["u3@x.cl"] is None and asignadas["u4@x.cl"] is None
    assert asignadas["u1@x.cl"].lower() == asignadas["u2@x.cl"].lower() == "dideco"
    assert _fetch(base_antigua, "SELECT COUNT(DISTINCT direccion_id) FROM usuarios WHERE email IN ('u1@x.cl', 'u2@x.cl')") == [(1,)]


def test_la_migracion_conserva_las_relaciones_y_se_puede_repetir(base_antigua):
    _migrar(base_antigua)
    antes = _fetch(base_antigua, "SELECT id, usuario_id, tecnico_id, estado_id, prioridad_id FROM tickets ORDER BY id")
    _migrar(base_antigua)                                   # segunda ejecución: no cambia nada
    assert _fetch(base_antigua, "SELECT id, usuario_id, tecnico_id, estado_id, prioridad_id FROM tickets ORDER BY id") == antes
    assert _fetch(base_antigua, "SELECT COUNT(*) FROM roles")[0][0] == 3 and _fetch(base_antigua, "SELECT COUNT(*) FROM direcciones")[0][0] == 2
    assert all(t[1] == 3 and t[2] == 2 for t in antes)
