"""HU-20 — Solicitar reapertura de un ticket resuelto (E2). Criterios CA1 a CA3."""
import re

import pytest

from tests.conftest import (FUNCIONARIO, TECNICO, crear_ticket, estado_de, historial_de, sql_uno, tecnico_de, usuario_id)

pytestmark = pytest.mark.hu20


def _resuelto(solicitante=FUNCIONARIO, tecnico=TECNICO):
    return crear_ticket(solicitante, titulo="Impresora sin tinta", estado="resuelto", tecnico=tecnico, solucion="Se cambió el cartucho")


def _reabrir(cliente, ticket_id, motivo="El problema volvió a ocurrir"):
    return cliente.post(f"/tickets/{ticket_id}/solicitar-reapertura", data={"motivo": motivo})


def _acciones(ticket_id):
    return [h["accion"] for h in historial_de(ticket_id)]


# ------------------------------------------------------------------ CA1
def test_ca1_la_solicitud_reabre_el_ticket_y_lo_deja_en_progreso(funcionario):
    tid = _resuelto()
    assert _reabrir(funcionario, tid).status_code == 302
    assert estado_de(tid) == "en_progreso"


def test_ca1_se_conserva_el_tecnico_asignado(funcionario):
    tid = _resuelto()
    antes = tecnico_de(tid)
    _reabrir(funcionario, tid)
    assert tecnico_de(tid) == antes == usuario_id(TECNICO)


@pytest.mark.parametrize("motivo", ["", "   ", "\n\t "])
def test_ca1_el_motivo_es_obligatorio(funcionario, motivo):
    tid = _resuelto()
    r = _reabrir(funcionario, tid, motivo)
    assert r.status_code == 302
    assert estado_de(tid) == "resuelto"
    assert not any("eabri" in a for a in _acciones(tid))


def test_ca1_se_informa_que_falta_el_motivo(funcionario):
    tid = _resuelto()
    r = funcionario.post(f"/tickets/{tid}/solicitar-reapertura", data={"motivo": "  "}, follow_redirects=True)
    assert "motivo" in r.get_data(as_text=True).lower()


def test_ca1_el_solicitante_ve_la_opcion_de_reabrir_en_un_ticket_resuelto(funcionario):
    tid = _resuelto()
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "Motivo de la reapertura" in html and f"/tickets/{tid}/solicitar-reapertura" in html


def test_ca1_la_atencion_continua_sin_aprobacion_previa(funcionario, tecnico):
    tid = _resuelto()
    _reabrir(funcionario, tid)
    assert "Solicitud de reapertura" not in tecnico.get(f"/tickets/{tid}").get_data(as_text=True)
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "en_revision"})
    assert estado_de(tid) == "en_revision"


def test_ca1_no_queda_ninguna_solicitud_pendiente(funcionario):
    tid = _resuelto()
    _reabrir(funcionario, tid)
    assert not sql_uno("SELECT reapertura_solicitada FROM tickets WHERE id = %s", (tid,))["reapertura_solicitada"]


# ------------------------------------------------------------------ CA2
@pytest.mark.parametrize("estado", ["pendiente", "en_progreso", "en_revision", "cerrado"])
def test_ca2_un_ticket_que_no_esta_resuelto_no_se_reabre(funcionario, estado):
    tid = crear_ticket(FUNCIONARIO, titulo="Impresora sin tinta", estado=estado, tecnico=TECNICO)
    r = _reabrir(funcionario, tid)
    assert r.status_code == 302
    assert estado_de(tid) == estado
    assert not any("eabri" in a for a in _acciones(tid))


@pytest.mark.parametrize("estado", ["pendiente", "en_progreso", "en_revision", "cerrado"])
def test_ca2_la_opcion_no_se_ofrece_si_no_esta_resuelto(funcionario, estado):
    tid = crear_ticket(FUNCIONARIO, titulo="Impresora sin tinta", estado=estado, tecnico=TECNICO)
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "Motivo de la reapertura" not in html and f"/tickets/{tid}/solicitar-reapertura" not in html


def test_ca2_se_informa_por_que_no_se_puede_reabrir(funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Impresora sin tinta", estado="en_progreso", tecnico=TECNICO)
    r = funcionario.post(f"/tickets/{tid}/solicitar-reapertura", data={"motivo": "Volvió"}, follow_redirects=True)
    assert "resuelto" in r.get_data(as_text=True).lower()


def test_ca2_un_ticket_de_otro_funcionario_no_se_puede_reabrir(funcionaria2):
    tid = _resuelto()
    assert _reabrir(funcionaria2, tid).status_code == 403
    assert estado_de(tid) == "resuelto"


@pytest.mark.parametrize("rol", ["tecnico", "admin"])
def test_ca2_solo_el_funcionario_solicita_la_reapertura(request, rol):
    cliente = request.getfixturevalue(rol)
    tid = _resuelto()
    assert _reabrir(cliente, tid).status_code == 403
    assert estado_de(tid) == "resuelto"


def test_ca2_sin_sesion_se_pide_iniciar_sesion(client):
    tid = _resuelto()
    r = _reabrir(client, tid)
    assert r.status_code == 302 and "/login" in r.headers["Location"]
    assert estado_de(tid) == "resuelto"


def test_ca2_un_ticket_inexistente_responde_404(funcionario):
    assert _reabrir(funcionario, 99999).status_code == 404


# ------------------------------------------------------------------ CA3
def test_ca3_el_historial_registra_motivo_fecha_y_usuario(funcionario):
    tid = _resuelto()
    _reabrir(funcionario, tid, "La impresora volvió a fallar")
    eventos = [h for h in historial_de(tid) if "La impresora volvió a fallar" in h["accion"]]
    assert len(eventos) == 1
    assert eventos[0]["usuario_id"] == usuario_id(FUNCIONARIO) and eventos[0]["creado_en"] is not None
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    historial = html[html.index("Historial"):]
    assert "La impresora volvió a fallar" in historial and "Pedro Fuentes" in historial
    assert re.search(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}", historial)


def test_ca3_queda_registrado_el_cambio_de_estado(funcionario):
    tid = _resuelto()
    _reabrir(funcionario, tid)
    assert any("de 'Resuelto' a 'En progreso'" in a for a in _acciones(tid))


def test_ca3_cada_reapertura_queda_registrada(funcionario, tecnico):
    tid = _resuelto()
    _reabrir(funcionario, tid, "Primera falla")
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "resuelto"})
    _reabrir(funcionario, tid, "Segunda falla")
    acciones = _acciones(tid)
    assert any("Primera falla" in a for a in acciones) and any("Segunda falla" in a for a in acciones)
