"""HU-07 — Visualizar tickets asignados (E2). Criterios CA1 a CA3."""
import pytest

from tests.conftest import FUNCIONARIO, TECNICO, TECNICO_2, crear_ticket

pytestmark = pytest.mark.hu07


def _html(r):
    return r.get_data(as_text=True)


# ------------------------------------------------------------------ CA1
def test_ca1_la_bandeja_del_tecnico_muestra_solo_sus_tickets_asignados(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Caso de Kiara uno", tecnico=TECNICO, estado="en_progreso")
    crear_ticket(FUNCIONARIO, titulo="Caso de Kiara dos", tecnico=TECNICO, estado="en_revision")
    crear_ticket(FUNCIONARIO, titulo="Caso de Marcela", tecnico=TECNICO_2, estado="en_progreso")
    html = _html(tecnico.get("/dashboard"))
    assert "Caso de Kiara uno" in html and "Caso de Kiara dos" in html
    assert "Caso de Marcela" not in html


def test_ca1_la_bandeja_no_muestra_tickets_sin_asignar(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Ticket sin responsable")
    assert "Ticket sin responsable" not in _html(tecnico.get("/dashboard"))


def test_ca1_el_listado_de_tickets_del_tecnico_tambien_muestra_solo_los_suyos(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Es de Kiara", tecnico=TECNICO, estado="en_progreso")
    crear_ticket(FUNCIONARIO, titulo="Es de Marcela", tecnico=TECNICO_2, estado="en_progreso")
    html = _html(tecnico.get("/tickets"))
    assert "Es de Kiara" in html and "Es de Marcela" not in html


def test_ca1_cada_tecnico_ve_unicamente_lo_suyo(tecnico2):
    crear_ticket(FUNCIONARIO, titulo="Es de Kiara", tecnico=TECNICO, estado="en_progreso")
    crear_ticket(FUNCIONARIO, titulo="Es de Marcela", tecnico=TECNICO_2, estado="en_progreso")
    html = _html(tecnico2.get("/dashboard"))
    assert "Es de Marcela" in html and "Es de Kiara" not in html


# ------------------------------------------------------------------ CA2
def test_ca2_los_tickets_de_prioridad_alta_quedan_identificados(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Urgente servidor caído", prioridad="alta", tecnico=TECNICO, estado="en_progreso")
    html = _html(tecnico.get("/dashboard"))
    assert "badge-prioridad-alta" in html and "Alta" in html


def test_ca2_los_tickets_de_prioridad_alta_aparecen_primero(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Prioridad baja", prioridad="baja", tecnico=TECNICO, estado="en_progreso")
    crear_ticket(FUNCIONARIO, titulo="Prioridad media", prioridad="media", tecnico=TECNICO, estado="en_progreso")
    crear_ticket(FUNCIONARIO, titulo="Prioridad alta", prioridad="alta", tecnico=TECNICO, estado="en_progreso")
    html = _html(tecnico.get("/dashboard"))
    assert html.index("Prioridad alta") < html.index("Prioridad media") < html.index("Prioridad baja")


# ------------------------------------------------------------------ CA3
def test_ca3_un_tecnico_sin_tickets_asignados_recibe_un_aviso(tecnico):
    html = _html(tecnico.get("/dashboard"))
    assert "No tienes solicitudes pendientes asignadas" in html


def test_ca3_el_aviso_no_aparece_si_el_tecnico_tiene_tickets(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Con trabajo", tecnico=TECNICO, estado="en_progreso")
    assert "No tienes solicitudes pendientes asignadas" not in _html(tecnico.get("/dashboard"))
