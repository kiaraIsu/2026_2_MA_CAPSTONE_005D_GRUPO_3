"""HU-18 — Evaluar la atención recibida (E5). Criterios CA1 a CA3."""
import pytest

from tests.conftest import (FUNCIONARIO, TECNICO, crear_ticket, historial_de, sql, usuario_id)

pytestmark = pytest.mark.hu18


def _evaluar(cliente, tid, puntaje="5", comentario="Muy buena atención"):
    return cliente.post(f"/tickets/{tid}/evaluar", data={"puntaje": puntaje, "comentario": comentario})


def _filas(tid):
    return sql("SELECT puntaje, comentario FROM evaluaciones WHERE ticket_id = %s", (tid,))


def _ticket(estado="resuelto"):
    return crear_ticket(FUNCIONARIO, titulo="Impresora sin tinta", estado=estado, tecnico=TECNICO, solucion="Se cambió el cartucho")


# ------------------------------------------------------------------ CA1
@pytest.mark.parametrize("estado", ["resuelto", "cerrado"])
def test_ca1_el_funcionario_ve_el_formulario_de_evaluacion(funcionario, estado):
    tid = _ticket(estado)
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "Evaluar atención" in html and f"/tickets/{tid}/evaluar" in html and 'name="puntaje"' in html


@pytest.mark.parametrize("puntaje", ["1", "2", "3", "4", "5"])
def test_ca1_se_registra_una_calificacion_de_1_a_5(funcionario, puntaje):
    tid = _ticket()
    assert _evaluar(funcionario, tid, puntaje).status_code == 302
    assert [(f["puntaje"]) for f in _filas(tid)] == [int(puntaje)]


def test_ca1_se_guarda_el_comentario(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "4", "Resolvieron rápido")
    assert _filas(tid)[0]["comentario"] == "Resolvieron rápido"


def test_ca1_el_comentario_es_opcional(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "3", "")
    f = _filas(tid)
    assert len(f) == 1 and not f[0]["comentario"]


def test_ca1_se_puede_evaluar_un_ticket_cerrado(funcionario):
    tid = _ticket("cerrado")
    _evaluar(funcionario, tid, "5")
    assert len(_filas(tid)) == 1


@pytest.mark.parametrize("puntaje", ["0", "6", "-1", "abc", "", "3.5", "99"])
def test_ca1_una_calificacion_fuera_de_rango_se_rechaza(funcionario, puntaje):
    tid = _ticket()
    r = _evaluar(funcionario, tid, puntaje)
    assert r.status_code == 302 and _filas(tid) == []


def test_ca1_se_informa_cuando_la_calificacion_no_es_valida(funcionario):
    tid = _ticket()
    r = funcionario.post(f"/tickets/{tid}/evaluar", data={"puntaje": "9"}, follow_redirects=True)
    assert "entre 1 y 5" in r.get_data(as_text=True)


def test_ca1_la_evaluacion_se_muestra_en_el_detalle(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "4", "Muy buena")
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "4/5" in html and "Muy buena" in html


def test_ca1_la_evaluacion_queda_en_el_historial(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "4")
    evento = [h for h in historial_de(tid) if "Evaluó la atención" in h["accion"]]
    assert len(evento) == 1 and "4/5" in evento[0]["accion"] and evento[0]["usuario_id"] == usuario_id(FUNCIONARIO)


def test_ca1_solo_el_solicitante_puede_evaluar(funcionaria2, tecnico, admin):
    tid = _ticket()
    for cliente in (funcionaria2, tecnico, admin):
        assert _evaluar(cliente, tid).status_code == 403
    assert _filas(tid) == []


def test_ca1_sin_sesion_se_pide_iniciar_sesion(client):
    tid = _ticket()
    r = _evaluar(client, tid)
    assert r.status_code == 302 and "/login" in r.headers["Location"] and _filas(tid) == []


def test_ca1_evaluar_un_ticket_inexistente_responde_404(funcionario):
    assert _evaluar(funcionario, 99999).status_code == 404


def test_ca1_un_comentario_con_html_se_muestra_como_texto(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "5", "<script>alert(1)</script>")
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "<script>alert(1)</script>" not in html


# ------------------------------------------------------------------ CA2
@pytest.mark.parametrize("estado", ["pendiente", "en_progreso", "en_revision"])
def test_ca2_antes_de_resolverse_no_se_ofrece_la_evaluacion(funcionario, estado):
    tid = _ticket(estado)
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "Evaluar atención" not in html and f"/tickets/{tid}/evaluar" not in html


@pytest.mark.parametrize("estado", ["pendiente", "en_progreso", "en_revision"])
def test_ca2_antes_de_resolverse_tampoco_se_acepta_la_evaluacion(funcionario, estado):
    tid = _ticket(estado)
    r = _evaluar(funcionario, tid)
    assert r.status_code == 302 and _filas(tid) == []


def test_ca2_se_informa_por_que_no_se_puede_evaluar(funcionario):
    tid = _ticket("en_progreso")
    r = funcionario.post(f"/tickets/{tid}/evaluar", data={"puntaje": "5"}, follow_redirects=True)
    assert "resueltos o cerrados" in r.get_data(as_text=True)


def test_ca2_al_reabrir_un_ticket_deja_de_ofrecerse_la_evaluacion(funcionario):
    tid = _ticket()
    funcionario.post(f"/tickets/{tid}/solicitar-reapertura", data={"motivo": "Volvió a fallar"})
    assert "Evaluar atención" not in funcionario.get(f"/tickets/{tid}").get_data(as_text=True)


# ------------------------------------------------------------------ CA3
def test_ca3_volver_a_evaluar_actualiza_la_evaluacion_existente(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "2", "Regular")
    _evaluar(funcionario, tid, "5", "Mejoró")
    f = _filas(tid)
    assert len(f) == 1 and f[0]["puntaje"] == 5 and f[0]["comentario"] == "Mejoró"


def test_ca3_no_se_crean_registros_duplicados(funcionario):
    tid = _ticket()
    for puntaje in ("1", "2", "3", "4", "5"):
        _evaluar(funcionario, tid, puntaje)
    assert len(_filas(tid)) == 1


def test_ca3_la_pantalla_permite_modificar_la_evaluacion(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "3", "Buena")
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert f"/tickets/{tid}/evaluar" in html and "Actualizar evaluación" in html


def test_ca3_el_formulario_de_modificacion_muestra_la_calificacion_actual(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "3", "Buena")
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert 'value="3" selected' in html and "Buena" in html


def test_ca3_cada_cambio_de_evaluacion_queda_en_el_historial(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "2")
    _evaluar(funcionario, tid, "5")
    eventos = [h["accion"] for h in historial_de(tid) if "Evaluó la atención" in h["accion"]]
    assert len(eventos) == 2 and "5/5" in eventos[1]


def test_ca3_una_evaluacion_invalida_no_pisa_la_existente(funcionario):
    tid = _ticket()
    _evaluar(funcionario, tid, "4", "Buena")
    _evaluar(funcionario, tid, "9", "Cambio inválido")
    f = _filas(tid)
    assert len(f) == 1 and f[0]["puntaje"] == 4 and f[0]["comentario"] == "Buena"


def test_ca3_cada_ticket_tiene_su_propia_evaluacion(funcionario):
    t1, t2 = _ticket(), _ticket("cerrado")
    _evaluar(funcionario, t1, "1")
    _evaluar(funcionario, t2, "5")
    assert _filas(t1)[0]["puntaje"] == 1 and _filas(t2)[0]["puntaje"] == 5
