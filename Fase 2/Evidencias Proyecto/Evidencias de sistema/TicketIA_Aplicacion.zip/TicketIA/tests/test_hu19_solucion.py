"""HU-19 — Registrar solución técnica del ticket (E2). Criterios CA1 a CA3."""
from datetime import datetime, timezone

import pytest

import app as appmod
from tests.conftest import (FUNCIONARIO, TECNICO, crear_ticket, estado_de, historial_de, solucion_de, usuario_id)

pytestmark = pytest.mark.hu19


def _guardar(cliente, ticket_id, texto):
    return cliente.post(f"/tickets/{ticket_id}/solucion", data={"solucion": texto})


def _en_atencion():
    return crear_ticket(FUNCIONARIO, titulo="Equipo no enciende", estado="en_progreso", tecnico=TECNICO)


# ------------------------------------------------------------------ CA1
def test_ca1_el_tecnico_registra_la_solucion_sin_cambiar_el_estado(tecnico):
    tid = _en_atencion()
    r = _guardar(tecnico, tid, "Se reemplazó la fuente de poder")
    assert r.status_code == 302
    assert solucion_de(tid) == "Se reemplazó la fuente de poder"
    assert estado_de(tid) == "en_progreso"


def test_ca1_la_solucion_se_muestra_con_su_autor_y_su_fecha(tecnico):
    tid = _en_atencion()
    _guardar(tecnico, tid, "Se reemplazó la fuente de poder")
    html = tecnico.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "Se reemplazó la fuente de poder" in html
    assert "Registrada por Kiara Isuiza" in html
    assert appmod.fmt_date(datetime.now(timezone.utc)) in html


def test_ca1_el_administrador_tambien_puede_registrar_la_solucion(admin):
    tid = _en_atencion()
    _guardar(admin, tid, "Se actualizó el controlador")
    assert solucion_de(tid) == "Se actualizó el controlador"


def test_ca1_un_funcionario_no_puede_registrar_la_solucion(funcionario):
    tid = _en_atencion()
    r = _guardar(funcionario, tid, "Intento no autorizado")
    assert r.status_code == 403 and solucion_de(tid) is None


def test_ca1_un_tecnico_no_asignado_no_puede_registrar_la_solucion(tecnico2):
    tid = _en_atencion()
    r = _guardar(tecnico2, tid, "Intento no autorizado")
    assert r.status_code == 403 and solucion_de(tid) is None


@pytest.mark.parametrize("texto", ["", "   ", "\n\t "])
def test_ca1_una_solucion_vacia_o_solo_con_espacios_se_rechaza(tecnico, texto):
    tid = _en_atencion()
    _guardar(tecnico, tid, texto)
    assert not (solucion_de(tid) or "").strip() and historial_de(tid) == []


# ------------------------------------------------------------------ CA2
def test_ca2_no_se_puede_resolver_un_ticket_sin_solucion(tecnico):
    tid = _en_atencion()
    r = tecnico.post(f"/tickets/{tid}/estado", data={"estado": "resuelto"}, follow_redirects=True)
    assert estado_de(tid) == "en_progreso"
    assert "Debes registrar la solución" in r.get_data(as_text=True)


def test_ca2_una_solucion_con_solo_espacios_no_permite_resolver(tecnico):
    tid = _en_atencion()
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "resuelto", "solucion": "   "})
    assert estado_de(tid) == "en_progreso"


def test_ca2_se_puede_resolver_enviando_la_solucion_en_el_mismo_cambio(tecnico):
    tid = _en_atencion()
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "resuelto", "solucion": "Se limpió el equipo"})
    assert estado_de(tid) == "resuelto" and solucion_de(tid) == "Se limpió el equipo"


def test_ca2_se_puede_resolver_si_la_solucion_ya_estaba_registrada(tecnico):
    tid = _en_atencion()
    _guardar(tecnico, tid, "Se reinstaló el sistema")
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "resuelto"})
    assert estado_de(tid) == "resuelto"


# ------------------------------------------------------------------ CA3
def test_ca3_el_historial_registra_responsable_y_fecha_de_la_solucion(tecnico):
    tid = _en_atencion()
    antes = datetime.now(timezone.utc)
    _guardar(tecnico, tid, "Se reemplazó la fuente de poder")
    h = historial_de(tid)[-1]
    assert "solución" in h["accion"].lower()
    assert h["usuario_id"] == usuario_id(TECNICO) and h["creado_en"] >= antes.replace(microsecond=0)


def test_ca3_el_historial_distingue_registrar_de_actualizar(tecnico):
    tid = _en_atencion()
    _guardar(tecnico, tid, "Primera versión de la solución")
    _guardar(tecnico, tid, "Versión corregida de la solución")
    acciones = [h["accion"] for h in historial_de(tid)]
    assert any("Registró la solución" in a for a in acciones)
    assert any("Actualizó la solución" in a for a in acciones)
    assert solucion_de(tid) == "Versión corregida de la solución"
