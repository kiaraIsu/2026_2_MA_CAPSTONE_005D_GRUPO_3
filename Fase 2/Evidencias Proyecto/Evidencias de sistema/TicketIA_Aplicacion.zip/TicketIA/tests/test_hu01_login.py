"""HU-01 — Iniciar sesión según rol (E1). Criterios de aceptación CA1 a CA3."""
import pytest

from tests.conftest import (ADMIN, TECNICO, FUNCIONARIO, login, sesion_activa, sql_exec)

pytestmark = pytest.mark.hu01

PANEL_POR_ROL = [
    (ADMIN, "administrador", "Panel del Departamento de Informática"),
    (TECNICO, "tecnico", "Mi tablero de tickets"),
    (FUNCIONARIO, "usuario", "Mis solicitudes de soporte"),
]


@pytest.mark.parametrize("credenciales, rol, titulo_panel", PANEL_POR_ROL)
def test_ca1_credenciales_validas_redirigen_al_panel_del_rol(client, credenciales, rol, titulo_panel):
    """CA1: usuario activo con credenciales válidas -> autentica y redirige al panel de su rol."""
    r = login(client, credenciales)
    assert r.status_code == 302 and r.headers["Location"].endswith("/dashboard")
    assert sesion_activa(client)["rol"] == rol
    panel = client.get("/dashboard")
    assert panel.status_code == 200
    assert titulo_panel in panel.get_data(as_text=True)


def test_ca1_el_correo_no_distingue_mayusculas(client):
    r = login(client, (ADMIN[0].upper(), ADMIN[1]))
    assert r.status_code == 302 and "user_id" in sesion_activa(client)


def test_ca2_contrasena_incorrecta_se_rechaza(client):
    """CA2: contraseña incorrecta -> rechaza el acceso y muestra mensaje genérico."""
    r = login(client, (ADMIN[0], "clave-equivocada"))
    assert r.status_code == 200
    assert "Correo o contraseña incorrectos" in r.get_data(as_text=True)
    assert "user_id" not in sesion_activa(client)


def test_ca2_correo_inexistente_muestra_el_mismo_mensaje_generico(client):
    """El mensaje no revela si el correo existe (misma respuesta que contraseña errónea)."""
    inexistente = login(client, ("no.existe@municipalidad.cl", "lo-que-sea")).get_data(as_text=True)
    errada = login(client, (ADMIN[0], "clave-equivocada")).get_data(as_text=True)
    assert "Correo o contraseña incorrectos" in inexistente
    assert ("Correo o contraseña incorrectos" in inexistente) == ("Correo o contraseña incorrectos" in errada)
    assert "user_id" not in sesion_activa(client)


@pytest.mark.parametrize("email, password", [("", ""), (ADMIN[0], ""), ("", ADMIN[1])])
def test_ca2_campos_vacios_se_rechazan(client, email, password):
    r = login(client, (email, password))
    assert r.status_code == 200
    assert "user_id" not in sesion_activa(client)


def test_ca3_usuario_deshabilitado_no_puede_ingresar(client):
    """CA3: usuario deshabilitado con credenciales correctas -> bloqueado y se informa."""
    sql_exec("UPDATE usuarios SET activo = FALSE WHERE email = %s", (FUNCIONARIO[0],))
    r = login(client, FUNCIONARIO)
    assert r.status_code == 200
    assert "deshabilitada" in r.get_data(as_text=True)
    assert "user_id" not in sesion_activa(client)


def test_acceso_al_panel_requiere_sesion(client):
    r = client.get("/dashboard")
    assert r.status_code == 302 and "/login" in r.headers["Location"]
