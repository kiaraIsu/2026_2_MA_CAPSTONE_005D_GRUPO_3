"""HU-15 — Supervisar tickets con filtros (E4). Criterios CA1 a CA3."""
from datetime import datetime, timedelta, timezone

import pytest

from tests.conftest import (FUNCIONARIA_2, FUNCIONARIO, TECNICO, crear_ticket)

pytestmark = pytest.mark.hu15

AHORA = datetime.now(timezone.utc)


def _escenario():
    crear_ticket(FUNCIONARIO, titulo="Caso Alfa", prioridad="alta", estado="pendiente", creado_en=AHORA - timedelta(hours=4))
    crear_ticket(FUNCIONARIA_2, titulo="Caso Beta", prioridad="media", estado="en_progreso", tecnico=TECNICO, creado_en=AHORA - timedelta(hours=3))
    crear_ticket(FUNCIONARIO, titulo="Caso Gamma", prioridad="alta", estado="en_progreso", tecnico=TECNICO, creado_en=AHORA - timedelta(hours=2))
    crear_ticket(FUNCIONARIA_2, titulo="Caso Delta", prioridad="baja", estado="resuelto", tecnico=TECNICO, creado_en=AHORA - timedelta(hours=1))


def _titulos(html):
    return [t for t in ("Caso Alfa", "Caso Beta", "Caso Gamma", "Caso Delta") if t in html]


# ------------------------------------------------------------------ CA1
def test_ca1_el_administrador_ve_todos_los_tickets(admin):
    _escenario()
    assert _titulos(admin.get("/tickets").get_data(as_text=True)) == ["Caso Alfa", "Caso Beta", "Caso Gamma", "Caso Delta"]


def test_ca1_los_tickets_se_ordenan_por_fecha_de_creacion_descendente(admin):
    _escenario()
    html = admin.get("/tickets").get_data(as_text=True)
    posiciones = [html.index(t) for t in ("Caso Delta", "Caso Gamma", "Caso Beta", "Caso Alfa")]
    assert posiciones == sorted(posiciones)


def test_ca1_se_ven_los_tickets_de_todos_los_solicitantes(admin):
    _escenario()
    html = admin.get("/tickets").get_data(as_text=True)
    assert "Pedro Fuentes" in html and "Ana Rojas" in html


def test_ca1_sin_tickets_el_listado_funciona(admin):
    r = admin.get("/tickets")
    assert r.status_code == 200 and "Caso Alfa" not in r.get_data(as_text=True)


def test_ca1_los_tickets_con_la_misma_fecha_se_ordenan_de_forma_estable(admin):
    momento = AHORA - timedelta(days=1)
    for nombre in ("Mismo A", "Mismo B", "Mismo C"):
        crear_ticket(FUNCIONARIO, titulo=nombre, creado_en=momento)
    html = admin.get("/tickets").get_data(as_text=True)
    assert html.index("Mismo C") < html.index("Mismo B") < html.index("Mismo A")


# ------------------------------------------------------------------ CA2
@pytest.mark.parametrize("estado,esperados", [("pendiente", ["Caso Alfa"]), ("en_progreso", ["Caso Beta", "Caso Gamma"]), ("resuelto", ["Caso Delta"]), ("cerrado", [])])
def test_ca2_el_filtro_por_estado_muestra_solo_ese_estado(admin, estado, esperados):
    _escenario()
    assert sorted(_titulos(admin.get(f"/tickets?estado={estado}").get_data(as_text=True))) == sorted(esperados)


@pytest.mark.parametrize("prioridad,esperados", [("alta", ["Caso Alfa", "Caso Gamma"]), ("media", ["Caso Beta"]), ("baja", ["Caso Delta"])])
def test_ca2_el_filtro_por_prioridad_muestra_solo_esa_prioridad(admin, prioridad, esperados):
    _escenario()
    assert sorted(_titulos(admin.get(f"/tickets?prioridad={prioridad}").get_data(as_text=True))) == sorted(esperados)


def test_ca2_dos_filtros_a_la_vez_se_combinan(admin):
    _escenario()
    assert _titulos(admin.get("/tickets?estado=en_progreso&prioridad=alta").get_data(as_text=True)) == ["Caso Gamma"]


def test_ca2_una_combinacion_sin_resultados_no_muestra_tickets(admin):
    _escenario()
    r = admin.get("/tickets?estado=pendiente&prioridad=baja")
    assert r.status_code == 200 and _titulos(r.get_data(as_text=True)) == []


def test_ca2_los_filtros_elegidos_quedan_seleccionados_en_la_pantalla(admin):
    _escenario()
    html = admin.get("/tickets?estado=en_progreso&prioridad=alta").get_data(as_text=True)
    assert 'value="en_progreso" selected' in html and 'value="alta" selected' in html


@pytest.mark.parametrize("consulta", ["estado=inexistente", "prioridad=urgente", "estado=' OR '1'='1", "prioridad=<script>alert(1)</script>"])
def test_ca2_un_filtro_invalido_no_provoca_error_ni_muestra_otros_tickets(admin, consulta):
    _escenario()
    r = admin.get(f"/tickets?{consulta}")
    assert r.status_code == 200
    assert _titulos(r.get_data(as_text=True)) == []
    assert "<script>alert(1)</script>" not in r.get_data(as_text=True)


# ------------------------------------------------------------------ CA3
def test_ca3_sin_filtros_vuelve_el_conjunto_completo(admin):
    _escenario()
    admin.get("/tickets?estado=pendiente")
    assert len(_titulos(admin.get("/tickets").get_data(as_text=True))) == 4


def test_ca3_los_filtros_vacios_equivalen_a_no_filtrar(admin):
    _escenario()
    assert len(_titulos(admin.get("/tickets?estado=&prioridad=").get_data(as_text=True))) == 4


def test_ca3_la_pantalla_ofrece_limpiar_los_filtros(admin):
    _escenario()
    html = admin.get("/tickets?estado=pendiente").get_data(as_text=True)
    assert "Limpiar filtros" in html and 'href="/tickets"' in html


# ------------------------------------------------------------------ alcance por rol
def test_el_funcionario_solo_ve_sus_tickets_aun_con_filtros(funcionario):
    _escenario()
    assert sorted(_titulos(funcionario.get("/tickets?prioridad=alta").get_data(as_text=True))) == ["Caso Alfa", "Caso Gamma"]
    assert _titulos(funcionario.get("/tickets?estado=resuelto").get_data(as_text=True)) == []


def test_el_tecnico_solo_ve_sus_tickets_asignados_aun_con_filtros(tecnico):
    _escenario()
    assert sorted(_titulos(tecnico.get("/tickets").get_data(as_text=True))) == ["Caso Beta", "Caso Delta", "Caso Gamma"]
    assert _titulos(tecnico.get("/tickets?estado=pendiente").get_data(as_text=True)) == []


def test_sin_sesion_se_pide_iniciar_sesion(client):
    r = client.get("/tickets?estado=pendiente")
    assert r.status_code == 302 and "/login" in r.headers["Location"]
