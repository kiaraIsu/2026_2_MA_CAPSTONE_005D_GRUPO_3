"""HU-16 — Visualizar dashboard de estadísticas (E4). Criterios CA1 a CA3."""
import re

import pytest

from tests.conftest import (FUNCIONARIA_2, FUNCIONARIO, TECNICO, TECNICO_2, crear_ticket, sql_exec, sql_uno)

pytestmark = pytest.mark.hu16


def _valor(html, etiqueta):
    """Número que aparece en la tarjeta del indicador con esa etiqueta."""
    m = re.search(r'stat-value[^>]*>\s*([^<]+?)\s*</div>\s*<div class="text-muted small">\s*' + re.escape(etiqueta) + r"\s*</div>", html)
    assert m, f"no se encontró el indicador “{etiqueta}”"
    return m.group(1)


def _panel(admin):
    r = admin.get("/dashboard")
    assert r.status_code == 200
    return r.get_data(as_text=True)


def _escenario():
    crear_ticket(FUNCIONARIO, titulo="T1", estado="pendiente", prioridad="alta", categoria="Hardware")
    crear_ticket(FUNCIONARIO, titulo="T2", estado="en_progreso", prioridad="alta", categoria="Hardware", tecnico=TECNICO)
    crear_ticket(FUNCIONARIA_2, titulo="T3", estado="en_revision", prioridad="media", categoria="Software", tecnico=TECNICO)
    crear_ticket(FUNCIONARIA_2, titulo="T4", estado="resuelto", prioridad="alta", categoria="Software", tecnico=TECNICO_2)
    crear_ticket(FUNCIONARIO, titulo="T5", estado="cerrado", prioridad="baja", categoria="Redes e Internet", tecnico=TECNICO_2)
    crear_ticket(FUNCIONARIO, titulo="T6", estado="pendiente", prioridad="baja", categoria="Hardware")


# ------------------------------------------------------------------ CA1
def test_ca1_muestra_el_total_de_tickets(admin):
    _escenario()
    assert _valor(_panel(admin), "Tickets totales") == "6"


@pytest.mark.parametrize("etiqueta,esperado", [("Pendientes", "2"), ("En progreso", "1"), ("En revisión", "1"), ("Resueltos", "1"), ("Cerrados", "1")])
def test_ca1_muestra_la_cantidad_de_tickets_por_estado(admin, etiqueta, esperado):
    _escenario()
    assert _valor(_panel(admin), etiqueta) == esperado


def test_ca1_muestra_los_tickets_de_alta_prioridad_sin_resolver(admin):
    _escenario()
    assert _valor(_panel(admin), "Alta prioridad abiertos") == "2"        # T1 y T2; T4 está resuelto


def test_ca1_muestra_la_distribucion_por_categoria(admin):
    _escenario()
    html = _panel(admin)
    for categoria, cantidad in (("Hardware", 3), ("Software", 2), ("Redes e Internet", 1)):
        fila = re.search(re.escape(categoria) + r"[^<]*</td>\s*<td[^>]*>\s*(?:<[^>]+>\s*)*(\d+)", html)
        assert fila and int(fila.group(1)) == cantidad, categoria


def test_ca1_muestra_la_carga_por_tecnico(admin):
    _escenario()
    html = _panel(admin)
    assert "Kiara Isuiza" in html and "Marcela Soto" in html
    kiara = html[html.index("Kiara Isuiza"):html.index("Kiara Isuiza") + 300]
    assert re.findall(r"\d+", kiara)[:2] == ["2", "0"]                    # abiertos y resueltos de Kiara
    marcela = html[html.index("Marcela Soto"):html.index("Marcela Soto") + 300]
    assert re.findall(r"\d+", marcela)[:2] == ["0", "2"]


def test_ca1_sin_tickets_los_indicadores_muestran_cero(admin):
    html = _panel(admin)
    for etiqueta in ("Tickets totales", "Pendientes", "En progreso", "En revisión", "Resueltos", "Cerrados", "Alta prioridad abiertos"):
        assert _valor(html, etiqueta) == "0"


def test_ca1_el_dashboard_de_estadisticas_es_solo_del_administrador(tecnico, funcionario):
    _escenario()
    for cliente in (tecnico, funcionario):
        assert "Tickets totales" not in cliente.get("/dashboard").get_data(as_text=True)


# ------------------------------------------------------------------ CA2
def test_ca2_al_crear_un_ticket_el_total_se_actualiza(admin, funcionario):
    _escenario()
    antes = int(_valor(_panel(admin), "Tickets totales"))
    funcionario.post("/tickets/nuevo", data={"titulo": "Nuevo", "descripcion": "Otro problema"})
    assert int(_valor(_panel(admin), "Tickets totales")) == antes + 1


def test_ca2_al_cambiar_un_estado_los_indicadores_reflejan_el_cambio(admin, tecnico):
    _escenario()
    tid = sql_uno("SELECT id FROM tickets WHERE titulo = 'T2'")["id"]
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "en_revision"})
    html = _panel(admin)
    assert _valor(html, "En progreso") == "0" and _valor(html, "En revisión") == "2"


def test_ca2_al_resolver_un_ticket_de_alta_prioridad_baja_el_indicador(admin, tecnico):
    _escenario()
    tid = sql_uno("SELECT id FROM tickets WHERE titulo = 'T2'")["id"]
    sql_exec("UPDATE tickets SET solucion = 'Listo' WHERE id = %s", (tid,))
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "resuelto"})
    assert _valor(_panel(admin), "Alta prioridad abiertos") == "1"


def test_ca2_los_datos_son_los_almacenados_no_una_copia_antigua(admin):
    _escenario()
    primera = _valor(_panel(admin), "Tickets totales")
    sql_exec("DELETE FROM tickets WHERE titulo = 'T6'")
    assert _valor(_panel(admin), "Tickets totales") == str(int(primera) - 1)


# ------------------------------------------------------------------ CA3
def _evaluar(titulo, puntaje):
    tid = sql_uno("SELECT id FROM tickets WHERE titulo = %s", (titulo,))["id"]
    sql_exec("INSERT INTO evaluaciones (ticket_id, puntaje, comentario, creado_en) VALUES (%s, %s, '', now())", (tid, puntaje))


def test_ca3_muestra_el_promedio_de_calificacion(admin):
    _escenario()
    _evaluar("T4", 4)
    _evaluar("T5", 5)
    assert re.fullmatch(r"4[.,]5(\s*/\s*5)?", _valor(_panel(admin), "Calificación promedio"))


def test_ca3_indica_cuantas_evaluaciones_hay(admin):
    _escenario()
    _evaluar("T4", 3)
    _evaluar("T5", 5)
    assert "2 evaluaciones" in _panel(admin)


def test_ca3_sin_evaluaciones_el_dashboard_funciona_y_lo_indica(admin):
    _escenario()
    html = _panel(admin)
    assert "Sin evaluaciones" in html and "Tickets totales" in html


def test_ca3_con_una_sola_evaluacion_se_usa_su_valor(admin):
    _escenario()
    _evaluar("T4", 2)
    assert _valor(_panel(admin), "Calificación promedio").startswith("2")
