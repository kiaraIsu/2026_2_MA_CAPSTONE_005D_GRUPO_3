"""HU-02 — Cerrar sesión y proteger el acceso (E1). Criterios CA1 a CA3."""
import io

import pytest

from tests.conftest import FUNCIONARIO, FUNCIONARIA_2, login, sesion_activa

pytestmark = pytest.mark.hu02

RUTAS_PROTEGIDAS = ["/dashboard", "/tickets", "/tickets/nuevo", "/admin/usuarios", "/admin/categorias"]


def test_ca1_cerrar_sesion_finaliza_la_sesion_y_redirige_al_login(funcionario):
    """CA1: usuario autenticado selecciona Cerrar sesión -> finaliza y redirige al inicio de sesión."""
    assert "user_id" in sesion_activa(funcionario)
    r = funcionario.get("/logout")
    assert r.status_code == 302 and r.headers["Location"].endswith("/login")
    assert "user_id" not in sesion_activa(funcionario)


@pytest.mark.parametrize("ruta", RUTAS_PROTEGIDAS)
def test_ca2_ruta_protegida_tras_cerrar_sesion_exige_autenticacion(funcionario, ruta):
    """CA2: sesión cerrada + intento de abrir ruta protegida -> deniega y solicita autenticación."""
    funcionario.get("/logout")
    r = funcionario.get(ruta)
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def _crear_ticket(cliente, titulo="Falla del correo institucional"):
    r = cliente.post("/tickets/nuevo", data={"titulo": titulo, "descripcion": "No puedo enviar correos",
                                              "categoria_id": "1", "prioridad": "media"})
    assert r.status_code == 302
    return int(r.headers["Location"].rsplit("/", 1)[1])


def test_ca3_sin_sesion_no_se_expone_informacion_de_tickets(app, funcionario):
    """CA3: sin sesión válida -> no se expone información de tickets ni datos de otros usuarios."""
    ticket_id = _crear_ticket(funcionario, titulo="Titulo-confidencial-123")
    anonimo = app.test_client()
    r = anonimo.get(f"/tickets/{ticket_id}")
    assert r.status_code == 302 and "/login" in r.headers["Location"]
    assert "Titulo-confidencial-123" not in r.get_data(as_text=True)
    lista = anonimo.get("/tickets")
    assert "Titulo-confidencial-123" not in lista.get_data(as_text=True)


def test_ca3_un_funcionario_no_ve_los_tickets_de_otro(app, funcionario):
    ticket_id = _crear_ticket(funcionario, titulo="Titulo-privado-456")
    otra = app.test_client()
    login(otra, FUNCIONARIA_2)
    assert otra.get(f"/tickets/{ticket_id}").status_code == 403
    assert "Titulo-privado-456" not in otra.get("/tickets").get_data(as_text=True)


def test_ca3_adjuntos_no_se_descargan_sin_sesion(app, funcionario):
    r = funcionario.post("/tickets/nuevo", data={"titulo": "Con adjunto", "descripcion": "Adjunto",
                                                  "categoria_id": "1", "prioridad": "baja",
                                                  "adjuntos": (io.BytesIO(b"contenido"), "nota.txt")},
                         content_type="multipart/form-data")
    assert r.status_code == 302
    anonimo = app.test_client()
    descarga = anonimo.get("/adjuntos/nota.txt")
    assert descarga.status_code == 302 and "/login" in descarga.headers["Location"]
