"""HU-14 — Revisar y corregir la clasificación (E3). Criterios CA1 a CA3."""
import pytest

from tests.conftest import (FUNCIONARIO, TECNICO, crear_ticket, historial_de, sql, sql_exec, sql_uno, usuario_id)

pytestmark = pytest.mark.hu14


def _cat(nombre):
    return sql_uno("SELECT id FROM categorias WHERE nombre = %s", (nombre,))["id"]


def _ticket_ia(**extra):
    tid = crear_ticket(FUNCIONARIO, titulo="La impresora no imprime", categoria="Hardware", prioridad="media", estado="en_progreso", tecnico=TECNICO, **extra)
    sql_exec("UPDATE tickets SET clasificado_por_ia = TRUE WHERE id = %s", (tid,))
    return tid


def _corregir(cliente, tid, categoria="Software", prioridad="alta"):
    datos = {}
    if categoria is not None:
        datos["categoria_id"] = str(_cat(categoria)) if isinstance(categoria, str) else str(categoria)
    if prioridad is not None:
        datos["prioridad"] = prioridad
    return cliente.post(f"/tickets/{tid}/clasificacion", data=datos)


def _fila(tid):
    return sql_uno("SELECT c.nombre AS categoria, t.prioridad, t.clasificado_por_ia FROM v_tickets t JOIN categorias c ON c.id = t.categoria_id WHERE t.id = %s", (tid,))


def _acciones(tid):
    return [h["accion"] for h in historial_de(tid)]


# ------------------------------------------------------------------ CA1
def test_ca1_el_tecnico_asignado_corrige_la_categoria_y_la_prioridad(tecnico):
    tid = _ticket_ia()
    assert _corregir(tecnico, tid).status_code == 302
    f = _fila(tid)
    assert f["categoria"] == "Software" and f["prioridad"] == "alta"


def test_ca1_el_administrador_corrige_la_clasificacion_de_cualquier_ticket(admin):
    tid = _ticket_ia()
    assert _corregir(admin, tid, "Redes e Internet", "baja").status_code == 302
    f = _fila(tid)
    assert f["categoria"] == "Redes e Internet" and f["prioridad"] == "baja"


def test_ca1_se_puede_corregir_solo_la_categoria(tecnico):
    tid = _ticket_ia()
    _corregir(tecnico, tid, "Software", "media")
    f = _fila(tid)
    assert f["categoria"] == "Software" and f["prioridad"] == "media"


def test_ca1_se_puede_corregir_solo_la_prioridad(tecnico):
    tid = _ticket_ia()
    _corregir(tecnico, tid, "Hardware", "alta")
    f = _fila(tid)
    assert f["categoria"] == "Hardware" and f["prioridad"] == "alta"


def test_ca1_la_correccion_manual_deja_de_figurar_como_clasificacion_de_la_ia(tecnico):
    tid = _ticket_ia()
    _corregir(tecnico, tid)
    assert not _fila(tid)["clasificado_por_ia"]
    assert "Clasificado por IA" not in tecnico.get(f"/tickets/{tid}").get_data(as_text=True)


def test_ca1_la_pantalla_muestra_la_clasificacion_corregida(tecnico):
    tid = _ticket_ia()
    _corregir(tecnico, tid, "Software", "alta")
    html = tecnico.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "Software" in html and "Alta" in html


def test_ca1_el_tecnico_y_el_administrador_ven_el_formulario_de_correccion(tecnico, admin):
    tid = _ticket_ia()
    for cliente in (tecnico, admin):
        html = cliente.get(f"/tickets/{tid}").get_data(as_text=True)
        assert f"/tickets/{tid}/clasificacion" in html and "Guardar clasificación" in html


@pytest.mark.parametrize("categoria_id", ["999999", "abc", "", "-1", "1.5", "1; DROP TABLE tickets"])
def test_ca1_una_categoria_invalida_se_rechaza_sin_error_del_servidor(tecnico, categoria_id):
    tid = _ticket_ia()
    r = tecnico.post(f"/tickets/{tid}/clasificacion", data={"categoria_id": categoria_id, "prioridad": "alta"})
    assert r.status_code == 302
    f = _fila(tid)
    assert f["categoria"] == "Hardware" and f["prioridad"] == "media"


def test_ca1_una_categoria_desactivada_no_se_puede_elegir(tecnico):
    tid = _ticket_ia()
    sql_exec("UPDATE categorias SET activa = FALSE WHERE nombre = 'Software'")
    _corregir(tecnico, tid, "Software", "alta")
    assert _fila(tid)["categoria"] == "Hardware"


@pytest.mark.parametrize("prioridad", ["urgente", "ALTA", "", "1", "alta; --"])
def test_ca1_una_prioridad_invalida_se_rechaza(tecnico, prioridad):
    tid = _ticket_ia()
    r = tecnico.post(f"/tickets/{tid}/clasificacion", data={"categoria_id": str(_cat("Software")), "prioridad": prioridad})
    assert r.status_code == 302
    f = _fila(tid)
    assert f["categoria"] == "Hardware" and f["prioridad"] == "media"


def test_ca1_se_informa_el_resultado_de_la_correccion(tecnico):
    tid = _ticket_ia()
    r = tecnico.post(f"/tickets/{tid}/clasificacion", data={"categoria_id": str(_cat("Software")), "prioridad": "alta"}, follow_redirects=True)
    assert "clasificación" in r.get_data(as_text=True).lower()


# ------------------------------------------------------------------ CA2
def test_ca2_el_historial_registra_el_valor_anterior_el_nuevo_y_el_usuario(tecnico):
    tid = _ticket_ia()
    _corregir(tecnico, tid, "Software", "alta")
    eventos = [h for h in historial_de(tid) if "orrigió la clasificación" in h["accion"]]
    assert len(eventos) == 1
    texto = eventos[0]["accion"]
    for valor in ("Hardware", "Software", "Media", "Alta"):
        assert valor in texto
    assert eventos[0]["usuario_id"] == usuario_id(TECNICO)


def test_ca2_el_historial_de_la_pantalla_muestra_la_correccion(tecnico):
    tid = _ticket_ia()
    _corregir(tecnico, tid, "Software", "alta")
    html = tecnico.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "Corrigió la clasificación" in html and "Kiara Isuiza" in html


def test_ca2_si_no_hay_cambios_no_se_registra_nada(tecnico):
    tid = _ticket_ia()
    antes = len(_acciones(tid))
    _corregir(tecnico, tid, "Hardware", "media")
    assert len(_acciones(tid)) == antes
    assert _fila(tid)["clasificado_por_ia"]


def test_ca2_cada_correccion_deja_su_propio_evento(tecnico, admin):
    tid = _ticket_ia()
    _corregir(tecnico, tid, "Software", "alta")
    _corregir(admin, tid, "Redes e Internet", "baja")
    eventos = [a for a in _acciones(tid) if "orrigió la clasificación" in a]
    assert len(eventos) == 2 and "Software" in eventos[1] and "Redes e Internet" in eventos[1]


def test_ca2_cuando_solo_cambia_un_valor_el_evento_lo_dice(tecnico):
    tid = _ticket_ia()
    _corregir(tecnico, tid, "Hardware", "baja")
    evento = [a for a in _acciones(tid) if "orrigió la clasificación" in a][0]
    assert "Media" in evento and "Baja" in evento


# ------------------------------------------------------------------ CA3
def test_ca3_el_funcionario_solicitante_no_puede_modificar_la_clasificacion(funcionario):
    tid = _ticket_ia()
    assert _corregir(funcionario, tid).status_code == 403
    f = _fila(tid)
    assert f["categoria"] == "Hardware" and f["prioridad"] == "media" and f["clasificado_por_ia"]


def test_ca3_el_funcionario_no_ve_el_formulario_de_correccion(funcionario):
    tid = _ticket_ia()
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert f"/tickets/{tid}/clasificacion" not in html and "Guardar clasificación" not in html


def test_ca3_otro_funcionario_tampoco_puede(funcionaria2):
    tid = _ticket_ia()
    assert _corregir(funcionaria2, tid).status_code == 403
    assert _fila(tid)["categoria"] == "Hardware"


def test_ca3_un_tecnico_no_asignado_no_puede_corregir(tecnico2):
    tid = _ticket_ia()
    assert _corregir(tecnico2, tid).status_code == 403
    assert _fila(tid)["categoria"] == "Hardware"


def test_ca3_sin_sesion_se_pide_iniciar_sesion(client):
    tid = _ticket_ia()
    r = client.post(f"/tickets/{tid}/clasificacion", data={"categoria_id": "1", "prioridad": "alta"})
    assert r.status_code == 302 and "/login" in r.headers["Location"]
    assert _fila(tid)["categoria"] == "Hardware"


def test_ca3_un_ticket_inexistente_responde_404(tecnico):
    assert tecnico.post("/tickets/99999/clasificacion", data={"categoria_id": "1", "prioridad": "alta"}).status_code == 404
