"""HU-03 — Administrar cuentas y roles (E1). Criterios CA1 a CA3."""
import pytest

from tests.conftest import (ADMIN, FUNCIONARIO, TECNICO, login, sesion_activa, sql, sql_uno)

pytestmark = pytest.mark.hu03


def _nuevo_usuario(cliente, **datos):
    base = {"nombre": "Usuario Prueba", "email": "prueba@municipalidad.cl",
            "password": "clave123", "rol": "usuario", "direccion": "Tránsito"}
    base.update(datos)
    return cliente.post("/admin/usuarios/nuevo", data=base)


@pytest.mark.parametrize("rol", ["usuario", "tecnico", "administrador"])
def test_ca1_admin_crea_cuenta_con_cada_rol(admin, app, rol):
    """CA1: administrador registra cuenta con nombre, correo y rol válidos -> se crea el usuario."""
    r = _nuevo_usuario(admin, rol=rol, email=f"{rol}.nuevo@municipalidad.cl")
    assert r.status_code == 302 and r.headers["Location"].endswith("/admin/usuarios")
    fila = sql_uno("SELECT * FROM v_usuarios WHERE email = %s", (f"{rol}.nuevo@municipalidad.cl",))
    assert fila["rol"] == rol and fila["activo"] is True
    assert fila["password_hash"] != "clave123"          # la contraseña se guarda con hash
    nuevo = app.test_client()
    assert login(nuevo, (f"{rol}.nuevo@municipalidad.cl", "clave123")).status_code == 302


def test_ca1_no_duplica_el_correo(admin):
    """CA1: el sistema crea el usuario sin duplicar el correo."""
    _nuevo_usuario(admin, email="duplicado@municipalidad.cl")
    r = _nuevo_usuario(admin, email="DUPLICADO@municipalidad.cl", nombre="Otro")
    assert r.status_code == 200 and "Ya existe un usuario con ese correo" in r.get_data(as_text=True)
    assert len(sql("SELECT 1 FROM v_usuarios WHERE email = %s", ("duplicado@municipalidad.cl",))) == 1


@pytest.mark.parametrize("campo, valor, mensaje", [
    ("nombre", "   ", "El nombre es obligatorio"),
    ("email", "sin-arroba", "correo válido"),
    ("password", "123", "al menos 6 caracteres"),
    ("rol", "superusuario", "Rol no válido"),
])
def test_ca1_datos_invalidos_se_rechazan(admin, campo, valor, mensaje):
    antes = len(sql("SELECT 1 FROM v_usuarios"))
    r = _nuevo_usuario(admin, **{campo: valor})
    assert r.status_code == 200 and mensaje in r.get_data(as_text=True)
    assert len(sql("SELECT 1 FROM v_usuarios")) == antes


def test_ca2_usuario_deshabilitado_no_inicia_sesion_hasta_ser_habilitado(admin, app):
    """CA2: administrador deshabilita un usuario activo -> no puede iniciar nuevas sesiones."""
    uid = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (FUNCIONARIO[0],))["id"]
    assert admin.post(f"/admin/usuarios/{uid}/estado").status_code == 302
    assert sql_uno("SELECT activo FROM v_usuarios WHERE id = %s", (uid,))["activo"] is False
    otro = app.test_client()
    assert "user_id" not in sesion_activa(otro) or True
    login(otro, FUNCIONARIO)
    assert "user_id" not in sesion_activa(otro)
    # se vuelve a habilitar
    admin.post(f"/admin/usuarios/{uid}/estado")
    assert login(otro, FUNCIONARIO).status_code == 302 and "user_id" in sesion_activa(otro)


def test_ca2_el_administrador_no_puede_deshabilitarse_a_si_mismo(admin):
    uid = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (ADMIN[0],))["id"]
    r = admin.post(f"/admin/usuarios/{uid}/estado", follow_redirects=True)
    assert "No puedes deshabilitar tu propia cuenta" in r.get_data(as_text=True)
    assert sql_uno("SELECT activo FROM v_usuarios WHERE id = %s", (uid,))["activo"] is True


def test_ca2_deshabilitar_cierra_tambien_la_sesion_ya_abierta(admin, funcionario):
    """Una cuenta deshabilitada pierde el acceso de inmediato, incluso con sesión abierta."""
    uid = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (FUNCIONARIO[0],))["id"]
    admin.post(f"/admin/usuarios/{uid}/estado")
    r = funcionario.get("/dashboard")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_ca3_modificar_rol_actualiza_la_base_de_datos(admin):
    """CA3: administrador modifica el rol de un usuario existente."""
    uid = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (FUNCIONARIO[0],))["id"]
    r = admin.post(f"/admin/usuarios/{uid}/rol", data={"rol": "tecnico"})
    assert r.status_code == 302
    assert sql_uno("SELECT rol FROM v_usuarios WHERE id = %s", (uid,))["rol"] == "tecnico"


def test_ca3_los_permisos_efectivos_cambian_con_el_nuevo_rol(admin, funcionario):
    """CA3: los permisos efectivos se actualizan de acuerdo con el nuevo rol (sin reiniciar sesión)."""
    assert funcionario.get("/admin/usuarios").status_code == 403           # antes: sin permiso
    uid = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (FUNCIONARIO[0],))["id"]
    admin.post(f"/admin/usuarios/{uid}/rol", data={"rol": "administrador"})
    assert funcionario.get("/admin/usuarios").status_code == 200           # después: con permiso
    admin.post(f"/admin/usuarios/{uid}/rol", data={"rol": "usuario"})
    assert funcionario.get("/admin/usuarios").status_code == 403           # vuelve a perderlo


def test_ca3_rol_invalido_se_rechaza(admin):
    uid = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (FUNCIONARIO[0],))["id"]
    admin.post(f"/admin/usuarios/{uid}/rol", data={"rol": "superusuario"})
    assert sql_uno("SELECT rol FROM v_usuarios WHERE id = %s", (uid,))["rol"] == "usuario"


def test_ca3_el_administrador_no_puede_cambiar_su_propio_rol(admin):
    uid = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (ADMIN[0],))["id"]
    admin.post(f"/admin/usuarios/{uid}/rol", data={"rol": "usuario"})
    assert sql_uno("SELECT rol FROM v_usuarios WHERE id = %s", (uid,))["rol"] == "administrador"


@pytest.mark.parametrize("ruta", ["/admin/usuarios", "/admin/usuarios/nuevo"])
def test_solo_el_administrador_accede_a_la_gestion_de_usuarios(funcionario, tecnico, client, ruta):
    assert funcionario.get(ruta).status_code == 403
    assert tecnico.get(ruta).status_code == 403
    assert client.get(ruta).status_code == 302
