"""HU-17 — Visualizar flujo de trabajo en tablero Kanban (E4). Criterios CA1 a CA3."""
import re

import pytest

from tests.conftest import (FUNCIONARIO, TECNICO, TECNICO_2, crear_ticket, sql_exec, sql_uno)

pytestmark = pytest.mark.hu17

COLUMNAS = ["Pendiente", "En progreso", "En revisión", "Resuelto", "Cerrado"]


def _columnas(html):
    """Devuelve {nombre de columna: texto de esa columna} a partir del tablero."""
    partes = re.split(r"<h6>\s*([^<]+?)\s*<span", html)
    return {partes[i].strip(): partes[i + 1] for i in range(1, len(partes) - 1, 2)}


def _tablero(tecnico):
    r = tecnico.get("/dashboard")
    assert r.status_code == 200
    return _columnas(r.get_data(as_text=True))


def _escenario():
    crear_ticket(FUNCIONARIO, titulo="K Pendiente", estado="pendiente", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="K Progreso", estado="en_progreso", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="K Revision", estado="en_revision", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="K Resuelto", estado="resuelto", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="K Cerrado", estado="cerrado", tecnico=TECNICO)


# ------------------------------------------------------------------ CA1
def test_ca1_el_tablero_tiene_una_columna_por_estado(tecnico):
    _escenario()
    assert list(_tablero(tecnico)) == COLUMNAS


@pytest.mark.parametrize("columna,titulo", [("Pendiente", "K Pendiente"), ("En progreso", "K Progreso"), ("En revisión", "K Revision"), ("Resuelto", "K Resuelto"), ("Cerrado", "K Cerrado")])
def test_ca1_cada_ticket_aparece_en_la_columna_de_su_estado(tecnico, columna, titulo):
    _escenario()
    tablero = _tablero(tecnico)
    assert titulo in tablero[columna]
    assert all(titulo not in texto for nombre, texto in tablero.items() if nombre != columna)


def test_ca1_las_columnas_vacias_se_muestran_con_su_aviso(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Solo uno", estado="en_progreso", tecnico=TECNICO)
    tablero = _tablero(tecnico)
    assert "Sin tickets" in tablero["Pendiente"] and "Sin tickets" in tablero["Cerrado"] and "Solo uno" in tablero["En progreso"]


def test_ca1_cada_columna_muestra_cuantos_tickets_tiene(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Uno", estado="en_progreso", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="Dos", estado="en_progreso", tecnico=TECNICO)
    html = tecnico.get("/dashboard").get_data(as_text=True)
    assert re.search(r"En progreso\s*<span[^>]*>\s*2\s*</span>", html)


def test_ca1_solo_aparecen_los_tickets_asignados_al_tecnico(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Mio", estado="en_progreso", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="De otro tecnico", estado="en_progreso", tecnico=TECNICO_2)
    crear_ticket(FUNCIONARIO, titulo="Sin asignar", estado="pendiente")
    html = tecnico.get("/dashboard").get_data(as_text=True)
    assert "Mio" in html and "De otro tecnico" not in html and "Sin asignar" not in html


def test_ca1_sin_tickets_asignados_el_tablero_lo_informa(tecnico):
    r = tecnico.get("/dashboard")
    assert r.status_code == 200 and "Sin tickets" in r.get_data(as_text=True)


def test_ca1_cada_tarjeta_enlaza_al_detalle_del_ticket(tecnico):
    tid = crear_ticket(FUNCIONARIO, titulo="Con enlace", estado="en_progreso", tecnico=TECNICO)
    assert f"/tickets/{tid}" in tecnico.get("/dashboard").get_data(as_text=True)


# ------------------------------------------------------------------ CA2
def test_ca2_al_cambiar_de_estado_el_ticket_pasa_a_la_columna_nueva(tecnico):
    tid = crear_ticket(FUNCIONARIO, titulo="Se mueve", estado="en_progreso", tecnico=TECNICO)
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "en_revision"})
    tablero = _tablero(tecnico)
    assert "Se mueve" in tablero["En revisión"] and "Se mueve" not in tablero["En progreso"]


def test_ca2_un_cambio_invalido_deja_el_ticket_en_su_columna(tecnico):
    tid = crear_ticket(FUNCIONARIO, titulo="No se mueve", estado="en_progreso", tecnico=TECNICO)
    tecnico.post(f"/tickets/{tid}/estado", data={"estado": "cerrado"})
    tablero = _tablero(tecnico)
    assert "No se mueve" in tablero["En progreso"] and "No se mueve" not in tablero["Cerrado"]


def test_ca2_el_recorrido_completo_se_refleja_en_el_tablero(tecnico):
    tid = crear_ticket(FUNCIONARIO, titulo="Recorrido", estado="pendiente", tecnico=TECNICO)
    sql_exec("UPDATE tickets SET solucion = 'Resuelto el problema' WHERE id = %s", (tid,))
    for estado, columna in (("en_progreso", "En progreso"), ("en_revision", "En revisión"), ("resuelto", "Resuelto"), ("cerrado", "Cerrado")):
        tecnico.post(f"/tickets/{tid}/estado", data={"estado": estado})
        assert "Recorrido" in _tablero(tecnico)[columna]


def test_ca2_un_ticket_reabierto_vuelve_a_la_columna_en_progreso(tecnico, funcionario):
    tid = crear_ticket(FUNCIONARIO, titulo="Reabierto", estado="resuelto", tecnico=TECNICO, solucion="Hecho")
    funcionario.post(f"/tickets/{tid}/solicitar-reapertura", data={"motivo": "Volvió a fallar"})
    assert "Reabierto" in _tablero(tecnico)["En progreso"]


def test_ca2_una_nueva_asignacion_aparece_en_el_tablero_del_tecnico(admin, tecnico):
    tid = crear_ticket(FUNCIONARIO, titulo="Recien asignado", estado="pendiente")
    admin.post(f"/tickets/{tid}/asignar", data={"tecnico_id": sql_uno("SELECT id FROM usuarios WHERE email = 'kiara.tecnico@municipalidad.cl'")["id"]})
    assert "Recien asignado" in _tablero(tecnico)["En progreso"]


# ------------------------------------------------------------------ CA3
def test_ca3_los_tickets_de_alta_prioridad_se_diferencian_visualmente(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Urgente", prioridad="alta", estado="en_progreso", tecnico=TECNICO)
    columna = _tablero(tecnico)["En progreso"]
    assert "prioridad-alta" in columna and "badge-prioridad-alta" in columna and "Alta" in columna


def test_ca3_cada_prioridad_tiene_su_propia_marca(tecnico):
    for prioridad in ("alta", "media", "baja"):
        crear_ticket(FUNCIONARIO, titulo=f"P {prioridad}", prioridad=prioridad, estado="en_progreso", tecnico=TECNICO)
    columna = _tablero(tecnico)["En progreso"]
    for prioridad in ("alta", "media", "baja"):
        assert f"prioridad-{prioridad}" in columna


def test_ca3_la_prioridad_alta_aparece_primero_en_su_columna(tecnico):
    crear_ticket(FUNCIONARIO, titulo="Prioridad baja", prioridad="baja", estado="en_progreso", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="Prioridad alta", prioridad="alta", estado="en_progreso", tecnico=TECNICO)
    crear_ticket(FUNCIONARIO, titulo="Prioridad media", prioridad="media", estado="en_progreso", tecnico=TECNICO)
    columna = _tablero(tecnico)["En progreso"]
    assert columna.index("Prioridad alta") < columna.index("Prioridad media") < columna.index("Prioridad baja")


def test_ca3_los_estilos_de_prioridad_existen_en_la_hoja_de_estilos(tecnico):
    css = tecnico.get("/static/style.css")
    if css.status_code != 200:
        pytest.skip("la hoja de estilos no está en esa ruta")
    texto = css.get_data(as_text=True)
    assert ".prioridad-alta" in texto and ".badge-prioridad-alta" in texto


# ------------------------------------------------------------------ alcance por rol
def test_solo_el_tecnico_tiene_el_tablero_kanban(admin, funcionario):
    _escenario()
    for cliente in (admin, funcionario):
        assert "Mi tablero de tickets" not in cliente.get("/dashboard").get_data(as_text=True)


def test_sin_sesion_se_pide_iniciar_sesion(client):
    r = client.get("/dashboard")
    assert r.status_code == 302 and "/login" in r.headers["Location"]
