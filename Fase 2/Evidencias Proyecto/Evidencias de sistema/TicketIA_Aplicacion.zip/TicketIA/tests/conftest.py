"""
Configuración común de las pruebas de TicketIA (Sprint 1).

Las pruebas usan una base de datos PostgreSQL SEPARADA de la de desarrollo
(por defecto "ticketia_test"). Antes de cada prueba se eliminan y recrean las
tablas, así que NUNCA apuntes TEST_DB_NAME a tu base de desarrollo.

Variables opcionales: TEST_DB_NAME, TEST_DB_HOST, TEST_DB_PORT, TEST_DB_USER,
TEST_DB_PASSWORD.
"""
import os

# Debe ejecutarse ANTES de importar database/app (leen el entorno al importar).
os.environ["DB_NAME"] = os.environ.get("TEST_DB_NAME", "ticketia_test")
for destino, origen in (("DB_HOST", "TEST_DB_HOST"), ("DB_PORT", "TEST_DB_PORT"),
                        ("DB_USER", "TEST_DB_USER"), ("DB_PASSWORD", "TEST_DB_PASSWORD")):
    if os.environ.get(origen):
        os.environ[destino] = os.environ[origen]

import psycopg2  # noqa: E402
import pytest  # noqa: E402


def _asegurar_base_de_pruebas():
    """Crea la base de pruebas si no existe (requiere un usuario con permiso CREATEDB)."""
    nombre = os.environ["DB_NAME"]
    try:
        conn = psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"),
                                dbname="postgres", user=os.environ.get("DB_USER", "ticketia_user"),
                                password=os.environ.get("DB_PASSWORD", "ticketia_pass"))
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (nombre,))
            if cur.fetchone() is None:
                cur.execute('CREATE DATABASE "%s"' % nombre.replace('"', ""))
        conn.close()
    except psycopg2.Error as error:  # si no se puede, las pruebas fallarán con un mensaje claro de conexión
        print(f"[tests] No fue posible verificar/crear la base de pruebas: {error}")


_asegurar_base_de_pruebas()

import app as appmod  # noqa: E402
import database as db  # noqa: E402

ADMIN = ("jade.admin@municipalidad.cl", "admin123")
TECNICO = ("kiara.tecnico@municipalidad.cl", "tecnico123")
FUNCIONARIO = ("pedro.funcionario@municipalidad.cl", "usuario123")
FUNCIONARIA_2 = ("ana.funcionaria@municipalidad.cl", "usuario123")
TECNICO_2 = ("marcela.tecnico@municipalidad.cl", "tecnico123")


@pytest.fixture()
def app(tmp_path):
    """Aplicación con base de datos recién creada y carpeta de adjuntos temporal."""
    appmod.app.config.update(TESTING=True, CSRF_ACTIVO=False)   # las pruebas de CSRF lo activan por su cuenta
    if hasattr(appmod, "_intentos_fallidos"):
        appmod._intentos_fallidos.clear()
    appmod.UPLOAD_DIR = str(tmp_path / "uploads")
    db.reset_db()
    db.init_db()
    yield appmod.app


@pytest.fixture()
def client(app):
    return app.test_client()


def login(client, credenciales, seguir=False):
    email, password = credenciales
    return client.post("/login", data={"email": email, "password": password}, follow_redirects=seguir)


@pytest.fixture()
def admin(app):
    c = app.test_client()
    login(c, ADMIN)
    return c


@pytest.fixture()
def tecnico(app):
    c = app.test_client()
    login(c, TECNICO)
    return c


@pytest.fixture()
def funcionario(app):
    c = app.test_client()
    login(c, FUNCIONARIO)
    return c


def sql(consulta, params=()):
    """Consulta directa a la base de pruebas (para verificar el estado real de los datos)."""
    conn = db.get_db()
    try:
        return db.query_all(conn, consulta, params)
    finally:
        conn.close()


def sql_uno(consulta, params=()):
    filas = sql(consulta, params)
    return filas[0] if filas else None


def sql_exec(consulta, params=()):
    conn = db.get_db()
    try:
        db.execute(conn, consulta, params)
        conn.commit()
    finally:
        conn.close()


def sesion_activa(client):
    with client.session_transaction() as s:
        return dict(s)


# ---------------------------------------------------------------------------
# Ayudantes para preparar tickets, consultar el historial y usar un segundo técnico
# ---------------------------------------------------------------------------
from datetime import datetime, timezone  # noqa: E402


@pytest.fixture()
def tecnico2(app):
    c = app.test_client()
    login(c, TECNICO_2)
    return c


@pytest.fixture()
def funcionaria2(app):
    c = app.test_client()
    login(c, FUNCIONARIA_2)
    return c


def usuario_id(credenciales):
    return sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (credenciales[0],))["id"]


def crear_ticket(solicitante=FUNCIONARIO, titulo="Ticket de prueba", descripcion="Descripción de prueba", prioridad="media",
                 estado="pendiente", tecnico=None, categoria="Hardware", creado_en=None, solucion=None):
    """Inserta un ticket directamente en la base (para preparar escenarios) y devuelve su id."""
    momento = creado_en or datetime.now(timezone.utc)
    cat = sql_uno("SELECT id FROM categorias WHERE nombre = %s", (categoria,))["id"]
    conn = db.get_db()
    try:
        fila = db.query_one(
            conn,
            "INSERT INTO tickets (titulo, descripcion, categoria_id, prioridad_id, estado_id, usuario_id, tecnico_id, solucion, "
            "creado_en, actualizado_en) VALUES (%s, %s, %s, (SELECT id FROM prioridades WHERE codigo = %s), "
            "(SELECT id FROM estados WHERE codigo = %s), %s, %s, %s, %s, %s) RETURNING id",
            (titulo, descripcion, cat, prioridad, estado, usuario_id(solicitante),
             usuario_id(tecnico) if tecnico else None, solucion, momento, momento),
        )
        conn.commit()
    finally:
        conn.close()
    return fila["id"]


def estado_de(ticket_id):
    return sql_uno("SELECT estado FROM v_tickets WHERE id = %s", (ticket_id,))["estado"]


def tecnico_de(ticket_id):
    return sql_uno("SELECT tecnico_id FROM v_tickets WHERE id = %s", (ticket_id,))["tecnico_id"]


def solucion_de(ticket_id):
    return sql_uno("SELECT solucion FROM v_tickets WHERE id = %s", (ticket_id,))["solucion"]


def historial_de(ticket_id):
    return sql("SELECT h.accion, h.usuario_id, h.creado_en FROM historial h WHERE h.ticket_id = %s ORDER BY h.id", (ticket_id,))
