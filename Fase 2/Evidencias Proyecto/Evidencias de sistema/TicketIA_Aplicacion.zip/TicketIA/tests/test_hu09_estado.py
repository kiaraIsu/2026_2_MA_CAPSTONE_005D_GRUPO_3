"""HU-09 — Actualizar estado del ticket (E2). Criterios CA1 a CA3."""
from datetime import datetime, timedelta, timezone

import pytest

from tests.conftest import (FUNCIONARIO, TECNICO, crear_ticket, estado_de, historial_de, usuario_id)

pytestmark = pytest.mark.hu09

# Transiciones del flujo de atención: pendiente -> en progreso -> en revisión -> resuelto -> cerrado
PERMITIDAS = [("pendiente", "en_progreso"), ("en_progreso", "en_revision"), ("en_progreso", "resuelto"), ("en_revision", "en_progreso"),
              ("en_revision", "resuelto"), ("resuelto", "en_progreso"), ("resuelto", "cerrado")]
NO_PERMITIDAS = [("pendiente", "en_revision"), ("pendiente", "resuelto"), ("pendiente", "cerrado"), ("en_progreso", "pendiente"),
                 ("en_progreso", "cerrado"), ("en_revision", "pendiente"), ("en_revision", "cerrado"), ("resuelto", "pendiente"),
                 ("resuelto", "en_revision"), ("cerrado", "pendiente"), ("cerrado", "en_progreso"), ("cerrado", "resuelto"),
                 ("en_progreso", "en_progreso")]


def _cambiar(cliente, ticket_id, nuevo, solucion=""):
    datos = {"estado": nuevo}
    if solucion:
        datos["solucion"] = solucion
    return cliente.post(f"/tickets/{ticket_id}/estado", data=datos)


def _solucion_para(destino):
    return "Se aplicó la solución indicada" if destino == "resuelto" else ""


# ------------------------------------------------------------------ CA1
@pytest.mark.parametrize("origen,destino", PERMITIDAS)
def test_ca1_el_tecnico_asignado_realiza_las_transiciones_permitidas(tecnico, origen, destino):
    tid = crear_ticket(FUNCIONARIO, estado=origen, tecnico=TECNICO)
    r = _cambiar(tecnico, tid, destino, _solucion_para(destino))
    assert r.status_code == 302
    assert estado_de(tid) == destino


@pytest.mark.parametrize("origen,destino", NO_PERMITIDAS)
def test_ca1_las_transiciones_no_permitidas_se_rechazan(tecnico, origen, destino):
    tid = crear_ticket(FUNCIONARIO, estado=origen, tecnico=TECNICO, solucion="Solución previa" if origen in ("resuelto", "cerrado") else None)
    _cambiar(tecnico, tid, destino, _solucion_para(destino))
    assert estado_de(tid) == origen
    assert historial_de(tid) == [], "una transición rechazada no debe dejar registro en el historial"


def test_ca1_el_administrador_tambien_puede_cambiar_el_estado(admin):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    _cambiar(admin, tid, "en_revision")
    assert estado_de(tid) == "en_revision"


def test_ca1_un_tecnico_no_asignado_no_puede_cambiar_el_estado(tecnico2):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    r = _cambiar(tecnico2, tid, "en_revision")
    assert r.status_code == 403 and estado_de(tid) == "en_progreso"


def test_ca1_un_estado_inexistente_se_rechaza(tecnico):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    _cambiar(tecnico, tid, "inventado")
    assert estado_de(tid) == "en_progreso"


# ------------------------------------------------------------------ CA2
def test_ca2_el_historial_registra_responsable_fecha_estado_anterior_y_nuevo(tecnico):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    antes = datetime.now(timezone.utc)
    _cambiar(tecnico, tid, "en_revision")
    h = historial_de(tid)[-1]
    assert h["usuario_id"] == usuario_id(TECNICO)
    assert h["creado_en"] >= antes - timedelta(seconds=5)
    assert "En progreso" in h["accion"] and "En revisión" in h["accion"]


def test_ca2_el_cambio_aparece_en_el_historial_del_detalle(tecnico):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    _cambiar(tecnico, tid, "en_revision")
    html = tecnico.get(f"/tickets/{tid}").get_data(as_text=True)
    assert "En revisión" in html and "Kiara Isuiza" in html


def test_ca2_cada_cambio_deja_su_propio_registro(tecnico):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    _cambiar(tecnico, tid, "en_revision")
    _cambiar(tecnico, tid, "en_progreso")
    assert len([h for h in historial_de(tid) if "estado" in h["accion"].lower()]) == 2


# ------------------------------------------------------------------ CA3
def test_ca3_un_funcionario_no_puede_modificar_el_estado_de_su_ticket(funcionario):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    r = _cambiar(funcionario, tid, "cerrado")
    assert r.status_code == 403 and estado_de(tid) == "en_progreso" and historial_de(tid) == []


def test_ca3_sin_sesion_no_se_puede_cambiar_el_estado(client):
    tid = crear_ticket(FUNCIONARIO, estado="en_progreso", tecnico=TECNICO)
    r = _cambiar(client, tid, "en_revision")
    assert r.status_code == 302 and "/login" in r.headers["Location"] and estado_de(tid) == "en_progreso"
