"""HU-12 — Descargar archivos adjuntos (E2). Criterios CA1 a CA3."""
import io
import os

import pytest

import app as appmod
from tests.conftest import (FUNCIONARIO, TECNICO, TECNICO_2, sql_exec, sql_uno, usuario_id)

pytestmark = pytest.mark.hu12

CONTENIDO = b"Contenido de la evidencia 12345"


def _ticket_con_adjunto(cliente, nombre="evidencia.txt", contenido=CONTENIDO):
    r = cliente.post("/tickets/nuevo", data={"titulo": "Falla de red", "descripcion": "Adjunto la captura",
                                                "adjuntos": (io.BytesIO(contenido), nombre)}, content_type="multipart/form-data")
    assert r.status_code == 302
    tid = sql_uno("SELECT id FROM tickets ORDER BY id DESC LIMIT 1")["id"]
    ruta = sql_uno("SELECT ruta FROM adjuntos WHERE ticket_id = %s", (tid,))["ruta"]
    return tid, ruta


def _asignar_a_kiara(tid):
    sql_exec("UPDATE tickets SET tecnico_id = %s WHERE id = %s", (usuario_id(TECNICO), tid))


# ------------------------------------------------------------------ CA1
def test_ca1_el_solicitante_descarga_su_adjunto(funcionario):
    tid, ruta = _ticket_con_adjunto(funcionario)
    r = funcionario.get(f"/adjuntos/{ruta}")
    assert r.status_code == 200 and r.data == CONTENIDO


def test_ca1_la_descarga_se_inicia_como_archivo_con_su_nombre(funcionario):
    tid, ruta = _ticket_con_adjunto(funcionario, nombre="informe de falla.txt")
    r = funcionario.get(f"/adjuntos/{ruta}")
    disposicion = r.headers.get("Content-Disposition", "")
    assert disposicion.startswith("attachment") and ".txt" in disposicion


def test_ca1_el_tecnico_asignado_y_el_administrador_tambien_descargan(funcionario, tecnico, admin):
    tid, ruta = _ticket_con_adjunto(funcionario)
    _asignar_a_kiara(tid)
    for cliente in (tecnico, admin):
        r = cliente.get(f"/adjuntos/{ruta}")
        assert r.status_code == 200 and r.data == CONTENIDO


def test_ca1_el_detalle_ofrece_el_enlace_de_descarga(funcionario):
    tid, ruta = _ticket_con_adjunto(funcionario, nombre="evidencia.txt")
    html = funcionario.get(f"/tickets/{tid}").get_data(as_text=True)
    assert f"/adjuntos/{ruta}" in html and "evidencia.txt" in html


def test_ca1_un_archivo_binario_se_descarga_completo(funcionario):
    binario = bytes(range(256)) * 40
    tid, ruta = _ticket_con_adjunto(funcionario, nombre="datos.zip", contenido=binario)
    assert funcionario.get(f"/adjuntos/{ruta}").data == binario


# ------------------------------------------------------------------ CA2
def test_ca2_un_archivo_eliminado_responde_que_no_esta_disponible(funcionario):
    tid, ruta = _ticket_con_adjunto(funcionario)
    os.remove(os.path.join(appmod.UPLOAD_DIR, ruta))
    r = funcionario.get(f"/adjuntos/{ruta}")
    assert r.status_code == 404
    assert "no está disponible" in r.get_data(as_text=True)


def test_ca2_la_respuesta_no_expone_rutas_internas(funcionario):
    tid, ruta = _ticket_con_adjunto(funcionario)
    os.remove(os.path.join(appmod.UPLOAD_DIR, ruta))
    cuerpo = funcionario.get(f"/adjuntos/{ruta}").get_data(as_text=True)
    assert appmod.UPLOAD_DIR not in cuerpo and ruta not in cuerpo
    assert "Traceback" not in cuerpo and "/uploads" not in cuerpo


@pytest.mark.parametrize("nombre", ["no_existe.txt", "999_abc_inexistente.pdf"])
def test_ca2_un_archivo_inexistente_responde_404(funcionario, nombre):
    assert funcionario.get(f"/adjuntos/{nombre}").status_code == 404


@pytest.mark.parametrize("ruta", ["../app.py", "..%2Fapp.py", "../../etc/passwd", "%2e%2e/%2e%2e/etc/passwd", "/etc/passwd"])
def test_ca2_no_se_puede_salir_de_la_carpeta_de_adjuntos(funcionario, ruta):
    r = funcionario.get(f"/adjuntos/{ruta}")
    assert r.status_code in (404, 308, 301) or r.status_code == 404
    assert b"root:" not in r.data and b"import " not in r.data


# ------------------------------------------------------------------ CA3
def test_ca3_otro_funcionario_no_descarga_por_url_directa(funcionario, funcionaria2):
    tid, ruta = _ticket_con_adjunto(funcionario)
    r = funcionaria2.get(f"/adjuntos/{ruta}")
    assert r.status_code == 403 and CONTENIDO not in r.data


def test_ca3_un_tecnico_no_asignado_no_descarga(funcionario, tecnico2):
    tid, ruta = _ticket_con_adjunto(funcionario)
    _asignar_a_kiara(tid)
    r = tecnico2.get(f"/adjuntos/{ruta}")
    assert r.status_code == 403 and CONTENIDO not in r.data


def test_ca3_sin_sesion_se_pide_iniciar_sesion(funcionario, client):
    tid, ruta = _ticket_con_adjunto(funcionario)
    r = client.get(f"/adjuntos/{ruta}")
    assert r.status_code == 302 and "/login" in r.headers["Location"]
    assert CONTENIDO not in r.data


def test_ca3_el_enlace_de_otro_ticket_tampoco_sirve(funcionario, funcionaria2):
    tid1, ruta1 = _ticket_con_adjunto(funcionario, nombre="uno.txt", contenido=b"secreto del uno")
    tid2, ruta2 = _ticket_con_adjunto(funcionaria2, nombre="dos.txt", contenido=b"secreto del dos")
    assert funcionaria2.get(f"/adjuntos/{ruta1}").status_code == 403
    assert funcionaria2.get(f"/adjuntos/{ruta2}").data == b"secreto del dos"
