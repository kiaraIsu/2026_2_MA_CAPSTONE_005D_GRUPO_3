"""HU-04 — Crear ticket de soporte (E2). Criterios CA1 a CA3."""
import io
import os

import pytest

from tests.conftest import FUNCIONARIO, FUNCIONARIA_2, login, sql, sql_uno

pytestmark = pytest.mark.hu04

MB = 1024 * 1024


def _datos(**extra):
    base = {"titulo": "La impresora no imprime", "descripcion": "Aparece un error al imprimir",
            "categoria_id": "1", "prioridad": "media"}
    base.update(extra)
    return base


def _enviar(cliente, archivos=None, **extra):
    datos = _datos(**extra)
    if archivos:
        datos["adjuntos"] = [(io.BytesIO(contenido), nombre) for nombre, contenido in archivos]
    return cliente.post("/tickets/nuevo", data=datos, content_type="multipart/form-data")


def _total_tickets():
    return sql_uno("SELECT COUNT(*) AS n FROM v_tickets")["n"]


# ----------------------------------------------------------------------- CA1
def test_ca1_crea_ticket_en_estado_pendiente_asociado_a_la_cuenta(funcionario):
    """CA1: título y descripción obligatorios -> ticket asociado a su cuenta, estado inicial Pendiente."""
    r = _enviar(funcionario)
    assert r.status_code == 302
    t = sql_uno("SELECT * FROM v_tickets")
    usuario = sql_uno("SELECT id FROM v_usuarios WHERE email = %s", (FUNCIONARIO[0],))
    assert t["estado"] == "pendiente"
    assert t["usuario_id"] == usuario["id"]
    assert t["tecnico_id"] is None
    assert t["titulo"] == "La impresora no imprime"
    assert "Pendiente" in funcionario.get(r.headers["Location"]).get_data(as_text=True)


def test_ca1_queda_registrado_en_el_historial(funcionario):
    _enviar(funcionario)
    acciones = [f["accion"] for f in sql("SELECT accion FROM historial ORDER BY id")]
    assert "Ticket creado" in acciones


def test_ca1_el_ticket_aparece_en_mis_solicitudes(funcionario):
    _enviar(funcionario, titulo="Solicitud-visible-789")
    assert "Solicitud-visible-789" in funcionario.get("/tickets").get_data(as_text=True)


def test_ca1_clasificacion_automatica_asigna_categoria_y_prioridad(funcionario):
    """Con la opción de IA activada el sistema clasifica el ticket y lo indica."""
    r = funcionario.post("/tickets/nuevo", data={"titulo": "Urgente: el servidor no funciona",
                                                  "descripcion": "Sistema caído, no funciona la red", "usar_ia": "on"})
    assert r.status_code == 302
    t = sql_uno("SELECT * FROM v_tickets")
    assert t["clasificado_por_ia"] is True
    assert t["prioridad"] in ("baja", "media", "alta") and t["categoria_id"] is not None


# ----------------------------------------------------------------------- CA2
def test_ca2_archivo_permitido_se_almacena_y_se_relaciona_con_el_ticket(app, funcionario):
    """CA2: archivo permitido -> el sistema lo almacena y lo relaciona con la solicitud."""
    r = _enviar(funcionario, archivos=[("captura.png", b"\x89PNG-contenido-de-prueba")])
    assert r.status_code == 302
    adjunto = sql_uno("SELECT * FROM adjuntos")
    ticket = sql_uno("SELECT id FROM v_tickets")
    assert adjunto["ticket_id"] == ticket["id"] and adjunto["nombre_archivo"] == "captura.png"
    ruta = os.path.join(app_upload_dir(), adjunto["ruta"])
    assert os.path.isfile(ruta) and open(ruta, "rb").read() == b"\x89PNG-contenido-de-prueba"
    descarga = funcionario.get(f"/adjuntos/{adjunto['ruta']}")
    assert descarga.status_code == 200


def test_ca2_acepta_varios_adjuntos(funcionario):
    _enviar(funcionario, archivos=[("a.pdf", b"%PDF-1"), ("b.txt", b"texto"), ("c.zip", b"PK")])
    assert len(sql("SELECT 1 FROM adjuntos")) == 3


@pytest.mark.parametrize("extension", ["png", "jpg", "jpeg", "gif", "pdf", "docx", "xlsx", "txt", "zip"])
def test_ca2_todas_las_extensiones_permitidas_se_aceptan(funcionario, extension):
    r = _enviar(funcionario, archivos=[(f"doc.{extension}", b"datos")])
    assert r.status_code == 302 and len(sql("SELECT 1 FROM adjuntos")) == 1


def test_ca2_archivo_de_9_mb_se_acepta(funcionario):
    r = _enviar(funcionario, archivos=[("grande.zip", b"0" * (9 * MB))])
    assert r.status_code == 302 and len(sql("SELECT 1 FROM adjuntos")) == 1


def test_ca2_archivo_de_exactamente_10_mb_se_acepta(funcionario):
    """El límite es 'hasta 10 MB': un archivo de 10 MB exactos debe aceptarse."""
    r = _enviar(funcionario, archivos=[("limite.zip", b"0" * (10 * MB))])
    assert r.status_code == 302 and len(sql("SELECT 1 FROM adjuntos")) == 1


def test_ca2_el_nombre_del_archivo_se_sanea(app, funcionario):
    _enviar(funcionario, archivos=[("../../etc/passwd.txt", b"x")])
    adjunto = sql_uno("SELECT * FROM adjuntos")
    assert ".." not in adjunto["nombre_archivo"] and "/" not in adjunto["ruta"]
    assert os.path.dirname(os.path.join(app_upload_dir(), adjunto["ruta"])) == app_upload_dir()


# ----------------------------------------------------------------------- CA3
@pytest.mark.parametrize("campos, mensaje", [
    ({"titulo": ""}, "El título es obligatorio"),
    ({"titulo": "    "}, "El título es obligatorio"),
    ({"descripcion": ""}, "La descripción es obligatoria"),
    ({"descripcion": "   "}, "La descripción es obligatoria"),
])
def test_ca3_campo_obligatorio_faltante_no_crea_ticket(funcionario, campos, mensaje):
    """CA3: falta un campo obligatorio -> no se crea el ticket y se muestra un mensaje específico."""
    r = _enviar(funcionario, **campos)
    assert r.status_code == 200 and mensaje in r.get_data(as_text=True)
    assert _total_tickets() == 0


def test_ca3_faltan_ambos_campos_se_informan_los_dos_errores(funcionario):
    r = _enviar(funcionario, titulo="", descripcion="")
    texto = r.get_data(as_text=True)
    assert "El título es obligatorio" in texto and "La descripción es obligatoria" in texto
    assert _total_tickets() == 0


@pytest.mark.parametrize("nombre", ["virus.exe", "script.sh", "pagina.html", "sin_extension"])
def test_ca3_archivo_con_extension_no_permitida_no_crea_ticket(funcionario, nombre):
    """CA3: el archivo no cumple las reglas -> no se crea el ticket y se muestra mensaje de validación."""
    r = _enviar(funcionario, archivos=[(nombre, b"contenido")])
    assert r.status_code == 200
    assert "tipo permitido" in r.get_data(as_text=True)
    assert _total_tickets() == 0 and len(sql("SELECT 1 FROM adjuntos")) == 0


def test_ca3_archivo_de_mas_de_10_mb_no_crea_ticket(funcionario):
    r = _enviar(funcionario, archivos=[("enorme.zip", b"0" * (10 * MB + 1))])
    assert r.status_code == 200 and "10 MB" in r.get_data(as_text=True)
    assert _total_tickets() == 0


def test_ca3_un_adjunto_invalido_cancela_todo_el_envio(funcionario):
    r = _enviar(funcionario, archivos=[("bien.pdf", b"%PDF"), ("mal.exe", b"MZ")])
    assert r.status_code == 200 and _total_tickets() == 0 and len(sql("SELECT 1 FROM adjuntos")) == 0


def test_ca3_envio_demasiado_grande_se_rechaza_con_mensaje(funcionario):
    """Un envío que supera el tope total de la solicitud muestra un mensaje en vez de un error técnico."""
    archivos = [(f"f{i}.zip", b"0" * (9 * MB)) for i in range(3)]
    r = _enviar(funcionario, archivos=archivos)
    assert r.status_code in (200, 302)
    assert _total_tickets() == 0
    seguimiento = funcionario.get("/tickets/nuevo").get_data(as_text=True)
    assert "10 MB" in (r.get_data(as_text=True) + seguimiento)


# ----------------------------------------------------------------------- acceso
def test_crear_ticket_requiere_sesion(client):
    r = client.post("/tickets/nuevo", data=_datos())
    assert r.status_code == 302 and "/login" in r.headers["Location"]
    assert _total_tickets() == 0


def test_otro_funcionario_no_puede_ver_el_ticket(app, funcionario):
    r = _enviar(funcionario)
    otra = app.test_client()
    login(otra, FUNCIONARIA_2)
    assert otra.get(r.headers["Location"]).status_code == 403


def app_upload_dir():
    import app as appmod
    return appmod.UPLOAD_DIR
