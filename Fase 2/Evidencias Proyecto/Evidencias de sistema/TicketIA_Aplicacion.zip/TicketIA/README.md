# TicketIA – Sistema Inteligente de Gestión de Soporte TI

**Asignatura / Sección:** 2026_2_MA_CAPSTONE_005D
**Grupo:** GRUPO_3
**Institución:** DUOC UC – Sede Maipú
**Docente guía:** Fabián Álvarez Montenegro

---

## 📋 Descripción del proyecto

**TicketIA** es una plataforma web de gestión de soporte TI pensada para el Departamento de Informática de una municipalidad en Chile. Hoy los funcionarios de las distintas direcciones municipales (Administración y Finanzas, DIDECO, Obras, Tránsito, entre otras) piden ayuda técnica por WhatsApp, llamadas o correo, sin un registro centralizado. Esto dificulta el seguimiento, la priorización y la medición del servicio.

El objetivo del proyecto es **centralizar en un solo sistema la creación, el seguimiento y la resolución de las solicitudes técnicas**. La plataforma tiene tres tipos de usuario: funcionario solicitante, técnico de soporte y administrador. Permite crear tickets con archivos adjuntos, asignarlos y priorizarlos, hacer seguimiento de su estado, agregar comentarios, consultar el historial y evaluar la atención recibida. Las cuentas las crea el administrador, como se hace en el Departamento de Informática de una municipalidad.

Como aporte diferenciador, incorpora un **módulo de inteligencia artificial** que propone automáticamente la categoría y la prioridad de cada ticket a partir de la descripción escrita por el funcionario. El técnico o el administrador pueden corregir esa clasificación, y la corrección queda registrada en el historial.

**Estado del proyecto:** las 21 historias de usuario (79 puntos) están construidas, verificadas con pruebas automatizadas y aceptadas por la Product Owner.

## 🧰 Tecnologías

| Capa | Tecnología |
|---|---|
| Backend | Python 3.12 y Flask 3.1 |
| Base de datos | PostgreSQL 16 |
| Interfaz | Plantillas Jinja2, HTML, CSS y Bootstrap |
| Inteligencia artificial | Clasificador propio por reglas y palabras clave con pesos |
| Despliegue | Docker, Docker Compose y servidor waitress |
| Calidad | pytest y pytest-cov, Locust y axe-core |
| Gestión | Git, GitHub y Jira |

## 🗓️ Metodología y sprints

El proyecto se desarrolla con **Scrumban** (Scrum + Kanban), con tablero en Jira.

| Etapa | Fechas | Puntos |
|---|---|---|
| Inicio (Sprint 0) | 17 de agosto al 6 de septiembre | — |
| Planificación | 7 al 27 de septiembre | — |
| Sprint 1 | 28 de septiembre al 11 de octubre | 21 |
| Sprint 2 | 19 de octubre al 1 de noviembre | 20 |
| Sprint 3 | 2 al 9 de noviembre | 19 |
| Sprint 4 | 10 al 13 de noviembre | 19 |
| Cierre y entrega | 14 al 19 de noviembre | — |

Los Sprints 3 y 4 fueron más cortos porque la entrega del proyecto se fijó para el 19 de noviembre.

## 👥 Equipo de trabajo

| Nombre completo | Rol / responsabilidad | Correo | GitHub |
|---|---|---|---|
| Jade Vásquez Quispe | Product Owner | jad.vasquez@duocuc.cl | [@jadeeeeeeeeeeeeeeee](https://github.com/jadeeeeeeeeeeeeeeee) |
| Kiara Isuiza Romero | Scrum Master, encargada de la planificación Kanban y desarrolladora backend | ki.isuiza@duocuc.cl | [@kiaraIsu](https://github.com/kiaraIsu) |
| David Navarro | Programador y QA | davi.navarro@duocuc.cl | [@DavidNavarroRojas](https://github.com/DavidNavarroRojas) |

## 📁 Estructura del repositorio

La organización de carpetas sigue la estructura definida para la sección 2026_2_MA_CAPSTONE_005D:

```
2026_2_MA_CAPSTONE_005D_GRUPO_3/
│
├── Fase 1/
│   ├── Evidencias Grupales/        # Entregables grupales de la Fase 1
│   └── Evidencias Individuales/    # Bitácoras y evaluaciones individuales de la Fase 1
│
├── Fase 2/
│   ├── Evidencias Grupales/        # Entregables grupales de la Fase 2, incluido el informe final
│   ├── Evidencias Individuales/    # Diarios de reflexión de la Fase 2
│   └── Evidencias Proyecto/
│       ├── Evidencias de documentación/   # Documentos del proyecto, organizados por sprint (SPRINT 1 a SPRINT 4)
│       └── Evidencias de sistema/
│           ├── Aplicación/                # Código fuente, pruebas y configuración del sistema
│           └── Base de datos/             # Scripts de la base de datos
│
└── Fase 3/
    ├── Evidencias Grupales/
    └── Evidencias Individuales/
```

Dentro de `Evidencias de sistema/Aplicación/`:

| Carpeta o archivo | Contenido |
|---|---|
| `app.py`, `database.py`, `ai_classifier.py`, `wsgi.py` | Aplicación, acceso a datos, clasificador de IA y punto de entrada de producción |
| `templates/`, `static/` | Pantallas del sistema y sus estilos |
| `tests/`, `pytest.ini` | Pruebas automatizadas de aceptación, seguridad y base de datos |
| `schema_export.sql`, `migraciones/` | Esquema de la base de datos y su migración |
| `Dockerfile`, `docker-compose.yml`, `docker-compose.produccion.yml` | Despliegue con contenedores |
| `rendimiento/`, `seguridad/`, `usabilidad/`, `validacion_ia/`, `despliegue/` | Scripts y resultados de las mediciones de calidad |
| `reports/` | Resultados de las ejecuciones de pruebas |

Dentro de `Evidencias de sistema/Base de datos/`: el script de creación (`schema_export.sql`), la migración de normalización (`migraciones/`), el script de datos de demostración y un `LEEME.md` que explica el modelo de 11 tablas.

## ▶️ Cómo ejecutar el sistema

**Requisitos:** Python 3.12 y Docker Desktop.

1. Entra a la carpeta del sistema:
   ```
   cd "Fase 2/Evidencias Proyecto/Evidencias de sistema/Aplicación"
   ```
2. Levanta la base de datos y la aplicación:
   ```
   docker compose up -d db
   pip install -r requirements.txt
   python app.py
   ```
3. Abre **http://127.0.0.1:5000** en el navegador.

También se puede levantar todo con Docker: `docker compose up --build`, y luego abrir **http://localhost:5000**.

**Cuentas de demostración**

| Rol | Correo | Clave |
|---|---|---|
| Administrador | jade.admin@municipalidad.cl | admin123 |
| Técnico | kiara.tecnico@municipalidad.cl | tecnico123 |
| Funcionario | pedro.funcionario@municipalidad.cl | usuario123 |

Para crear más cuentas, el administrador entra a **Usuarios → Nuevo usuario**. No existe el registro público.

## 🧪 Pruebas

```
pip install -r requirements-dev.txt
python -m pytest -v --cov=app --cov=database --cov=ai_classifier --cov-report=term-missing
```

El resultado esperado es **503 pruebas aprobadas** y **98 % de cobertura**.

## 📊 Resultados

| Indicador | Meta | Resultado |
|---|---|---|
| Historias de usuario verificadas | 21 | 21 de 21 |
| Cobertura de las pruebas | 70 % o más | 98 % |
| Precisión de la IA | 80 % o más | 91 % en categoría y 80 % en prioridad, con un conjunto de prueba aparte |
| Tiempo de respuesta | 500 ms o menos | Cumple hasta 60 usuarios simultáneos en una máquina de un núcleo |
| Accesibilidad (WCAG 2.1 A y AA) | 0 violaciones | 0 violaciones en 24 vistas, en escritorio y en celular |

## 📚 Documentación

Los documentos de cada sprint están en `Fase 2/Evidencias Proyecto/Evidencias de documentación/`: planificación y seguimiento, tablero de Jira, plan de pruebas, evidencias de las pruebas y Sprint Review con retrospectiva. El documento de arquitectura, la matriz de riesgos, el roadmap y el Product Backlog están en las carpetas de los sprints, con su versión más reciente en la carpeta del último sprint.
