"""Validación del clasificador de IA de TicketIA (HU-13).

Mide qué tan bien el clasificador (ai_classifier.py) acierta la categoría y la prioridad de un conjunto de
tickets etiquetados a mano. Compara con la meta de la Fase 1: precisión de 80 % o más.

Hay dos sets de 100 tickets etiquetados a mano:
  - set_validacion.csv (de DESARROLLO): se usó para encontrar errores y ajustar las reglas.
  - set_prueba.csv (de PRUEBA): se redactó aparte y NO se usa para ajustar las reglas. Es la medición oficial.

Uso, desde la carpeta del proyecto:
    python validacion_ia/validar_ia.py            mide los dos sets
    python validacion_ia/validar_ia.py prueba     mide solo el set de prueba
Escribe resultados_desarrollo.csv y resultados_prueba.csv en esta carpeta.
"""
import csv
import os
import sys
from collections import Counter, defaultdict

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(AQUI))
from ai_classifier import clasificar_ticket  # noqa: E402

CATEGORIAS = ["Hardware", "Software", "Redes e Internet", "Correo Electrónico", "Cuentas y Accesos", "Otros"]
PRIORIDADES = ["alta", "media", "baja"]
IDS = {nombre: i for i, nombre in enumerate(CATEGORIAS, 1)}
NOMBRES = {i: n for n, i in IDS.items()}
META = 0.80


def leer(ruta):
    with open(ruta, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def metricas(pares, clases):
    """pares: lista de (esperada, predicha). Devuelve exactitud, matriz y precisión/exhaustividad por clase."""
    matriz = {e: Counter() for e in clases}
    for e, p in pares:
        matriz[e][p] += 1
    exactitud = sum(1 for e, p in pares if e == p) / len(pares)
    por_clase = {}
    for c in clases:
        tp = matriz[c][c]
        fn = sum(matriz[c].values()) - tp
        fp = sum(matriz[e][c] for e in clases if e != c)
        precision = tp / (tp + fp) if tp + fp else 0.0
        exhaust = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * exhaust / (precision + exhaust) if precision + exhaust else 0.0
        por_clase[c] = (precision, exhaust, f1, tp + fn)
    return exactitud, matriz, por_clase


SETS = {"desarrollo": ("set_validacion.csv", "resultados_desarrollo.csv"), "prueba": ("set_prueba.csv", "resultados_prueba.csv")}


def medir(clave):
    entrada, salida = SETS[clave]
    casos = leer(os.path.join(AQUI, entrada))
    filas, cat_pares, pri_pares = [], [], []
    for c in casos:
        r = clasificar_ticket(c["titulo"], c["descripcion"], IDS)
        cat_p, pri_p = NOMBRES[r["categoria_id"]], r["prioridad"]
        cat_pares.append((c["categoria_esperada"], cat_p)); pri_pares.append((c["prioridad_esperada"], pri_p))
        filas.append({**c, "categoria_predicha": cat_p, "prioridad_predicha": pri_p,
                      "acierta_categoria": int(cat_p == c["categoria_esperada"]), "acierta_prioridad": int(pri_p == c["prioridad_esperada"])})
    ruta_out = os.path.join(AQUI, salida)
    with open(ruta_out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0].keys())); w.writeheader(); w.writerows(filas)
    ex_c, _, pc_c = metricas(cat_pares, CATEGORIAS); ex_p, _, pc_p = metricas(pri_pares, PRIORIDADES)
    ambas = sum(1 for f in filas if f["acierta_categoria"] and f["acierta_prioridad"]) / len(filas)
    print(f"=== Set de {clave.upper()} ({entrada}) ===")
    print(f"Casos evaluados: {len(filas)}")
    print(f"Precisión de la categoría:  {ex_c:.1%}  (meta {META:.0%}: {'CUMPLE' if ex_c >= META else 'NO CUMPLE'})")
    print(f"Precisión de la prioridad:  {ex_p:.1%}  (meta {META:.0%}: {'CUMPLE' if ex_p >= META else 'NO CUMPLE'})")
    print(f"Acierta categoría y prioridad a la vez: {ambas:.1%}")
    print("Por categoría (precisión / exhaustividad):")
    for c, (p, r, _, n) in pc_c.items(): print(f"  {c:20s} {p:5.0%} / {r:5.0%}  ({n} casos)")
    print("Por prioridad (precisión / exhaustividad):")
    for c, (p, r, _, n) in pc_p.items(): print(f"  {c:6s} {p:5.0%} / {r:5.0%}  ({n} casos)")
    print(f"Resultados guardados en {ruta_out}\n")


def main():
    claves = [a for a in sys.argv[1:] if a in SETS] or list(SETS)
    for clave in claves:
        medir(clave)


if __name__ == "__main__":
    main()
