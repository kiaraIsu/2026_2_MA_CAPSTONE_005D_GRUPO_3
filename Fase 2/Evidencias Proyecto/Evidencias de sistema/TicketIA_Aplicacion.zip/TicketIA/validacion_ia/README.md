# Validación del clasificador de IA

Mide qué tan bien `ai_classifier.py` acierta la categoría y la prioridad de un ticket. La meta de la Fase 1 es una exactitud de 80 % o más (criterio CA3 de la HU-13).

## Cómo ejecutarla
Desde la carpeta del proyecto:

    python validacion_ia/validar_ia.py            # mide los dos sets
    python validacion_ia/validar_ia.py prueba     # mide solo el set de prueba

## Los dos sets
- `set_validacion.csv` (**desarrollo**): 100 tickets. Con ellos se encontraron los errores del clasificador y se ajustaron las reglas.
- `set_prueba.csv` (**prueba**): 100 tickets nuevos, redactados aparte. No se usaron para ajustar las reglas, y por eso su resultado es la medición oficial.

Separarlos evita medir el clasificador con los mismos casos con los que se mejoró, lo que daría una cifra inflada.

## Resultados
| Medición | Categoría | Prioridad | Ambas a la vez |
|---|---|---|---|
| Línea base del Sprint 2 (set de desarrollo, reglas anteriores) | 76 % | 61 % | 44 % |
| Sprint 3, set de desarrollo (con el que se ajustó) | 99 % | 92 % | 91 % |
| **Sprint 3, set de prueba (medición oficial)** | **91 %** | **80 %** | **72 %** |

## Cómo leer el resultado
- La categoría supera la meta con margen. La prioridad la alcanza justo en el límite.
- Con 100 casos, el intervalo de confianza de 95 % de la prioridad va de 71 % a 87 %: el valor real podría estar bajo la meta.
- Ambos sets los etiquetó y redactó la misma persona y comparten el tipo de situaciones. La cifra es una referencia, no una garantía con tickets reales.
- Acertar la categoría y la prioridad a la vez llega a 72 %.

## Archivos
- `validar_ia.py`: el script de medición.
- `resultados_prueba.csv` y `resultados_desarrollo.csv`: el resultado de cada set, ticket por ticket.
- `resultados_linea_base_sprint2.csv`: la medición del Sprint 2, con las reglas anteriores.
- El informe con el análisis está en `docs/pruebas/Validacion_IA_TicketIA.xlsx`.

## Próximos pasos
Validar con tickets reales de la municipalidad y escritos por otras personas, medir con un tercer set antes de cambiar las reglas, y evaluar un motor avanzado a través de `MOTOR_AVANZADO`, que ya cuenta con el respaldo por reglas.
