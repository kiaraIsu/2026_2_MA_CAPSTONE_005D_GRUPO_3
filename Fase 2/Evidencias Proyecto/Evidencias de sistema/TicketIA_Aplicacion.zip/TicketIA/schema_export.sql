-- ============================================================
-- TicketIA - Script de creación de base de datos (PostgreSQL)
-- Proyecto APT - PT4614 Capstone
-- Equipo: Jade Vásquez, Kiara Isuiza, David Navarro
-- Generado a partir de database.py (fuente de verdad del esquema)
-- Esquema normalizado: catálogos de roles, estados, prioridades y direcciones.
-- Para una base creada con la versión anterior, usar migraciones/001_normalizar_catalogos.sql
-- ============================================================

-- Tablas catálogo (normalización): cada valor se guarda una sola vez y las demás tablas lo referencian por su id.
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS estados (
    id SERIAL PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    orden INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS prioridades (
    id SERIAL PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    orden INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS direcciones (
    id SERIAL PRIMARY KEY,
    nombre TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_direcciones_nombre ON direcciones (lower(nombre));

CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    nombre TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    rol_id INTEGER NOT NULL REFERENCES roles(id),
    direccion_id INTEGER REFERENCES direcciones(id),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS categorias (
    id SERIAL PRIMARY KEY,
    nombre TEXT NOT NULL UNIQUE,
    activa BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS tickets (
    id SERIAL PRIMARY KEY,
    titulo TEXT NOT NULL,
    descripcion TEXT NOT NULL,
    categoria_id INTEGER NOT NULL REFERENCES categorias(id),
    prioridad_id INTEGER NOT NULL REFERENCES prioridades(id),
    estado_id INTEGER NOT NULL REFERENCES estados(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    tecnico_id INTEGER REFERENCES usuarios(id),
    clasificado_por_ia BOOLEAN NOT NULL DEFAULT FALSE,
    solucion TEXT,
    reapertura_solicitada BOOLEAN NOT NULL DEFAULT FALSE,
    creado_en TIMESTAMPTZ NOT NULL,
    actualizado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS comentarios (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    contenido TEXT NOT NULL,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS adjuntos (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    nombre_archivo TEXT NOT NULL,
    ruta TEXT NOT NULL,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS historial (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    accion TEXT NOT NULL,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS evaluaciones (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL UNIQUE REFERENCES tickets(id),
    puntaje INTEGER NOT NULL CHECK (puntaje BETWEEN 1 AND 5),
    comentario TEXT,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tickets_usuario ON tickets(usuario_id);
CREATE INDEX IF NOT EXISTS idx_tickets_tecnico ON tickets(tecnico_id);
CREATE INDEX IF NOT EXISTS idx_tickets_estado ON tickets(estado_id);
CREATE INDEX IF NOT EXISTS idx_tickets_prioridad ON tickets(prioridad_id);
CREATE INDEX IF NOT EXISTS idx_usuarios_rol ON usuarios(rol_id);
CREATE INDEX IF NOT EXISTS idx_usuarios_direccion ON usuarios(direccion_id);
CREATE INDEX IF NOT EXISTS idx_comentarios_ticket ON comentarios(ticket_id);
CREATE INDEX IF NOT EXISTS idx_historial_ticket ON historial(ticket_id);

-- Vistas de lectura: muestran los códigos (rol, estado, prioridad) y la dirección como texto, uniendo los catálogos.
CREATE OR REPLACE VIEW v_usuarios AS
SELECT u.id, u.nombre, u.email, u.password_hash, r.codigo AS rol, r.nombre AS rol_nombre, d.nombre AS direccion,
       u.rol_id, u.direccion_id, u.activo, u.creado_en
FROM usuarios u
JOIN roles r ON r.id = u.rol_id
LEFT JOIN direcciones d ON d.id = u.direccion_id;

CREATE OR REPLACE VIEW v_tickets AS
SELECT t.id, t.titulo, t.descripcion, t.categoria_id, p.codigo AS prioridad, e.codigo AS estado,
       t.prioridad_id, t.estado_id, t.usuario_id, t.tecnico_id, t.clasificado_por_ia, t.solucion,
       t.reapertura_solicitada, t.creado_en, t.actualizado_en
FROM tickets t
JOIN prioridades p ON p.id = t.prioridad_id
JOIN estados e ON e.id = t.estado_id;


-- Valores de los catálogos (la aplicación también los carga al iniciar)
INSERT INTO roles (codigo, nombre) VALUES ('usuario', 'Funcionario'), ('tecnico', 'Técnico'), ('administrador', 'Administrador') ON CONFLICT (codigo) DO NOTHING;
INSERT INTO estados (codigo, nombre, orden) VALUES ('pendiente', 'Pendiente', 1), ('en_progreso', 'En progreso', 2), ('en_revision', 'En revisión', 3),
                                                   ('resuelto', 'Resuelto', 4), ('cerrado', 'Cerrado', 5) ON CONFLICT (codigo) DO NOTHING;
INSERT INTO prioridades (codigo, nombre, orden) VALUES ('alta', 'Alta', 1), ('media', 'Media', 2), ('baja', 'Baja', 3) ON CONFLICT (codigo) DO NOTHING;
