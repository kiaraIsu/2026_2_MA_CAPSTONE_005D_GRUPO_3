# Pruebas de seguridad de TicketIA

**Tipo de prueba:** seguridad de la aplicación web (autenticación, control de acceso, inyección SQL, XSS, CSRF, archivos adjuntos, cabeceras y validación de datos).
**Herramientas:** pytest (`tests/test_seguridad.py`, 72 pruebas) y el escáner de vulnerabilidades [Wapiti](https://wapiti-scanner.github.io/).

## Pruebas automatizadas
```bash
python -m pytest -m seguridad -v
```

## Escáner Wapiti
1. Instalar: `pip install wapiti3` (o usar Docker: `docker run --rm -it --network host cyberwatch/wapiti`).
2. Iniciar la aplicación con los datos de demostración y abrir el sistema en el navegador.
3. Para escanear las pantallas con sesión, iniciar sesión como administrador y copiar el valor de la cookie `session` (en las herramientas del navegador).
4. Ejecutar (reemplaza `<COOKIE>` y la dirección si es necesario):
```bash
wapiti -u http://127.0.0.1:5000/dashboard -s http://127.0.0.1:5000/tickets -s http://127.0.0.1:5000/admin/usuarios \
  -H "Cookie: session=<COOKIE>" -x http://127.0.0.1:5000/logout --scope domain \
  -m "sql,xss,csrf,file,exec,crlf,redirect,http_headers,cookieflags,csp,backup,htaccess" \
  --max-attack-time 22 --max-scan-time 140 -f json -o reports/seguridad/wapiti_reporte.json
```
> Úsalo solo contra tu propia aplicación y con datos de prueba: el escáner envía miles de solicitudes y crea registros.

## Resultado
72 pruebas aprobadas; el último escaneo recorrió 65 páginas y envió más de 4.400 solicitudes sin errores del servidor
(solo queda el aviso de la cookie sin la bandera Secure, que depende de usar HTTPS).
Informe completo: `docs/pruebas/Informe_Pruebas_de_Seguridad_TicketIA.docx`.
