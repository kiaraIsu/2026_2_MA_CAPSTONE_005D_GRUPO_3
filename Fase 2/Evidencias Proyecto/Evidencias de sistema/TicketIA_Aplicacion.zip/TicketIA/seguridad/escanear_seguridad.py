"""Escaneo de seguridad con Wapiti, autenticado como administrador, sin usar F12.

Uso (desde la carpeta del sistema, donde esta app.py, con el sistema ya iniciado
con  $env:HOST="0.0.0.0"; python app.py  en otra terminal):
    python escanear_seguridad.py
"""
import http.cookiejar, os, re, subprocess, sys, urllib.parse, urllib.request

BASE = "http://localhost:5000"
CORREO, CLAVE = "jade.admin@municipalidad.cl", "admin123"

jar = http.cookiejar.CookieJar()
op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
try:
    html = op.open(BASE + "/login", timeout=15).read().decode("utf-8", "replace")
except Exception as e:
    sys.exit(f"No pude conectar con {BASE}. Inicia el sistema primero (python app.py). Detalle: {e}")
m = re.search(r'name="csrf_token"\s+value="([^"]+)"', html)
if not m:
    sys.exit("No encontre el token CSRF en la pantalla de login.")
datos = urllib.parse.urlencode({"csrf_token": m.group(1), "email": CORREO, "password": CLAVE}).encode()
op.open(BASE + "/login", datos, timeout=15)
cookie = next((c.value for c in jar if c.name == "session"), None)
if not cookie:
    sys.exit("No se obtuvo la cookie de sesion.")
# comprobar que la sesion es de administrador
try:
    r = op.open(BASE + "/admin/usuarios", timeout=15)
    ok = r.status == 200
except Exception:
    ok = False
if not ok:
    sys.exit("La sesion no es de administrador (no abre /admin/usuarios). Revisa que la base tenga la cuenta jade.admin@municipalidad.cl.")
print("Sesion de administrador obtenida correctamente. Iniciando el escaner (unos 3 minutos)...")
os.makedirs(os.path.join("reports", "seguridad"), exist_ok=True)
salida = os.path.abspath(os.path.join("reports", "seguridad"))
H = "http://host.docker.internal:5000"
cmd = ["docker", "run", "--rm", "-v", f"{salida}:/out", "cyberwatch/wapiti",
       "-u", f"{H}/dashboard", "-s", f"{H}/tickets", "-s", f"{H}/admin/usuarios",
       "-H", f"Cookie: session={cookie}", "-x", f"{H}/logout", "--scope", "domain",
       "-m", "sql,xss,csrf,file,exec,crlf,redirect,http_headers,cookieflags,csp,backup,htaccess",
       "--max-attack-time", "22", "--max-scan-time", "140", "-f", "json", "-o", "/out/wapiti_reporte.json"]
subprocess.run(cmd)
ruta = os.path.join(salida, "wapiti_reporte.json")
if os.path.exists(ruta):
    txt = open(ruta, encoding="utf-8", errors="replace").read()
    print("Reporte generado:", ruta, "| cookie real usada:", "PEGA_AQUI" not in txt)
else:
    print("No se genero el reporte.")
