"""Carga 3 tickets de ejemplo para mostrar las funciones del Sprint 2 (solo si todavía no hay tickets).

  - Tickets 1 y 2: de Pedro, asignados al técnico Kiara y en progreso (prioridad alta y media).
  - Ticket 3: de Pedro, pendiente y sin técnico (sirve para mostrar la asignación).

Uso, con el sistema ya iniciado al menos una vez (así existen las tablas y los usuarios de demostración):
    python cargar_datos_demo.py                              (aplicación en tu computador)
    docker compose exec web python cargar_datos_demo.py      (aplicación en Docker)
"""
from datetime import datetime, timedelta, timezone

import database as db


def main():
    db.init_db(seed_demo_data=True)
    conn = db.get_db()
    try:
        if db.query_one(conn, "SELECT COUNT(*) AS n FROM tickets")["n"] > 0:
            print("Ya hay tickets en la base: no se cargó nada.")
            return
        uid = lambda email: db.query_one(conn, "SELECT id FROM usuarios WHERE email = %s", (email,))["id"]
        cid = lambda nombre: db.query_one(conn, "SELECT id FROM categorias WHERE nombre = %s", (nombre,))["id"]
        ahora = datetime.now(timezone.utc)
        ejemplos = [
            ("La impresora del segundo piso no imprime", "Aparece un error de papel atascado y no funciona.", "Hardware", "alta", "en_progreso", "kiara.tecnico@municipalidad.cl", ahora - timedelta(days=3)),
            ("No puedo ingresar al correo institucional", "El sistema dice que mi contraseña expiró.", "Correo Electrónico", "media", "en_progreso", "kiara.tecnico@municipalidad.cl", ahora - timedelta(days=1)),
            ("Solicitud de instalación de software", "Necesito instalar el programa de planillas.", "Software", "baja", "pendiente", None, ahora),
        ]
        for titulo, descripcion, categoria, prioridad, estado, tecnico, creado in ejemplos:
            t = db.query_one(
                conn,
                "INSERT INTO tickets (titulo, descripcion, categoria_id, prioridad_id, estado_id, usuario_id, tecnico_id, creado_en, actualizado_en) "
                "VALUES (%s, %s, %s, (SELECT id FROM prioridades WHERE codigo = %s), (SELECT id FROM estados WHERE codigo = %s), %s, %s, %s, %s) RETURNING id",
                (titulo, descripcion, cid(categoria), prioridad, estado, uid("pedro.funcionario@municipalidad.cl"), uid(tecnico) if tecnico else None, creado, creado))
            db.execute(conn, "INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, 'Ticket creado', %s)", (t["id"], uid("pedro.funcionario@municipalidad.cl"), creado))
        conn.commit()
        print("Listo: se cargaron 3 tickets de ejemplo (ids 1, 2 y 3).")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
