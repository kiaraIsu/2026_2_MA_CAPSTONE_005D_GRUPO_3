"""
wsgi.py — punto de entrada de TicketIA para producción.

Un servidor de producción (waitress, gunicorn) importa este módulo en lugar de ejecutar `python app.py`.
Aquí se prepara lo que app.py solo hace al ejecutarse directamente: la carpeta de adjuntos, el esquema de la
base de datos y, si el sistema está detrás de un proxy con HTTPS, la lectura de sus cabeceras.

Variables de entorno:
  SEED_DEMO_DATA  1 (por defecto) carga las cuentas y los tickets de demostración si la base está vacía; 0 no los carga.
  TRUST_PROXY     1 si el sistema está detrás de un proxy o túnel que entrega HTTPS (Render, Cloudflare Tunnel, etc.).

Uso:   waitress-serve --listen=0.0.0.0:5000 wsgi:app
"""
import os

import app as ticketia

os.makedirs(ticketia.UPLOAD_DIR, exist_ok=True)
ticketia.db.init_db(seed_demo_data=os.environ.get("SEED_DEMO_DATA", "1") == "1")

app = ticketia.app

if os.environ.get("TRUST_PROXY", "0") == "1":
    from werkzeug.middleware.proxy_fix import ProxyFix

    # Confía en una sola capa de proxy: usa su esquema (https), su host y la IP real del visitante.
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
