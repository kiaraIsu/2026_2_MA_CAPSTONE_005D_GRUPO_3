<#
 Prueba de estres de TicketIA en Windows (PowerShell): sobrecarga el sistema y comprueba si se recupera.
   1) Referencia:   10 usuarios (carga normal)
   2) Estres:      200 usuarios, muy por encima de la capacidad
   3) Recuperacion: otra vez 10 usuarios, con el mismo servidor, para ver si vuelve a responder como antes

 Uso, desde la carpeta del sistema (donde esta app.py):
     powershell -ExecutionPolicy Bypass -File rendimiento\ejecutar_estres.ps1

 Resultados: rendimiento\resultados\final_estres_*_stats.csv
#>
param([string]$Prefijo = "final")
$ErrorActionPreference = "Continue"
$puerto = 5057
$host_url = "http://127.0.0.1:$puerto"
$salida = "rendimiento/resultados"
New-Item -ItemType Directory -Force -Path "rendimiento\resultados" | Out-Null
$env:DB_NAME = "ticketia_perf"
python rendimiento\preparar_datos.py
$servidor = Start-Process -FilePath "python" -ArgumentList @("-m", "waitress", "--listen=127.0.0.1:$puerto", "--threads=8", "app:app") -PassThru -WindowStyle Hidden
Start-Sleep -Seconds 6
try {
    Write-Host "=== 1) Referencia: 10 usuarios ==="
    locust -f rendimiento/locustfile.py --headless -u 10 -r 5 -t 40s --reset-stats --stop-timeout 10 --host $host_url --csv "$salida/${Prefijo}_estres_1_referencia"
    Write-Host "=== 2) Estres: 200 usuarios ==="
    locust -f rendimiento/locustfile.py --headless -u 200 -r 10 -t 85s --reset-stats --stop-timeout 10 --host $host_url --csv "$salida/${Prefijo}_estres_2_sobrecarga"
    Write-Host "=== 3) Recuperacion: 10 usuarios ==="
    locust -f rendimiento/locustfile.py --headless -u 10 -r 5 -t 40s --reset-stats --stop-timeout 10 --host $host_url --csv "$salida/${Prefijo}_estres_3_recuperacion"
}
finally {
    Stop-Process -Id $servidor.Id -Force -ErrorAction SilentlyContinue
    Remove-Item Env:DB_NAME -ErrorAction SilentlyContinue
}
Write-Host ""
Write-Host "Listo. Resultados en rendimiento\resultados\ (archivos ${Prefijo}_estres_*_stats.csv)"
