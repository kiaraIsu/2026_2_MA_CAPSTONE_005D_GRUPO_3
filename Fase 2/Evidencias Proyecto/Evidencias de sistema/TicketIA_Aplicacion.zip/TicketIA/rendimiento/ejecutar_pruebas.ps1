<#
 Ejecuta las pruebas de carga de TicketIA en Windows (PowerShell).

 Uso, desde la carpeta del sistema (donde esta app.py):
     powershell -ExecutionPolicy Bypass -File rendimiento\ejecutar_pruebas.ps1

 Opciones:  -Niveles 10,25,50,60,75   -Prefijo final
 Requisitos: PostgreSQL en marcha (docker compose up -d db) y
             pip install -r requirements.txt -r rendimiento/requirements.txt

 Para cada nivel de usuarios: reinicia los datos, inicia el sistema, mide y lo detiene.
 Resultados: rendimiento\resultados\final_carga_N_stats.csv
 No uses el computador mientras corre: el resultado se altera.
#>
param(
    [int[]]$Niveles = @(10, 25, 50, 60, 75),
    [string]$Prefijo = "final"
)
$ErrorActionPreference = "Continue"
$puerto = 5057
New-Item -ItemType Directory -Force -Path "rendimiento\resultados" | Out-Null
$env:DB_NAME = "ticketia_perf"
foreach ($n in $Niveles) {
    Write-Host ""
    Write-Host "=== $n usuarios simultaneos ==="
    python rendimiento\preparar_datos.py
    $servidor = Start-Process -FilePath "python" -ArgumentList @("-m", "waitress", "--listen=127.0.0.1:$puerto", "--threads=8", "app:app") -PassThru -WindowStyle Hidden
    Start-Sleep -Seconds 6
    try {
        # 1 usuario nuevo por segundo; cuando todos iniciaron sesion se mide durante 1 minuto
        locust -f rendimiento/locustfile.py --headless -u $n -r 1 -t "$($n + 60)s" --reset-stats --host "http://127.0.0.1:$puerto" --csv "rendimiento/resultados/${Prefijo}_carga_$n"
    }
    finally {
        Stop-Process -Id $servidor.Id -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
}
Remove-Item Env:DB_NAME -ErrorAction SilentlyContinue
Write-Host ""
Write-Host "Listo. Resultados en rendimiento\resultados\ (archivos ${Prefijo}_carga_N_stats.csv)"
