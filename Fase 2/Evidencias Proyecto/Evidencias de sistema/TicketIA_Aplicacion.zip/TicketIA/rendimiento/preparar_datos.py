"""Prepara una base de datos SEPARADA ("ticketia_perf") con datos realistas para las pruebas de rendimiento.

Uso (desde la carpeta del proyecto, con PostgreSQL en marcha):
    python rendimiento/preparar_datos.py
Crea la base si no existe, recrea las tablas y carga 300 tickets con comentarios e historial.
"""
import os
import random
import sys
from datetime import datetime, timedelta, timezone

import psycopg2

os.environ["DB_NAME"] = os.environ.get("PERF_DB_NAME", "ticketia_perf")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import database as db  # noqa: E402


def asegurar_base():
    conn = psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"), dbname="postgres",
                            user=os.environ.get("DB_USER", "ticketia_user"), password=os.environ.get("DB_PASSWORD", "ticketia_pass"))
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (os.environ["DB_NAME"],))
        if cur.fetchone() is None:
            cur.execute('CREATE DATABASE "%s"' % os.environ["DB_NAME"])
    conn.close()


def main(n_tickets=300):
    asegurar_base()
    db.reset_db()
    db.init_db()
    conn = db.get_db()
    uid = lambda email: db.query_one(conn, "SELECT id FROM usuarios WHERE email = %s", (email,))["id"]
    funcionarios = [uid("pedro.funcionario@municipalidad.cl"), uid("ana.funcionaria@municipalidad.cl")]
    tecnicos = [uid("kiara.tecnico@municipalidad.cl"), uid("marcela.tecnico@municipalidad.cl")]
    categorias = [f["id"] for f in db.query_all(conn, "SELECT id FROM categorias")]
    random.seed(42)
    ahora = datetime.now(timezone.utc)
    estados = ["pendiente", "en_progreso", "en_revision", "resuelto", "cerrado"]
    for i in range(n_tickets):
        creado = ahora - timedelta(hours=random.randint(1, 24 * 60))
        estado = random.choice(estados)
        tecnico = random.choice(tecnicos) if estado != "pendiente" else None
        t = db.query_one(
            conn,
            "INSERT INTO tickets (titulo, descripcion, categoria_id, prioridad_id, estado_id, usuario_id, tecnico_id, creado_en, actualizado_en) "
            "VALUES (%s, %s, %s, (SELECT id FROM prioridades WHERE codigo = %s), (SELECT id FROM estados WHERE codigo = %s), %s, %s, %s, %s) RETURNING id",
            (f"Solicitud de soporte número {i + 1}", "Descripción de prueba para medir el rendimiento del sistema.", random.choice(categorias),
             random.choice(["baja", "media", "alta"]), estado, random.choice(funcionarios), tecnico, creado, creado))
        for k in range(random.randint(0, 3)):
            db.execute(conn, "INSERT INTO comentarios (ticket_id, usuario_id, contenido, creado_en) VALUES (%s, %s, %s, %s)",
                       (t["id"], random.choice(funcionarios + tecnicos), f"Comentario de prueba {k + 1}", creado + timedelta(minutes=10 * (k + 1))))
        db.execute(conn, "INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, 'Ticket creado', %s)", (t["id"], funcionarios[0], creado))
    conn.commit()
    conn.close()
    print(f"Base '{os.environ['DB_NAME']}' lista con {n_tickets} tickets.")


if __name__ == "__main__":
    main()
