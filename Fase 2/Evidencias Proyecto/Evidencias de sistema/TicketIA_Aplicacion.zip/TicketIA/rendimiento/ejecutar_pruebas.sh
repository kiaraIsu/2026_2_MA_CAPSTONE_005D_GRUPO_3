#!/bin/bash
# Ejecuta las pruebas de carga de TicketIA en Linux, Mac o WSL.
# Uso (desde la carpeta del proyecto):  bash rendimiento/ejecutar_pruebas.sh
set -e
NIVELES="${NIVELES:-10 25 50 60 75}"            # usuarios simultáneos a probar
PUERTO=5057
for N in $NIVELES; do
  python rendimiento/preparar_datos.py          # datos reiniciados: cada nivel parte igual
  DB_NAME=ticketia_perf gunicorn -w 3 -b 127.0.0.1:$PUERTO app:app > /dev/null 2>&1 &
  PID=$!
  sleep 4
  # 1 usuario nuevo por segundo; después de que todos iniciaron sesión se mide 1 minuto
  locust -f rendimiento/locustfile.py --headless -u $N -r 1 -t $((N + 60))s --reset-stats \
         --host http://127.0.0.1:$PUERTO --csv rendimiento/resultados/carga_$N
  kill $PID; sleep 2
done
echo "Listo. Resultados en rendimiento/resultados/ (archivos carga_N_stats.csv)"
