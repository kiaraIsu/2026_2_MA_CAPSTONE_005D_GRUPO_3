"""Pruebas de rendimiento de TicketIA con Locust.

Simula usuarios reales de los tres roles (funcionario, técnico y administrador) que inician sesión y
navegan por el sistema con pausas de 1 a 3 segundos entre acciones.

Ejemplo (sin interfaz web, 50 usuarios durante 60 s):
    locust -f rendimiento/locustfile.py --headless -u 50 -r 5 -t 60s --reset-stats --host http://127.0.0.1:5057
"""
import random
import re

from locust import HttpUser, between, task

IDS = re.compile(r"/tickets/(\d+)")
TOKEN = re.compile(r'name="csrf_token" value="([^"]+)"')


def token_de(respuesta):
    """Token CSRF que el servidor incluye en cada formulario."""
    m = TOKEN.search(respuesta.text)
    return m.group(1) if m else ""


class UsuarioBase(HttpUser):
    abstract = True
    wait_time = between(1, 3)
    credenciales = ("", "")

    def on_start(self):
        pagina = self.client.get("/login", name="GET /login")
        self.client.post("/login", data={"email": self.credenciales[0], "password": self.credenciales[1], "csrf_token": token_de(pagina)}, name="POST /login")
        self.ids = []
        self._cargar_ids()

    def _cargar_ids(self):
        r = self.client.get("/tickets", name="GET /tickets (carga inicial)")
        self.ids = list(set(IDS.findall(r.text))) or []

    def _detalle(self):
        if self.ids:
            self.client.get(f"/tickets/{random.choice(self.ids)}", name="GET /tickets/<id>")


class Funcionario(UsuarioBase):
    weight = 6
    credenciales = ("pedro.funcionario@municipalidad.cl", "usuario123")

    @task(5)
    def mis_solicitudes(self):
        self.client.get("/dashboard", name="GET /dashboard (mis solicitudes)")

    @task(3)
    def listado(self):
        self.client.get("/tickets", name="GET /tickets")

    @task(2)
    def detalle(self):
        self._detalle()

    @task(1)
    def crear_ticket(self):
        pagina = self.client.get("/tickets/nuevo", name="GET /tickets/nuevo")
        self.client.post("/tickets/nuevo", data={"titulo": "Prueba de carga: equipo lento", "descripcion": "Solicitud creada por la prueba de rendimiento.",
                                                  "categoria_id": "1", "prioridad": "media", "csrf_token": token_de(pagina)}, name="POST /tickets/nuevo")


class Tecnico(UsuarioBase):
    weight = 3
    credenciales = ("kiara.tecnico@municipalidad.cl", "tecnico123")

    @task(5)
    def mi_tablero(self):
        self.client.get("/dashboard", name="GET /dashboard (tablero técnico)")

    @task(2)
    def listado(self):
        self.client.get("/tickets", name="GET /tickets")

    @task(2)
    def detalle(self):
        self._detalle()


class Administrador(UsuarioBase):
    weight = 1
    credenciales = ("jade.admin@municipalidad.cl", "admin123")

    @task(4)
    def panel(self):
        self.client.get("/dashboard", name="GET /dashboard (panel administrador)")

    @task(3)
    def listado(self):
        self.client.get("/tickets", name="GET /tickets")

    @task(1)
    def usuarios(self):
        self.client.get("/admin/usuarios", name="GET /admin/usuarios")

    @task(1)
    def detalle(self):
        self._detalle()
