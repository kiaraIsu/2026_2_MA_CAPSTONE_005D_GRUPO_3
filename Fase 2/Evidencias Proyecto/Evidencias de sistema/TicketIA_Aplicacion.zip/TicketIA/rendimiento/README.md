# Pruebas de rendimiento de TicketIA

**Tipo de prueba:** rendimiento, carga y estrés. **Objetivo:** medir el tiempo de respuesta y cuántos usuarios
simultáneos soporta la aplicación, y compararlo con el KPI del proyecto (percentil 95 de 500 ms o menos).
**Herramienta:** [Locust](https://locust.io) (generador de carga en Python).

## Contenido
- `locustfile.py`: los usuarios virtuales (funcionario, técnico y administrador) y sus acciones.
- `preparar_datos.py`: crea la base `ticketia_perf` con 300 tickets de prueba (no toca tu base de desarrollo).
- `ejecutar_pruebas.sh`: ejecuta varios niveles de carga seguidos (Linux, Mac o WSL).
- `ejecutar_estres.sh`: prueba de estrés con referencia, sobrecarga y recuperación.
- `resultados/`: archivos CSV de la última medición, el gráfico, el resumen y el entorno usado.

## Cómo ejecutarlas
1. Tener PostgreSQL en marcha (con Docker: `docker compose up -d db`).
2. Instalar las herramientas: `pip install -r requirements.txt -r rendimiento/requirements.txt`
3. Preparar los datos: `python rendimiento/preparar_datos.py`
4. Iniciar la aplicación apuntando a esa base:
   - Linux/Mac/WSL: `DB_NAME=ticketia_perf gunicorn -w 3 -b 127.0.0.1:5057 app:app`
   - Windows (PowerShell): `pip install waitress` y luego `$env:DB_NAME="ticketia_perf"; waitress-serve --port=5057 app:app`
5. En otra terminal, ejecutar la carga (por ejemplo, 25 usuarios):
   `locust -f rendimiento/locustfile.py --headless -u 25 -r 1 -t 85s --reset-stats --host http://127.0.0.1:5057 --csv rendimiento/resultados/carga_25`
6. Revisar el CSV (`carga_25_stats.csv`): la fila *Aggregated* tiene la mediana y el percentil 95 (`95%`).

Para ver los resultados en una interfaz web, ejecuta `locust -f rendimiento/locustfile.py` y abre http://localhost:8089.

## Prueba de estrés
`bash rendimiento/ejecutar_estres.sh` (Linux, Mac o WSL) mide con 10 usuarios, sobrecarga el sistema con 200 y vuelve a medir con 10 en el mismo servidor,
para ver si falla y si se recupera.

## Resultados (máquina de 1 núcleo, datos reiniciados en cada nivel)
| Usuarios | Mediana (ms) | Percentil 95 (ms) | Errores | ¿Cumple 500 ms? |
|---|---|---|---|---|
| 10 | 38 | 87 | 0 | Sí |
| 25 | 48 | 110 | 0 | Sí |
| 50 | 100 | 270 | 0 | Sí |
| 60 | 160 | 410 | 0 | Sí |
| 75 | 600 | 1300 | 0 | No |
| 100 | 1500 | 2800 | 0 | No |

**Estrés (200 usuarios):** sin errores; mediana de 4,4 s y percentil 95 de 11 s. Al bajar la carga a 10 usuarios, el percentil 95 volvió a 160 ms (antes: 170 ms).

Con más núcleos o con mejoras (paginación y grupo de conexiones) se espera mayor capacidad.
Informe completo: `docs/pruebas/Informe_Pruebas_de_Rendimiento_TicketIA.docx`.
