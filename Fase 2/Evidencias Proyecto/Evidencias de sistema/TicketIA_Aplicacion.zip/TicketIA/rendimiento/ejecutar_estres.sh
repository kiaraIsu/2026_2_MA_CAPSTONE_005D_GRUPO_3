#!/bin/bash
# Prueba de estrés de TicketIA (Linux, Mac o WSL): sobrecarga el sistema y comprueba si se recupera.
#   1) Referencia: 10 usuarios (carga normal)
#   2) Estrés: 200 usuarios, muy por encima de la capacidad
#   3) Recuperación: otra vez 10 usuarios, con el mismo servidor, para ver si vuelve a responder como antes
# Uso (desde la carpeta del proyecto):  bash rendimiento/ejecutar_estres.sh
set -e
PUERTO=5057; HOST=http://127.0.0.1:$PUERTO; SALIDA=rendimiento/resultados
python rendimiento/preparar_datos.py
DB_NAME=ticketia_perf gunicorn -w 3 -b 127.0.0.1:$PUERTO app:app > /dev/null 2>&1 &
PID=$!
trap "kill $PID 2>/dev/null" EXIT
sleep 4
locust -f rendimiento/locustfile.py --headless -u 10  -r 5  -t 40s --reset-stats --stop-timeout 10 --host $HOST --csv $SALIDA/estres_1_referencia
locust -f rendimiento/locustfile.py --headless -u 200 -r 10 -t 85s --reset-stats --stop-timeout 10 --host $HOST --csv $SALIDA/estres_2_sobrecarga
locust -f rendimiento/locustfile.py --headless -u 10  -r 5  -t 40s --reset-stats --stop-timeout 10 --host $HOST --csv $SALIDA/estres_3_recuperacion
echo "Listo. Resultados en $SALIDA/estres_*_stats.csv"
