"""
ai_classifier.py
Módulo de "inteligencia artificial" para TicketIA (HU-13).

La clasificación automática funciona en dos niveles:

1. Motor avanzado (opcional). Si se configura `MOTOR_AVANZADO` con una función (por ejemplo,
   una llamada a un modelo entrenado o a un modelo de lenguaje), se usa primero.
2. Estrategia de respaldo por reglas y palabras clave. Se usa cuando no hay motor avanzado,
   cuando este falla (tiempo de espera, caída del servicio, error interno) o cuando su respuesta
   no es válida. Así la creación de un ticket nunca se impide por la clasificación.

El resto del sistema solo llama a `clasificar_ticket`.
"""

import re
import unicodedata

PRIORIDADES_VALIDAS = ("alta", "media", "baja")

# Función opcional con la firma (titulo, descripcion, categorias_disponibles) -> {"categoria_id", "prioridad"}.
# None significa que el motor avanzado no está disponible.
MOTOR_AVANZADO = None


# ---------------------------------------------------------------------------
# Vocabulario por categoría: (patrón, peso). Peso 3 = señal fuerte, 2 = normal, 1 = débil.
# Las palabras terminadas en * son raíces (impres* = impresora, imprimir...). Las demás se buscan
# como palabra completa, para que "red" no coincida dentro de "credenciales".
# ---------------------------------------------------------------------------
VOCABULARIO = {
    "Hardware": [
        ("impresora*", 3), ("impresor*", 3), ("computador*", 3), ("notebook*", 3), ("laptop*", 3), ("portatil*", 3), ("monitor*", 3),
        ("pantalla*", 2), ("teclado*", 3), ("mouse", 3), ("raton", 3), ("escaner*", 3), ("toner", 3), ("tinta", 3), ("cartucho*", 3),
        ("webcam", 3), ("camara*", 3), ("parlante*", 3), ("altavoz*", 3), ("microfono*", 3), ("audifono*", 3), ("ups", 3), ("cpu", 3),
        ("fuente de poder", 3), ("bateria*", 3), ("cargador*", 3), ("ventilador*", 3), ("disco duro", 3), ("pendrive*", 3), ("proyector*", 3),
        ("respaldo de energia", 3), ("no enciende", 3), ("no prende", 3), ("se apaga", 2), ("pc", 3), ("equipo*", 1), ("cable*", 1),
        ("enchufe*", 2), ("energia", 1), ("telefono ip", 2), ("lector*", 1),
    ],
    "Redes e Internet": [
        ("internet", 3), ("wifi", 3), ("wi-fi", 3), ("red", 3), ("redes", 3), ("router*", 3), ("modem*", 3), ("switch*", 3), ("cortafuego*", 3),
        ("firewall*", 3), ("vpn", 3), ("conexion*", 3), ("conectividad", 3), ("ancho de banda", 3), ("sin senal", 3), ("punto de red", 3),
        ("conecta*", 2), ("conectar*", 2), ("navegacion", 2), ("senal", 2), ("lent*", 1), ("se corta", 1), ("servidor*", 1),
        ("acced* al servidor", 2), ("acceso al servidor", 2), ("intermitente*", 2),
    ],
    "Software": [
        ("programa*", 3), ("aplicacion*", 3), ("software", 3), ("excel", 4), ("word", 4), ("powerpoint", 4), ("office", 4), ("licencia*", 3),
        ("instalar", 3), ("instalacion*", 3), ("actualizacion*", 3), ("actualizar", 3), ("pantalla azul", 3), ("pdf*", 3), ("navegador*", 3),
        ("chrome", 4), ("firefox", 4), ("antivirus", 4), ("macro*", 3), ("plugin*", 3), ("no abre", 3), ("se cierra", 3), ("bug", 3),
        ("formula*", 3), ("planilla*", 3), ("plantilla*", 3), ("formulario*", 3), ("driver*", 3), ("windows", 4), ("zoom", 4), ("teams", 4),
        ("sistema*", 1), ("sistema de permisos", 4), ("sistema de patentes", 4), ("sistema de ingresos", 4), ("gestion documental", 4), ("error*", 1), ("falla*", 1), ("portal*", 1), ("se cae", 1), ("pantalla azul", 3),
    ],
    "Cuentas y Accesos": [
        ("contrasena*", 3), ("clave*", 3), ("password", 3), ("usuario*", 3), ("credencial*", 3), ("iniciar sesion", 3), ("inicio de sesion", 3),
        ("sesion", 2), ("acceso*", 2), ("permiso*", 3), ("bloquead*", 2), ("verificacion", 3), ("autenticacion", 3), ("cuenta*", 2),
        ("perfil*", 2), ("desbloquear", 3), ("habilitar", 1), ("entrar", 1), ("login", 3), ("autorizad*", 2),
    ],
    "Correo Electrónico": [
        ("correo*", 3), ("email*", 3), ("e-mail*", 3), ("outlook", 4), ("gmail", 4), ("casilla*", 3), ("bandeja*", 3), ("spam", 3), ("remitente*", 3),
        ("calendario*", 3), ("rebot*", 3), ("no entregado*", 3), ("phishing", 3), ("suplant*", 2), ("estafa*", 2), ("mensaje*", 1), ("adjunto*", 1),
        ("firma", 1), ("alias", 2), ("lista de distribucion", 3), ("no llegan", 2), ("no envia", 2),
    ],
    "Otros": [
        ("capacitacion*", 5), ("charla*", 5), ("taller*", 5), ("curso*", 5), ("cotiz*", 3), ("presupuesto*", 3), ("inventario*", 3), ("informe*", 3),
        ("reunion*", 3), ("coordinar*", 3), ("traslado*", 3), ("mudanza*", 3), ("prestamo*", 3), ("evento*", 5), ("acto civico", 5),
        ("dar de baja", 3), ("retirar equipos", 3), ("horario*", 3), ("intranet", 3), ("transformacion digital", 3), ("digitalizacion", 3),
        ("propuesta*", 2), ("listado*", 2), ("registro de activos", 3), ("activos", 2), ("respald*", 2), ("soporte nocturno", 3), ("fuera de horario", 3),
        ("remodelacion*", 3), ("cambio de oficina", 3), ("cambiamos de oficina", 3), ("mover* los equipos", 3), ("corte de luz", 3), ("recuperar*", 2), ("corte de energia", 3), ("obsoleto*", 3), ("transferir llamadas", 3), ("telefono nuevo", 2),
    ],
}

# Prioridad alta: impacto operativo severo, muchas personas afectadas, pérdida de datos o riesgo de seguridad.
SENALES_ALTA = [
    (r"\burgente", 2), (r"\bcritic[oa]", 2), (r"\bnadie\b", 2), (r"\bninguno?a? (de|en|puede)", 2), (r"\btodos? (los|las|el|ella)", 2),
    (r"\btodo el (departamento|municipio|edificio|equipo|personal|piso)", 2), (r"\btoda la (oficina|municipalidad|direccion|area|institucion)", 2),
    (r"\b(departamento|direccion|oficina|area) (completo|completa)", 2), (r"\bsin internet\b", 2), (r"\bse cayo\b|\bcaid[oa]\b", 2),
    (r"\bno funciona nada\b", 2), (r"\bno puedo trabajar\b|\bno se puede (trabajar|atender)\b|\bno hay como atender\b", 2),
    (r"\bperdida de (datos|informacion|archivos)\b|\bperdi (la |mi |el |los |las |todo |todos )?(informacion|datos|archivos|trabajo|documentos|borradores)\b|\bse borr(o|aron)\b|\bborraron\b", 2), (r"\bno enciende\b|\bno prende\b|\bno arranca\b|\bno inicia\b", 2),
    (r"\bsuplant\w*|\bestafa\w*|\bphishing\b|\bhackeo\b|\bataque\b|\bvirus\b", 2), (r"\bsospechos\w*|\bdesconocid[oa]\b|\botra (ciudad|pais)\b", 2),
    (r"\bex funcionari[oa]\b|\brenuncio\b", 2), (r"\bplazos? legales?\b|\bcierre (de ano|mensual|de mes)\b", 2), (r"\bunico\b", 2),
    (r"\b([5-9]|[1-9]\d+) (personas|funcionarios|usuarios|tecnicos|equipos|pantallas|computadores|empleados)\b", 2), (r"\bse detuvo\b|\bdetenid[oa]\b", 2),
    (r"\bperdiendo\b|\bperdidos\b", 1), (r"\bvarios (usuarios|funcionarios|equipos|departamentos|tecnicos)\b", 2), (r"\bno se ve nada\b", 2), (r"\balcald\w+", 2), (r"\bcamaras? de seguridad\b", 2), (r"\bcorte de (luz|energia)\b", 1), (r"\bquedaron apagad\w+", 1), (r"\bservidor", 1), (r"\berror 500\b", 2), (r"\bhoy mismo\b|\binmediat\w*|\bahora mismo\b", 1),
    (r"\batencion (al|de) publico\b|\bcontribuyentes\b", 1), (r"\bpitando\b|\bpita sin parar\b", 1),
]

# Prioridad baja: consultas, sugerencias o solicitudes planificables que no impiden trabajar.
SENALES_BAJA = [
    (r"\bconsulta\b", 2), (r"\bduda\b", 2), (r"\bpregunta\b", 1), (r"\bsugerencia\b|\bsugiero\b", 2), (r"\bmejora\b", 1), (r"\bidea\b", 1),
    (r"\bpropuesta\b|\bpropongo\b", 1), (r"\bcuando (puedan|pueda|haya|tengan|quieran)\b", 2), (r"\bsin apuro\b|\bsin prisa\b|\bno corre prisa\b|\bno es urgente\b|\bno urgente\b", 2),
    (r"\bcapacitacion\b|\bcharla\b|\btaller\b", 1), (r"\bcotiz\w+|\binventario\b|\binforme\b|\bhorario\b", 1), (r"^como\b|\b¿?como (hago|uso|se|puedo|respaldo|agrupo|reservo|transfiero|configuro|cambio)\b", 2),
    (r"\bquisiera saber\b|\bme gustaria\b|\bseria (bueno|util)\b|\bquizas\b|\bsolo una consulta\b", 2), (r"\bsolo (es )?molest\w+\b|\bno se ha apagado\b|\bpuedo trabajar\b|\bigual (puedo|funciona)\b|\bse puede usar\b|\bse puede leer\b", 1),
    (r"\bsolicito (un|una|el|la|cambio)\b", 1), (r"\bevaluar\b|\bdar de baja\b|\bretirar\b|\bsolicitud de (un|una|nuevo|nueva)\b|\bpedido de\b|\bquiero (un|una|instalar|cambiar|actualizar|agendar)\b", 2), (r"\bspam\b|\bofertas\b|\bpublicidad\b|\bpropaganda\b", 1), (r"\b(caduca|vence) en \d+", 2), (r"\bnuevo (equipo|usuario)\b|\bpara el (proximo|ano)\b", 1),
]

# Expresiones que anulan una señal de urgencia ("no es urgente", "sin urgencia").
_NEGACIONES = re.compile(r"\bno es urgente\b|\bno urgente\b|\bsin urgencia\b|\bno corre prisa\b|\bsin apuro\b|\bsin prisa\b")


def _normalizar(texto) -> str:
    """Minúsculas y sin tildes, para comparar de forma robusta."""
    texto = unicodedata.normalize("NFKD", str(texto or "").lower())
    return "".join(c for c in texto if not unicodedata.combining(c))


def _compilar(patron: str):
    """Convierte una palabra o raíz (terminada en *) en una expresión regular por palabra completa."""
    if patron.endswith("*"):
        return re.compile(r"\b" + re.escape(patron[:-1]).replace("\\*", r"\w*") + r"\w*")
    base = re.escape(patron).replace("\\ ", " ")
    base = base.replace(r"\*", r"\w*")
    return re.compile(r"\b" + base + r"\b")


_VOCABULARIO_COMPILADO = {cat: [(_compilar(p), peso) for p, peso in items] for cat, items in VOCABULARIO.items()}
_ALTA = [(re.compile(p), peso) for p, peso in SENALES_ALTA]
_BAJA = [(re.compile(p), peso) for p, peso in SENALES_BAJA]


def _puntaje(texto: str, patrones) -> int:
    return sum(peso for rx, peso in patrones if rx.search(texto))


def clasificar_categoria(titulo: str, descripcion: str, categorias_disponibles: dict) -> int:
    """
    Devuelve el id de la categoría con mayor puntaje. El título pesa el doble, porque resume el problema.
    `categorias_disponibles` es un dict {nombre_categoria: id}. Si ninguna palabra coincide, devuelve el id de
    'Otros' o, si esa categoría no está disponible, el de la primera categoría disponible.
    """
    if not categorias_disponibles:
        raise ValueError("No hay categorías disponibles para clasificar.")
    titulo_n, desc_n = _normalizar(titulo), _normalizar(descripcion)
    completo = f"{titulo_n} {desc_n}"
    mejor, mejor_puntaje = None, 0
    for nombre, patrones in _VOCABULARIO_COMPILADO.items():
        if nombre not in categorias_disponibles:
            continue
        puntaje = _puntaje(completo, patrones) + _puntaje(titulo_n, patrones)
        if puntaje > mejor_puntaje:
            mejor, mejor_puntaje = nombre, puntaje
    if mejor is None:
        return categorias_disponibles.get("Otros", next(iter(categorias_disponibles.values())))
    return categorias_disponibles[mejor]


def clasificar_prioridad(titulo: str, descripcion: str = "") -> str:
    """Devuelve 'alta', 'media' o 'baja' según las señales presentes. Las negaciones anulan la urgencia."""
    texto = f"{_normalizar(titulo)} {_normalizar(descripcion)}"
    baja = _puntaje(texto, _BAJA)
    sin_negaciones = _NEGACIONES.sub(" ", texto)
    alta = _puntaje(sin_negaciones, _ALTA)
    if alta >= 2:
        return "alta"
    if baja >= 1:
        return "baja"
    return "media"


def clasificar_por_reglas(titulo: str, descripcion: str, categorias_disponibles: dict) -> dict:
    """Estrategia de respaldo basada en reglas y palabras clave."""
    return {
        "categoria_id": clasificar_categoria(titulo, descripcion, categorias_disponibles),
        "prioridad": clasificar_prioridad(titulo, descripcion),
    }


def _respuesta_valida(respuesta, categorias_disponibles: dict) -> bool:
    return (
        isinstance(respuesta, dict)
        and respuesta.get("categoria_id") in categorias_disponibles.values()
        and respuesta.get("prioridad") in PRIORIDADES_VALIDAS
    )


def clasificar_ticket(titulo: str, descripcion: str, categorias_disponibles: dict) -> dict:
    """
    Punto de entrada principal del módulo de IA.

    Retorna: {"categoria_id": int, "prioridad": str, "motor": "avanzado" | "reglas"}.
    Usa el motor avanzado cuando está disponible y responde bien; en cualquier otro caso usa las reglas.
    """
    titulo, descripcion = titulo or "", descripcion or ""
    motor = MOTOR_AVANZADO
    if motor is not None:
        try:
            respuesta = motor(titulo, descripcion, categorias_disponibles)
            if _respuesta_valida(respuesta, categorias_disponibles):
                return {"categoria_id": respuesta["categoria_id"], "prioridad": respuesta["prioridad"], "motor": "avanzado"}
        except Exception:  # noqa: BLE001 - cualquier falla del motor avanzado activa el respaldo
            pass
    resultado = clasificar_por_reglas(titulo, descripcion, categorias_disponibles)
    resultado["motor"] = "reglas"
    return resultado
