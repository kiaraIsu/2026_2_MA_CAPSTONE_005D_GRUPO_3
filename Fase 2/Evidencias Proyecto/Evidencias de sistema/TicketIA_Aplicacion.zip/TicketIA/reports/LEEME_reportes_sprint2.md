# Reportes de ejecución del Sprint 2

| Archivo | Qué es |
|---|---|
| `sprint2_ejecucion1_con_fallas.txt` | Primera ejecución de las 81 pruebas del sprint, antes de corregir: 54 aprobadas y 27 fallidas, que revelaron 8 defectos. |
| `sprint2_ejecucion2_final.txt` | Ejecución después de corregir: todas aprobadas (160 pruebas funcionales de los Sprints 1 y 2). |
| `junit_sprint2_final.xml` | Resultado de esa ejecución en formato JUnit. |
| `sprint2_ejecucion3_proyecto_completo.txt` | Ejecución de todo el proyecto con cobertura: 249 aprobadas y 88 % de cobertura. |

Estos reportes se generaron en el entorno de desarrollo. Cada integrante que ejecute las pruebas en su computador puede agregar el suyo:

    python -m pytest -m "hu05 or hu06 or hu07 or hu08 or hu09 or hu19" -v | Tee-Object reports\sprint2_ejecucion_equipo.txt
