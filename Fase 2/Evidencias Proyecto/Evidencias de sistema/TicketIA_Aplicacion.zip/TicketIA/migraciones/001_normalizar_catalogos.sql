-- Migración 001: normalización de la base de datos de TicketIA.
--
-- Qué hace:
--   * Crea las tablas catálogo roles, estados, prioridades y direcciones.
--   * Reemplaza usuarios.rol y usuarios.direccion por usuarios.rol_id y usuarios.direccion_id.
--   * Reemplaza tickets.estado y tickets.prioridad por tickets.estado_id y tickets.prioridad_id.
--   * Une las direcciones repetidas que solo diferían en mayúsculas o espacios ("DIDECO" y " dideco ").
--   * Crea los índices y las vistas v_usuarios y v_tickets.
-- Conserva todos los datos y se puede ejecutar más de una vez sin dañar nada.
--
-- Cuándo usarla: en una base creada con la versión anterior del sistema (antes de ejecutar la aplicación nueva).
-- Una base nueva no la necesita: la aplicación crea el esquema normalizado sola.
--
-- Cómo ejecutarla:   psql -h localhost -U ticketia_user -d ticketia -f migraciones/001_normalizar_catalogos.sql
-- Recomendación: respalda antes la base (pg_dump -U ticketia_user ticketia > respaldo.sql).

BEGIN;

-- 1) Tablas catálogo
CREATE TABLE IF NOT EXISTS roles (id SERIAL PRIMARY KEY, codigo TEXT NOT NULL UNIQUE, nombre TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS estados (id SERIAL PRIMARY KEY, codigo TEXT NOT NULL UNIQUE, nombre TEXT NOT NULL, orden INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS prioridades (id SERIAL PRIMARY KEY, codigo TEXT NOT NULL UNIQUE, nombre TEXT NOT NULL, orden INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS direcciones (id SERIAL PRIMARY KEY, nombre TEXT NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS idx_direcciones_nombre ON direcciones (lower(nombre));

INSERT INTO roles (codigo, nombre) VALUES ('usuario', 'Funcionario'), ('tecnico', 'Técnico'), ('administrador', 'Administrador') ON CONFLICT (codigo) DO NOTHING;
INSERT INTO estados (codigo, nombre, orden) VALUES ('pendiente', 'Pendiente', 1), ('en_progreso', 'En progreso', 2), ('en_revision', 'En revisión', 3),
                                                   ('resuelto', 'Resuelto', 4), ('cerrado', 'Cerrado', 5) ON CONFLICT (codigo) DO NOTHING;
INSERT INTO prioridades (codigo, nombre, orden) VALUES ('alta', 'Alta', 1), ('media', 'Media', 2), ('baja', 'Baja', 3) ON CONFLICT (codigo) DO NOTHING;

-- 2) usuarios: rol y dirección pasan a ser referencias
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'usuarios' AND column_name = 'rol') THEN
        ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS rol_id INTEGER REFERENCES roles(id);
        ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS direccion_id INTEGER REFERENCES direcciones(id);

        UPDATE usuarios u SET rol_id = r.id FROM roles r WHERE r.codigo = u.rol;

        INSERT INTO direcciones (nombre)
        SELECT DISTINCT ON (lower(n)) n
        FROM (SELECT regexp_replace(btrim(direccion), '\s+', ' ', 'g') AS n FROM usuarios WHERE direccion IS NOT NULL AND btrim(direccion) <> '') x
        ORDER BY lower(n), n
        ON CONFLICT ((lower(nombre))) DO NOTHING;

        UPDATE usuarios u SET direccion_id = d.id FROM direcciones d
        WHERE u.direccion IS NOT NULL AND lower(d.nombre) = lower(regexp_replace(btrim(u.direccion), '\s+', ' ', 'g'));

        ALTER TABLE usuarios ALTER COLUMN rol_id SET NOT NULL;
        ALTER TABLE usuarios DROP COLUMN rol;
        ALTER TABLE usuarios DROP COLUMN direccion;
    END IF;
END $$;

-- 3) tickets: estado y prioridad pasan a ser referencias
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tickets' AND column_name = 'estado') THEN
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS estado_id INTEGER REFERENCES estados(id);
        ALTER TABLE tickets ADD COLUMN IF NOT EXISTS prioridad_id INTEGER REFERENCES prioridades(id);

        UPDATE tickets t SET estado_id = e.id FROM estados e WHERE e.codigo = t.estado;
        UPDATE tickets t SET prioridad_id = p.id FROM prioridades p WHERE p.codigo = t.prioridad;

        ALTER TABLE tickets ALTER COLUMN estado_id SET NOT NULL;
        ALTER TABLE tickets ALTER COLUMN prioridad_id SET NOT NULL;
        ALTER TABLE tickets DROP COLUMN estado;
        ALTER TABLE tickets DROP COLUMN prioridad;
    END IF;
END $$;

-- 4) Índices y vistas de lectura
CREATE INDEX IF NOT EXISTS idx_tickets_estado ON tickets(estado_id);
CREATE INDEX IF NOT EXISTS idx_tickets_prioridad ON tickets(prioridad_id);
CREATE INDEX IF NOT EXISTS idx_usuarios_rol ON usuarios(rol_id);
CREATE INDEX IF NOT EXISTS idx_usuarios_direccion ON usuarios(direccion_id);

CREATE OR REPLACE VIEW v_usuarios AS
SELECT u.id, u.nombre, u.email, u.password_hash, r.codigo AS rol, r.nombre AS rol_nombre, d.nombre AS direccion,
       u.rol_id, u.direccion_id, u.activo, u.creado_en
FROM usuarios u
JOIN roles r ON r.id = u.rol_id
LEFT JOIN direcciones d ON d.id = u.direccion_id;

CREATE OR REPLACE VIEW v_tickets AS
SELECT t.id, t.titulo, t.descripcion, t.categoria_id, p.codigo AS prioridad, e.codigo AS estado,
       t.prioridad_id, t.estado_id, t.usuario_id, t.tecnico_id, t.clasificado_por_ia, t.solucion,
       t.reapertura_solicitada, t.creado_en, t.actualizado_en
FROM tickets t
JOIN prioridades p ON p.id = t.prioridad_id
JOIN estados e ON e.id = t.estado_id;

COMMIT;
