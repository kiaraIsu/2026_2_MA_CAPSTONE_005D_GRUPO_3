"""
database.py
Capa de acceso a datos de TicketIA, usando PostgreSQL (psycopg2).

La conexión se configura mediante variables de entorno (ver .env.example):
    DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
"""

import os
from datetime import datetime, timezone

import psycopg2
import psycopg2.extras
from werkzeug.security import generate_password_hash

DB_HOST = os.environ.get("DB_HOST", "localhost")
DB_PORT = os.environ.get("DB_PORT", "5432")
DB_NAME = os.environ.get("DB_NAME", "ticketia")
DB_USER = os.environ.get("DB_USER", "ticketia_user")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "ticketia_pass")

SCHEMA = """
-- Tablas catálogo (normalización): cada valor se guarda una sola vez y las demás tablas lo referencian por su id.
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS estados (
    id SERIAL PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    orden INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS prioridades (
    id SERIAL PRIMARY KEY,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    orden INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS direcciones (
    id SERIAL PRIMARY KEY,
    nombre TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_direcciones_nombre ON direcciones (lower(nombre));

CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    nombre TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    rol_id INTEGER NOT NULL REFERENCES roles(id),
    direccion_id INTEGER REFERENCES direcciones(id),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS categorias (
    id SERIAL PRIMARY KEY,
    nombre TEXT NOT NULL UNIQUE,
    activa BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS tickets (
    id SERIAL PRIMARY KEY,
    titulo TEXT NOT NULL,
    descripcion TEXT NOT NULL,
    categoria_id INTEGER NOT NULL REFERENCES categorias(id),
    prioridad_id INTEGER NOT NULL REFERENCES prioridades(id),
    estado_id INTEGER NOT NULL REFERENCES estados(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    tecnico_id INTEGER REFERENCES usuarios(id),
    clasificado_por_ia BOOLEAN NOT NULL DEFAULT FALSE,
    solucion TEXT,
    reapertura_solicitada BOOLEAN NOT NULL DEFAULT FALSE,
    creado_en TIMESTAMPTZ NOT NULL,
    actualizado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS comentarios (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    contenido TEXT NOT NULL,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS adjuntos (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    nombre_archivo TEXT NOT NULL,
    ruta TEXT NOT NULL,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS historial (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL REFERENCES tickets(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    accion TEXT NOT NULL,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS evaluaciones (
    id SERIAL PRIMARY KEY,
    ticket_id INTEGER NOT NULL UNIQUE REFERENCES tickets(id),
    puntaje INTEGER NOT NULL CHECK (puntaje BETWEEN 1 AND 5),
    comentario TEXT,
    creado_en TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_tickets_usuario ON tickets(usuario_id);
CREATE INDEX IF NOT EXISTS idx_tickets_tecnico ON tickets(tecnico_id);
CREATE INDEX IF NOT EXISTS idx_tickets_estado ON tickets(estado_id);
CREATE INDEX IF NOT EXISTS idx_tickets_prioridad ON tickets(prioridad_id);
CREATE INDEX IF NOT EXISTS idx_usuarios_rol ON usuarios(rol_id);
CREATE INDEX IF NOT EXISTS idx_usuarios_direccion ON usuarios(direccion_id);
CREATE INDEX IF NOT EXISTS idx_comentarios_ticket ON comentarios(ticket_id);
CREATE INDEX IF NOT EXISTS idx_historial_ticket ON historial(ticket_id);

-- Vistas de lectura: muestran los códigos (rol, estado, prioridad) y la dirección como texto, uniendo los catálogos.
CREATE OR REPLACE VIEW v_usuarios AS
SELECT u.id, u.nombre, u.email, u.password_hash, r.codigo AS rol, r.nombre AS rol_nombre, d.nombre AS direccion,
       u.rol_id, u.direccion_id, u.activo, u.creado_en
FROM usuarios u
JOIN roles r ON r.id = u.rol_id
LEFT JOIN direcciones d ON d.id = u.direccion_id;

CREATE OR REPLACE VIEW v_tickets AS
SELECT t.id, t.titulo, t.descripcion, t.categoria_id, p.codigo AS prioridad, e.codigo AS estado,
       t.prioridad_id, t.estado_id, t.usuario_id, t.tecnico_id, t.clasificado_por_ia, t.solucion,
       t.reapertura_solicitada, t.creado_en, t.actualizado_en
FROM tickets t
JOIN prioridades p ON p.id = t.prioridad_id
JOIN estados e ON e.id = t.estado_id;
"""

# Valores de los catálogos: (código, nombre, orden). El orden sirve para listar (la prioridad alta va primero).
ROLES_INICIALES = [("usuario", "Funcionario"), ("tecnico", "Técnico"), ("administrador", "Administrador")]
ESTADOS_INICIALES = [("pendiente", "Pendiente", 1), ("en_progreso", "En progreso", 2), ("en_revision", "En revisión", 3),
                     ("resuelto", "Resuelto", 4), ("cerrado", "Cerrado", 5)]
PRIORIDADES_INICIALES = [("alta", "Alta", 1), ("media", "Media", 2), ("baja", "Baja", 3)]

CATEGORIAS_INICIALES = [
    "Hardware",
    "Software",
    "Redes e Internet",
    "Cuentas y Accesos",
    "Correo Electrónico",
    "Otros",
]


def get_db():
    """
    Devuelve una nueva conexión a PostgreSQL.
    Las filas se devuelven como RealDictRow (se comportan como diccionarios,
    ej. row["nombre"]), para mantener el mismo estilo de acceso que se usaba
    con sqlite3.Row en la versión anterior del proyecto.
    """
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        cursor_factory=psycopg2.extras.RealDictCursor,
    )
    return conn


def now_ts():
    return datetime.now(timezone.utc)


def init_db(seed_demo_data=True, max_intentos=10, espera_segundos=2):
    """
    Crea las tablas si no existen y siembra datos base/demo.
    Reintenta la conexión varias veces por si PostgreSQL aún se está
    iniciando (por ejemplo, al levantar con docker-compose).
    """
    import time

    conn = None
    ultimo_error = None
    for intento in range(1, max_intentos + 1):
        try:
            conn = get_db()
            break
        except psycopg2.OperationalError as e:
            ultimo_error = e
            print(f"[TicketIA] Esperando a PostgreSQL... intento {intento}/{max_intentos}")
            time.sleep(espera_segundos)

    if conn is None:
        raise RuntimeError(
            f"No fue posible conectar a PostgreSQL después de {max_intentos} intentos. "
            f"Último error: {ultimo_error}"
        )

    with conn:
        with conn.cursor() as cur:
            cur.execute(SCHEMA)

        with conn.cursor() as cur:
            cur.executemany("INSERT INTO roles (codigo, nombre) VALUES (%s, %s) ON CONFLICT (codigo) DO NOTHING", ROLES_INICIALES)
            cur.executemany("INSERT INTO estados (codigo, nombre, orden) VALUES (%s, %s, %s) ON CONFLICT (codigo) DO NOTHING", ESTADOS_INICIALES)
            cur.executemany("INSERT INTO prioridades (codigo, nombre, orden) VALUES (%s, %s, %s) ON CONFLICT (codigo) DO NOTHING", PRIORIDADES_INICIALES)

        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS n FROM categorias")
            if cur.fetchone()["n"] == 0:
                cur.executemany(
                    "INSERT INTO categorias (nombre) VALUES (%s)",
                    [(c,) for c in CATEGORIAS_INICIALES],
                )

        if seed_demo_data:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) AS n FROM usuarios")
                if cur.fetchone()["n"] == 0:
                    ahora = now_ts()
                    usuarios_demo = [
                        ("Jade Vásquez", "jade.admin@municipalidad.cl", "admin123", "administrador", "Departamento de Informática"),
                        ("Kiara Isuiza", "kiara.tecnico@municipalidad.cl", "tecnico123", "tecnico", "Departamento de Informática"),
                        ("Marcela Soto", "marcela.tecnico@municipalidad.cl", "tecnico123", "tecnico", "Departamento de Informática"),
                        ("Pedro Fuentes", "pedro.funcionario@municipalidad.cl", "usuario123", "usuario", "DIDECO"),
                        ("Ana Rojas", "ana.funcionaria@municipalidad.cl", "usuario123", "usuario", "Dirección de Obras"),
                    ]
                    for nombre, email, pw, rol, direccion in usuarios_demo:
                        cur.execute(
                            "INSERT INTO usuarios (nombre, email, password_hash, rol_id, direccion_id, creado_en) "
                            "VALUES (%s, %s, %s, (SELECT id FROM roles WHERE codigo = %s), %s, %s)",
                            (nombre, email, generate_password_hash(pw), rol, direccion_id(conn, direccion), ahora),
                        )
    conn.close()


def query_one(conn, sql, params=None):
    """Ejecuta una consulta y devuelve una sola fila (o None)."""
    with conn.cursor() as cur:
        cur.execute(sql, params or ())
        return cur.fetchone()


def query_all(conn, sql, params=None):
    """Ejecuta una consulta y devuelve todas las filas (lista)."""
    with conn.cursor() as cur:
        cur.execute(sql, params or ())
        return cur.fetchall()


def execute(conn, sql, params=None):
    """Ejecuta una sentencia INSERT/UPDATE/DELETE sin devolver filas.
    No hace commit: quien llama decide cuándo confirmar la transacción."""
    with conn.cursor() as cur:
        cur.execute(sql, params or ())


def direccion_id(conn, nombre):
    """Devuelve el id de la dirección (departamento) con ese nombre; la crea si no existe.
    No distingue mayúsculas ni espacios sobrantes, así "DIDECO" y " dideco " son la misma dirección.
    Devuelve None si el nombre está vacío."""
    nombre = " ".join((nombre or "").split())
    if not nombre:
        return None
    with conn.cursor() as cur:
        cur.execute("SELECT id FROM direcciones WHERE lower(nombre) = lower(%s)", (nombre,))
        fila = cur.fetchone()
        if fila:
            return fila["id"]
        cur.execute("INSERT INTO direcciones (nombre) VALUES (%s) ON CONFLICT ((lower(nombre))) DO NOTHING RETURNING id", (nombre,))
        fila = cur.fetchone()
        if fila is None:                       # otra solicitud la creó justo antes
            cur.execute("SELECT id FROM direcciones WHERE lower(nombre) = lower(%s)", (nombre,))
            fila = cur.fetchone()
        return fila["id"]


def execute_returning_id(conn, sql, params=None):
    """Ejecuta un INSERT ... RETURNING id y devuelve ese id."""
    with conn.cursor() as cur:
        cur.execute(sql, params or ())
        return cur.fetchone()["id"]


def reset_db():
    """Elimina todas las tablas (solo para pruebas/desarrollo). Úsalo con cuidado."""
    conn = get_db()
    with conn:
        with conn.cursor() as cur:
            cur.execute(
                "DROP TABLE IF EXISTS evaluaciones, historial, adjuntos, comentarios, "
                "tickets, usuarios, categorias, roles, estados, prioridades, direcciones CASCADE"
            )
    conn.close()
