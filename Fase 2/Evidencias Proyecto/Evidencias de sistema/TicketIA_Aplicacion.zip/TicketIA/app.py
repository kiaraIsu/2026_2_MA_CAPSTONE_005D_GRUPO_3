"""
TicketIA - Sistema Inteligente de Gestión de Soporte TI
Aplicación principal (Flask + PostgreSQL).

Roles:
    - usuario (funcionario municipal): crea y sigue sus tickets.
    - tecnico: gestiona los tickets asignados.
    - administrador: gestiona usuarios, asigna técnicos y ve el dashboard.

Configuración de base de datos: variables de entorno DB_HOST, DB_PORT,
DB_NAME, DB_USER, DB_PASSWORD (ver .env.example).

Ejecutar:
    pip install -r requirements.txt
    python app.py
    Abrir http://127.0.0.1:5000
"""

import os
from datetime import datetime, timezone
from functools import wraps

from dotenv import load_dotenv

load_dotenv()  # carga variables desde .env si existe (antes de importar database)

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, abort, send_from_directory, g
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from markupsafe import Markup
import secrets
import time
import psycopg2

import database as db
from ai_classifier import clasificar_ticket

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "pdf", "docx", "xlsx", "txt", "zip"}
MAX_FILE_BYTES = 10 * 1024 * 1024          # máximo por archivo adjunto: 10 MB (HU-04)
MAX_CONTENT_LENGTH = 25 * 1024 * 1024      # tope total de una solicitud (varios adjuntos)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "clave-secreta-desarrollo-cambiar-en-produccion")
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
# Seguridad de la sesión: la cookie no es legible por JavaScript y no se envía en solicitudes de otros sitios.
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "0") == "1",   # activar con HTTPS
    CSRF_ACTIVO=True,
    # Las cuentas de demostración (con sus contraseñas) solo se muestran en el login si se pide expresamente.
    MOSTRAR_CUENTAS_DEMO=os.environ.get("MOSTRAR_CUENTAS_DEMO", "0") == "1",
)
CLAVE_POR_DEFECTO = "clave-secreta-desarrollo-cambiar-en-produccion"
if app.config["SECRET_KEY"] == CLAVE_POR_DEFECTO:
    print("AVISO DE SEGURIDAD: se usa la SECRET_KEY de desarrollo; define la variable SECRET_KEY antes de publicar el sistema.")

# Bloqueo temporal tras varios intentos fallidos de inicio de sesión (por correo; en memoria de cada proceso)
INTENTOS_MAXIMOS = 5
VENTANA_INTENTOS_SEG = 600
_intentos_fallidos = {}

ESTADOS_LABEL = {
    "pendiente": "Pendiente",
    "en_progreso": "En progreso",
    "en_revision": "En revisión",
    "resuelto": "Resuelto",
    "cerrado": "Cerrado",
}
PRIORIDAD_LABEL = {"baja": "Baja", "media": "Media", "alta": "Alta"}

# HU-09: flujo de atención. Un ticket solo puede pasar a los estados indicados para su estado actual.
# (La reapertura de un ticket resuelto la solicita el funcionario con su propio flujo, HU-20.)
TRANSICIONES_PERMITIDAS = {
    "pendiente": {"en_progreso"},
    "en_progreso": {"en_revision", "resuelto"},
    "en_revision": {"en_progreso", "resuelto"},
    "resuelto": {"en_progreso", "cerrado"},
    "cerrado": set(),
}


# --------------------------------------------------------------------------
# Utilidades y decoradores de autenticación / autorización
# --------------------------------------------------------------------------

def now_ts():
    return datetime.now(timezone.utc)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Debes iniciar sesión para continuar.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles_permitidos):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                flash("Debes iniciar sesión para continuar.", "warning")
                return redirect(url_for("login"))
            if session.get("rol") not in roles_permitidos:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def current_user():
    if "user_id" not in session:
        return None
    conn = db.get_db()
    try:
        return db.query_one(conn, "SELECT * FROM v_usuarios WHERE id = %s", (session["user_id"],))
    finally:
        conn.close()


def registrar_historial(conn, ticket_id, usuario_id, accion):
    db.execute(
        conn,
        "INSERT INTO historial (ticket_id, usuario_id, accion, creado_en) VALUES (%s, %s, %s, %s)",
        (ticket_id, usuario_id, accion, now_ts()),
    )


@app.context_processor
def inject_globals():
    return {
        "estados_label": ESTADOS_LABEL,
        "prioridad_label": PRIORIDAD_LABEL,
        "transiciones": TRANSICIONES_PERMITIDAS,
        "current_user": current_user(),
    }


@app.before_request
def sincronizar_sesion():
    """Mantiene la sesión alineada con la base de datos en cada solicitud.

    - Si la cuenta fue deshabilitada o eliminada, la sesión se cierra de inmediato.
    - Si el administrador cambió el rol del usuario, el nuevo rol rige desde la
      siguiente solicitud (HU-03, CA2 y CA3).
    """
    if "user_id" not in session or request.endpoint in (None, "static"):
        return None
    conn = db.get_db()
    try:
        user = db.query_one(
            conn, "SELECT id, nombre, rol, activo FROM v_usuarios WHERE id = %s", (session["user_id"],)
        )
    finally:
        conn.close()
    if user is None or not user["activo"]:
        session.clear()
        flash("Tu sesión ya no es válida. Inicia sesión nuevamente.", "warning")
        return redirect(url_for("login"))
    session["rol"] = user["rol"]
    session["nombre"] = user["nombre"]
    return None


@app.errorhandler(413)
def solicitud_demasiado_grande(error):
    """Muestra un mensaje claro cuando el envío completo supera el tope permitido."""
    flash("El envío supera el tamaño máximo permitido: cada archivo puede pesar hasta 10 MB "
          "y el total de la solicitud hasta 25 MB.", "danger")
    return redirect(url_for("nuevo_ticket"))


def _token_csrf():
    """Token CSRF de la sesión actual (se crea la primera vez que se necesita)."""
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


@app.context_processor
def inyectar_csrf():
    def lista_direcciones():
        conn = db.get_db()
        try:
            return [f["nombre"] for f in db.query_all(conn, "SELECT nombre FROM direcciones ORDER BY nombre")]
        finally:
            conn.close()

    return {"csrf_input": lambda: Markup(f'<input type="hidden" name="csrf_token" value="{_token_csrf()}">'),
            "lista_direcciones": lista_direcciones,
            "csp_nonce": getattr(g, "csp_nonce", ""),
            "mostrar_cuentas_demo": app.config.get("MOSTRAR_CUENTAS_DEMO", False)}


@app.before_request
def crear_nonce_csp():
    """Valor único por solicitud: solo los scripts en línea que lo traen se ejecutan (política de contenido)."""
    g.csp_nonce = secrets.token_urlsafe(16)


@app.before_request
def rechazar_caracteres_nulos():
    """Un dato con un carácter nulo (%00) no es válido: se rechaza con un error claro en lugar de fallar al guardarlo."""
    for fuente in (request.args, request.form):
        for clave, valor in fuente.items(multi=True):
            if "\x00" in clave or "\x00" in valor:
                abort(400)
    return None


@app.before_request
def proteger_contra_csrf():
    """Rechaza los envíos (POST) que no traen el token CSRF de la sesión (protección contra solicitudes falsificadas)."""
    if not app.config.get("CSRF_ACTIVO", True) or request.method in ("GET", "HEAD", "OPTIONS"):
        return None
    enviado = request.form.get("csrf_token") or request.headers.get("X-CSRFToken", "")
    esperado = session.get("csrf_token", "")
    # se comparan bytes: compare_digest falla con texto que tenga caracteres no ASCII
    if not esperado or not secrets.compare_digest(str(enviado).encode("utf-8"), esperado.encode("utf-8")):
        abort(400)
    return None


@app.after_request
def cabeceras_de_seguridad(respuesta):
    respuesta.headers["X-Content-Type-Options"] = "nosniff"
    respuesta.headers["X-Frame-Options"] = "DENY"
    respuesta.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    respuesta.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    respuesta.headers["Content-Security-Policy"] = (
        f"default-src 'self'; script-src 'self' 'nonce-{getattr(g, 'csp_nonce', '')}'; object-src 'none'; "
        "style-src 'self' 'unsafe-inline'; font-src 'self'; "
        "img-src 'self' data:; frame-ancestors 'none'; form-action 'self'; base-uri 'self'")
    if request.endpoint != "static":
        respuesta.headers["Cache-Control"] = "no-store"
    return respuesta


@app.template_filter("fmt_dt")
def fmt_dt(value, fmt="%Y-%m-%d %H:%M"):
    """Formatea un datetime (o None) para mostrarlo en las plantillas."""
    if value is None:
        return ""
    return value.strftime(fmt)


@app.template_filter("fmt_date")
def fmt_date(value):
    return fmt_dt(value, "%Y-%m-%d")


# --------------------------------------------------------------------------
# Autenticación
# --------------------------------------------------------------------------

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        ahora = time.time()
        recientes = [t for t in _intentos_fallidos.get(email, []) if ahora - t < VENTANA_INTENTOS_SEG]
        _intentos_fallidos[email] = recientes
        if len(recientes) >= INTENTOS_MAXIMOS:
            flash("Demasiados intentos fallidos. Espera unos minutos antes de intentarlo nuevamente.", "danger")
            return render_template("login.html"), 429

        conn = db.get_db()
        try:
            user = db.query_one(conn, "SELECT * FROM v_usuarios WHERE email = %s", (email,))
        finally:
            conn.close()

        if user is None or not check_password_hash(user["password_hash"], password):
            _intentos_fallidos[email].append(ahora)
            flash("Correo o contraseña incorrectos.", "danger")
            return render_template("login.html")

        if not user["activo"]:
            flash("Esta cuenta se encuentra deshabilitada. Contacta al administrador.", "danger")
            return render_template("login.html")

        _intentos_fallidos.pop(email, None)
        session["user_id"] = user["id"]
        session["nombre"] = user["nombre"]
        session["rol"] = user["rol"]
        flash(f"¡Bienvenido/a, {user['nombre']}!", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# Dashboard (redirige según rol)
# --------------------------------------------------------------------------

@app.route("/dashboard")
@login_required
def dashboard():
    rol = session.get("rol")
    conn = db.get_db()
    try:
        if rol == "administrador":
            stats = {
                "total": db.query_one(conn, "SELECT COUNT(*) AS n FROM v_tickets")["n"],
                "pendientes": db.query_one(
                    conn, "SELECT COUNT(*) AS n FROM v_tickets WHERE estado = 'pendiente'"
                )["n"],
                "en_progreso": db.query_one(
                    conn, "SELECT COUNT(*) AS n FROM v_tickets WHERE estado = 'en_progreso'"
                )["n"],
                "en_revision": db.query_one(
                    conn, "SELECT COUNT(*) AS n FROM v_tickets WHERE estado = 'en_revision'"
                )["n"],
                "resueltos": db.query_one(
                    conn, "SELECT COUNT(*) AS n FROM v_tickets WHERE estado = 'resuelto'"
                )["n"],
                "cerrados": db.query_one(
                    conn, "SELECT COUNT(*) AS n FROM v_tickets WHERE estado = 'cerrado'"
                )["n"],
                "alta_prioridad_abiertos": db.query_one(
                    conn,
                    "SELECT COUNT(*) AS n FROM v_tickets WHERE prioridad = 'alta' "
                    "AND estado NOT IN ('resuelto', 'cerrado')"
                )["n"],
            }
            # HU-16 CA3: promedio de las evaluaciones del servicio; sin evaluaciones el panel sigue funcionando.
            evaluaciones = db.query_one(conn, "SELECT COUNT(*) AS n, AVG(puntaje) AS promedio FROM evaluaciones")
            calificacion = {
                "n": evaluaciones["n"],
                "promedio": f"{float(evaluaciones['promedio']):.1f}".replace(".", ",") if evaluaciones["n"] else None,
            }
            por_categoria = db.query_all(
                conn,
                "SELECT c.nombre AS categoria, COUNT(t.id) AS total "
                "FROM categorias c LEFT JOIN v_tickets t ON t.categoria_id = c.id "
                "GROUP BY c.id ORDER BY total DESC"
            )
            por_tecnico = db.query_all(
                conn,
                "SELECT u.nombre AS tecnico, "
                "SUM(CASE WHEN t.estado NOT IN ('resuelto','cerrado') THEN 1 ELSE 0 END) AS abiertos, "
                "SUM(CASE WHEN t.estado IN ('resuelto','cerrado') THEN 1 ELSE 0 END) AS resueltos "
                "FROM v_usuarios u LEFT JOIN v_tickets t ON t.tecnico_id = u.id "
                "WHERE u.rol = 'tecnico' GROUP BY u.id, u.nombre"
            )
            sin_asignar = db.query_all(
                conn,
                "SELECT t.*, c.nombre AS categoria_nombre, u.nombre AS usuario_nombre "
                "FROM v_tickets t JOIN categorias c ON c.id = t.categoria_id "
                "JOIN v_usuarios u ON u.id = t.usuario_id "
                "WHERE t.tecnico_id IS NULL AND t.estado NOT IN ('resuelto','cerrado') "
                "ORDER BY CASE t.prioridad WHEN 'alta' THEN 0 WHEN 'media' THEN 1 ELSE 2 END, t.creado_en"
            )
            return render_template(
                "dashboard_admin.html", stats=stats, por_categoria=por_categoria,
                por_tecnico=por_tecnico, sin_asignar=sin_asignar, calificacion=calificacion
            )

        if rol == "tecnico":
            mis_tickets = db.query_all(
                conn,
                "SELECT t.*, c.nombre AS categoria_nombre, u.nombre AS usuario_nombre "
                "FROM v_tickets t JOIN categorias c ON c.id = t.categoria_id "
                "JOIN v_usuarios u ON u.id = t.usuario_id "
                "WHERE t.tecnico_id = %s "
                "ORDER BY CASE t.prioridad WHEN 'alta' THEN 0 WHEN 'media' THEN 1 ELSE 2 END, t.creado_en",
                (session["user_id"],),
            )
            columnas = {estado: [] for estado in ESTADOS_LABEL}
            for t in mis_tickets:
                columnas[t["estado"]].append(t)
            return render_template("dashboard_tecnico.html", columnas=columnas, sin_tickets=not mis_tickets)

        # rol == usuario (funcionario)
        mis_tickets = db.query_all(
            conn,
            "SELECT t.*, c.nombre AS categoria_nombre, tec.nombre AS tecnico_nombre "
            "FROM v_tickets t JOIN categorias c ON c.id = t.categoria_id "
            "LEFT JOIN v_usuarios tec ON tec.id = t.tecnico_id "
            "WHERE t.usuario_id = %s ORDER BY t.creado_en DESC, t.id DESC",
            (session["user_id"],),
        )
        return render_template("dashboard_usuario.html", tickets=mis_tickets)
    finally:
        conn.close()


# --------------------------------------------------------------------------
# Tickets: creación, listado, detalle
# --------------------------------------------------------------------------

@app.route("/tickets/nuevo", methods=["GET", "POST"])
@login_required
def nuevo_ticket():
    conn = db.get_db()
    try:
        categorias = db.query_all(conn, "SELECT * FROM categorias WHERE activa = TRUE ORDER BY nombre")

        if request.method == "POST":
            titulo = request.form.get("titulo", "").strip()
            descripcion = request.form.get("descripcion", "").strip()
            usar_ia = request.form.get("usar_ia") == "on"
            categoria_id_form = request.form.get("categoria_id")
            prioridad_form = request.form.get("prioridad")

            errores = []
            if not titulo:
                errores.append("El título es obligatorio.")
            if not descripcion:
                errores.append("La descripción es obligatoria.")

            # Adjuntos: se validan ANTES de crear el ticket (tipo permitido y máximo 10 MB por archivo)
            archivos = [f for f in request.files.getlist("adjuntos") if f and f.filename]
            for f in archivos:
                nombre_mostrado = secure_filename(f.filename) or f.filename
                if not allowed_file(f.filename):
                    errores.append(
                        f"El archivo {nombre_mostrado} no tiene un tipo permitido "
                        f"({', '.join(sorted(ALLOWED_EXTENSIONS))})."
                    )
                    continue
                f.stream.seek(0, os.SEEK_END)
                tamano = f.stream.tell()
                f.stream.seek(0)
                if tamano > MAX_FILE_BYTES:
                    errores.append(f"El archivo {nombre_mostrado} supera el tamaño máximo de 10 MB.")

            if errores:
                for e in errores:
                    flash(e, "danger")
                return render_template("nuevo_ticket.html", categorias=categorias)

            categorias_dict = {c["nombre"]: c["id"] for c in categorias}
            clasificado_por_ia = False
            if (usar_ia or not categoria_id_form) and not categorias_dict:
                flash("No hay categorías activas para clasificar la solicitud. Avisa al administrador.", "danger")
                return render_template("nuevo_ticket.html", categorias=categorias)

            if usar_ia or not categoria_id_form:
                resultado_ia = clasificar_ticket(titulo, descripcion, categorias_dict)
                categoria_id = resultado_ia["categoria_id"]
                prioridad = resultado_ia["prioridad"]
                clasificado_por_ia = True
            else:
                if not categoria_id_form.isdigit() or int(categoria_id_form) not in categorias_dict.values():
                    flash("Selecciona una categoría válida.", "danger")
                    return render_template("nuevo_ticket.html", categorias=categorias)
                categoria_id = int(categoria_id_form)
                prioridad = prioridad_form if prioridad_form in PRIORIDAD_LABEL else "media"

            ahora = now_ts()
            ticket_id = db.execute_returning_id(
                conn,
                "INSERT INTO tickets (titulo, descripcion, categoria_id, prioridad_id, estado_id, "
                "usuario_id, tecnico_id, clasificado_por_ia, creado_en, actualizado_en) "
                "VALUES (%s, %s, %s, (SELECT id FROM prioridades WHERE codigo = %s), "
                "(SELECT id FROM estados WHERE codigo = 'pendiente'), %s, NULL, %s, %s, %s) RETURNING id",
                (titulo, descripcion, categoria_id, prioridad, session["user_id"],
                 clasificado_por_ia, ahora, ahora),
            )

            # Adjuntos (opcional, puede haber varios)
            os.makedirs(UPLOAD_DIR, exist_ok=True)
            for f in archivos:
                if f and f.filename and allowed_file(f.filename):
                    nombre_seguro = secure_filename(f.filename)
                    nombre_final = f"{ticket_id}_{secrets.token_hex(16)}_{nombre_seguro}"
                    ruta = os.path.join(UPLOAD_DIR, nombre_final)
                    f.save(ruta)
                    db.execute(
                        conn,
                        "INSERT INTO adjuntos (ticket_id, nombre_archivo, ruta, creado_en) "
                        "VALUES (%s, %s, %s, %s)",
                        (ticket_id, nombre_seguro, nombre_final, ahora),
                    )

            registrar_historial(conn, ticket_id, session["user_id"], "Ticket creado")
            nombre_categoria = next((n for n, i in categorias_dict.items() if i == categoria_id), "")
            if clasificado_por_ia:
                registrar_historial(
                    conn, ticket_id, session["user_id"],
                    f"Clasificado automáticamente por IA (categoría '{nombre_categoria}', prioridad '{PRIORIDAD_LABEL[prioridad]}')"
                )
            conn.commit()

            flash("Ticket creado correctamente.", "success")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        return render_template("nuevo_ticket.html", categorias=categorias)
    finally:
        conn.close()


@app.route("/tickets")
@login_required
def listar_tickets():
    conn = db.get_db()
    try:
        rol = session["rol"]

        filtro_estado = request.args.get("estado", "")
        filtro_prioridad = request.args.get("prioridad", "")

        query = (
            "SELECT t.*, c.nombre AS categoria_nombre, u.nombre AS usuario_nombre, "
            "tec.nombre AS tecnico_nombre "
            "FROM v_tickets t "
            "JOIN categorias c ON c.id = t.categoria_id "
            "JOIN v_usuarios u ON u.id = t.usuario_id "
            "LEFT JOIN v_usuarios tec ON tec.id = t.tecnico_id WHERE 1=1"
        )
        params = []

        if rol == "usuario":
            query += " AND t.usuario_id = %s"
            params.append(session["user_id"])
        elif rol == "tecnico":
            query += " AND t.tecnico_id = %s"
            params.append(session["user_id"])
        # administrador ve todos

        if filtro_estado:
            query += " AND t.estado = %s"
            params.append(filtro_estado)
        if filtro_prioridad:
            query += " AND t.prioridad = %s"
            params.append(filtro_prioridad)

        query += " ORDER BY t.creado_en DESC, t.id DESC"
        tickets = db.query_all(conn, query, params)

        return render_template(
            "listar_tickets.html", tickets=tickets,
            filtro_estado=filtro_estado, filtro_prioridad=filtro_prioridad
        )
    finally:
        conn.close()


@app.route("/tickets/<int:ticket_id>")
@login_required
def ver_ticket(ticket_id):
    conn = db.get_db()
    try:
        ticket = db.query_one(
            conn,
            "SELECT t.*, c.nombre AS categoria_nombre, u.nombre AS usuario_nombre, "
            "u.direccion AS usuario_direccion, tec.nombre AS tecnico_nombre "
            "FROM v_tickets t "
            "JOIN categorias c ON c.id = t.categoria_id "
            "JOIN v_usuarios u ON u.id = t.usuario_id "
            "LEFT JOIN v_usuarios tec ON tec.id = t.tecnico_id "
            "WHERE t.id = %s",
            (ticket_id,),
        )

        if ticket is None:
            abort(404)

        rol = session["rol"]
        if rol == "usuario" and ticket["usuario_id"] != session["user_id"]:
            abort(403)
        if rol == "tecnico" and ticket["tecnico_id"] != session["user_id"]:
            abort(403)

        comentarios = db.query_all(
            conn,
            "SELECT co.*, u.nombre AS autor_nombre, u.rol AS autor_rol "
            "FROM comentarios co JOIN v_usuarios u ON u.id = co.usuario_id "
            "WHERE co.ticket_id = %s ORDER BY co.creado_en ASC",
            (ticket_id,),
        )

        historial = db.query_all(
            conn,
            "SELECT h.*, u.nombre AS usuario_nombre "
            "FROM historial h JOIN v_usuarios u ON u.id = h.usuario_id "
            "WHERE h.ticket_id = %s ORDER BY h.creado_en ASC, h.id ASC",
            (ticket_id,),
        )

        adjuntos = db.query_all(
            conn, "SELECT * FROM adjuntos WHERE ticket_id = %s ORDER BY creado_en ASC", (ticket_id,)
        )

        tecnicos = []
        if rol == "administrador":
            tecnicos = db.query_all(
                conn, "SELECT * FROM v_usuarios WHERE rol = 'tecnico' AND activo = TRUE ORDER BY nombre"
            )

        evaluacion = db.query_one(
            conn, "SELECT * FROM evaluaciones WHERE ticket_id = %s", (ticket_id,)
        )

        # HU-14: categorías que puede elegir quien corrige la clasificación (las activas y la actual)
        categorias = []
        if session["rol"] in ("tecnico", "administrador"):
            categorias = db.query_all(
                conn, "SELECT id, nombre FROM categorias WHERE activa OR id = %s ORDER BY nombre", (ticket["categoria_id"],)
            )

        # HU-19: autor y fecha del último registro o actualización de la solución
        solucion_info = db.query_one(
            conn,
            "SELECT h.accion, h.creado_en, u.nombre AS usuario_nombre "
            "FROM historial h JOIN v_usuarios u ON u.id = h.usuario_id "
            "WHERE h.ticket_id = %s AND (h.accion LIKE 'Registró la solución%%' OR h.accion LIKE 'Actualizó la solución%%') "
            "ORDER BY h.id DESC LIMIT 1",
            (ticket_id,),
        )

        return render_template(
            "ticket_detalle.html", ticket=ticket, comentarios=comentarios,
            historial=historial, adjuntos=adjuntos, tecnicos=tecnicos, categorias=categorias,
            evaluacion=evaluacion, solucion_info=solucion_info
        )
    finally:
        conn.close()


@app.route("/tickets/<int:ticket_id>/comentar", methods=["POST"])
@login_required
def comentar_ticket(ticket_id):
    contenido = request.form.get("contenido", "").strip()
    if not contenido:
        flash("El comentario no puede estar vacío.", "danger")
        return redirect(url_for("ver_ticket", ticket_id=ticket_id))

    conn = db.get_db()
    try:
        ticket = db.query_one(conn, "SELECT * FROM v_tickets WHERE id = %s", (ticket_id,))
        if ticket is None:
            abort(404)

        rol = session["rol"]
        if rol == "usuario" and ticket["usuario_id"] != session["user_id"]:
            abort(403)
        if rol == "tecnico" and ticket["tecnico_id"] != session["user_id"]:
            abort(403)

        db.execute(
            conn,
            "INSERT INTO comentarios (ticket_id, usuario_id, contenido, creado_en) VALUES (%s, %s, %s, %s)",
            (ticket_id, session["user_id"], contenido, now_ts()),
        )
        registrar_historial(conn, ticket_id, session["user_id"], "Agregó un comentario")
        conn.commit()
    finally:
        conn.close()

    flash("Comentario agregado.", "success")
    return redirect(url_for("ver_ticket", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/asignar", methods=["POST"])
@roles_required("administrador")
def asignar_tecnico(ticket_id):
    """HU-08: el administrador asigna o reasigna un técnico ACTIVO; el historial anterior se conserva."""
    tecnico_id = request.form.get("tecnico_id", "")
    if not tecnico_id.isdigit():
        flash("Selecciona un técnico.", "danger")
        return redirect(url_for("ver_ticket", ticket_id=ticket_id))

    conn = db.get_db()
    try:
        ticket = db.query_one(
            conn,
            "SELECT t.id, t.tecnico_id, t.estado, tec.nombre AS tecnico_actual FROM v_tickets t "
            "LEFT JOIN v_usuarios tec ON tec.id = t.tecnico_id WHERE t.id = %s",
            (ticket_id,),
        )
        if ticket is None:
            abort(404)
        tecnico = db.query_one(
            conn, "SELECT * FROM v_usuarios WHERE id = %s AND rol = 'tecnico'", (tecnico_id,)
        )
        if tecnico is None:
            abort(404)
        if not tecnico["activo"]:
            flash(f"{tecnico['nombre']} está deshabilitado: elige un técnico activo.", "danger")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        db.execute(
            conn,
            "UPDATE tickets SET tecnico_id = %s, estado_id = CASE "
            "WHEN estado_id = (SELECT id FROM estados WHERE codigo = 'pendiente') "
            "THEN (SELECT id FROM estados WHERE codigo = 'en_progreso') ELSE estado_id END, "
            "actualizado_en = %s WHERE id = %s",
            (tecnico_id, now_ts(), ticket_id),
        )
        accion = f"Asignó el ticket al técnico {tecnico['nombre']}"
        if ticket["tecnico_actual"]:
            accion += f" (reasignado desde {ticket['tecnico_actual']})"
        registrar_historial(conn, ticket_id, session["user_id"], accion)
        if ticket["estado"] == "pendiente":
            registrar_historial(
                conn, ticket_id, session["user_id"],
                f"Cambió el estado de '{ESTADOS_LABEL['pendiente']}' a '{ESTADOS_LABEL['en_progreso']}' al asignar un técnico"
            )
        conn.commit()
    finally:
        conn.close()

    flash(f"Ticket asignado a {tecnico['nombre']}.", "success")
    return redirect(url_for("ver_ticket", ticket_id=ticket_id))


def _guardar_solucion(conn, ticket, texto):
    """Guarda la solución del ticket y deja constancia (autor y fecha) en el historial (HU-19)."""
    existia = bool((ticket["solucion"] or "").strip())
    db.execute(conn, "UPDATE tickets SET solucion = %s, actualizado_en = %s WHERE id = %s", (texto, now_ts(), ticket["id"]))
    registrar_historial(conn, ticket["id"], session["user_id"],
                        "Actualizó la solución aplicada" if existia else "Registró la solución aplicada")


def _ticket_gestionable(conn, ticket_id):
    """Devuelve el ticket si el usuario (técnico asignado o administrador) puede gestionarlo."""
    ticket = db.query_one(conn, "SELECT * FROM v_tickets WHERE id = %s", (ticket_id,))
    if ticket is None:
        abort(404)
    if session["rol"] == "tecnico" and ticket["tecnico_id"] != session["user_id"]:
        abort(403)
    return ticket


@app.route("/tickets/<int:ticket_id>/estado", methods=["POST"])
@roles_required("tecnico", "administrador")
def cambiar_estado(ticket_id):
    """HU-09: cambia el estado respetando las transiciones permitidas y deja el cambio en el historial."""
    nuevo_estado = request.form.get("estado")
    solucion = request.form.get("solucion", "").strip()
    if nuevo_estado not in ESTADOS_LABEL:
        flash("Estado no válido.", "danger")
        return redirect(url_for("ver_ticket", ticket_id=ticket_id))

    conn = db.get_db()
    try:
        ticket = _ticket_gestionable(conn, ticket_id)
        actual = ticket["estado"]

        if nuevo_estado == actual:
            flash(f"El ticket ya está en estado '{ESTADOS_LABEL[actual]}'. Para modificar la solución usa «Guardar solución».", "warning")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))
        if nuevo_estado not in TRANSICIONES_PERMITIDAS[actual]:
            flash(f"No se permite pasar de '{ESTADOS_LABEL[actual]}' a '{ESTADOS_LABEL[nuevo_estado]}'.", "danger")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        # HU-19: no se puede marcar como "resuelto" sin registrar la solución aplicada
        if nuevo_estado == "resuelto" and not solucion and not (ticket["solucion"] or "").strip():
            flash("Debes registrar la solución aplicada antes de marcar el ticket como resuelto.", "danger")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        if solucion and solucion != (ticket["solucion"] or "").strip():
            _guardar_solucion(conn, ticket, solucion)
        db.execute(
            conn, "UPDATE tickets SET estado_id = (SELECT id FROM estados WHERE codigo = %s), actualizado_en = %s WHERE id = %s",
            (nuevo_estado, now_ts(), ticket_id)
        )
        registrar_historial(
            conn, ticket_id, session["user_id"],
            f"Cambió el estado de '{ESTADOS_LABEL[actual]}' a '{ESTADOS_LABEL[nuevo_estado]}'"
        )
        conn.commit()
    finally:
        conn.close()

    flash("Estado actualizado.", "success")
    return redirect(url_for("ver_ticket", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/solucion", methods=["POST"])
@roles_required("tecnico", "administrador")
def registrar_solucion(ticket_id):
    """HU-19: el técnico asignado (o el administrador) registra o actualiza la solución sin cambiar el estado."""
    texto = request.form.get("solucion", "").strip()
    conn = db.get_db()
    try:
        ticket = _ticket_gestionable(conn, ticket_id)
        if not texto:
            flash("La solución no puede estar vacía.", "danger")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))
        _guardar_solucion(conn, ticket, texto)
        conn.commit()
    finally:
        conn.close()

    flash("Solución guardada.", "success")
    return redirect(url_for("ver_ticket", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/clasificacion", methods=["POST"])
@roles_required("tecnico", "administrador")
def corregir_clasificacion(ticket_id):
    """HU-14: el técnico asignado o el administrador corrige la categoría y la prioridad propuestas por la IA."""
    conn = db.get_db()
    try:
        ticket = _ticket_gestionable(conn, ticket_id)
        try:
            categoria_id = int(request.form.get("categoria_id", ""))
        except ValueError:
            categoria_id = 0
        prioridad = request.form.get("prioridad", "")

        categoria = None
        if 0 < categoria_id < 2 ** 31:
            categoria = db.query_one(conn, "SELECT id, nombre, activa FROM categorias WHERE id = %s", (categoria_id,))
        categoria_valida = categoria is not None and (categoria["activa"] or categoria["id"] == ticket["categoria_id"])
        if not categoria_valida or prioridad not in PRIORIDAD_LABEL:
            flash("Elige una categoría activa y una prioridad válida.", "danger")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        cambia_categoria = categoria["id"] != ticket["categoria_id"]
        cambia_prioridad = prioridad != ticket["prioridad"]
        if not cambia_categoria and not cambia_prioridad:
            flash("La clasificación no tiene cambios.", "info")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        partes = []
        if cambia_categoria:
            anterior = db.query_one(conn, "SELECT nombre FROM categorias WHERE id = %s", (ticket["categoria_id"],))["nombre"]
            partes.append(f"categoría de '{anterior}' a '{categoria['nombre']}'")
        if cambia_prioridad:
            partes.append(f"prioridad de '{PRIORIDAD_LABEL[ticket['prioridad']]}' a '{PRIORIDAD_LABEL[prioridad]}'")

        db.execute(
            conn,
            "UPDATE tickets SET categoria_id = %s, prioridad_id = (SELECT id FROM prioridades WHERE codigo = %s), "
            "clasificado_por_ia = FALSE, actualizado_en = %s WHERE id = %s",
            (categoria["id"], prioridad, now_ts(), ticket_id),
        )
        registrar_historial(conn, ticket_id, session["user_id"], "Corrigió la clasificación: " + "; ".join(partes))
        conn.commit()
    finally:
        conn.close()

    flash("Clasificación corregida.", "success")
    return redirect(url_for("ver_ticket", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/evaluar", methods=["POST"])
@roles_required("usuario")
def evaluar_ticket(ticket_id):
    conn = db.get_db()
    try:
        ticket = db.query_one(conn, "SELECT * FROM v_tickets WHERE id = %s", (ticket_id,))
        if ticket is None:
            abort(404)
        if ticket["usuario_id"] != session["user_id"]:
            abort(403)
        if ticket["estado"] not in ("resuelto", "cerrado"):
            flash("Solo puedes evaluar tickets resueltos o cerrados.", "warning")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        try:
            puntaje = int(request.form.get("puntaje", 0))
        except ValueError:
            puntaje = 0
        comentario = request.form.get("comentario", "").strip()

        if puntaje < 1 or puntaje > 5:
            flash("La calificación debe ser entre 1 y 5.", "danger")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        db.execute(
            conn,
            "INSERT INTO evaluaciones (ticket_id, puntaje, comentario, creado_en) "
            "VALUES (%s, %s, %s, %s) "
            "ON CONFLICT (ticket_id) DO UPDATE SET puntaje = EXCLUDED.puntaje, "
            "comentario = EXCLUDED.comentario, creado_en = EXCLUDED.creado_en",
            (ticket_id, puntaje, comentario, now_ts()),
        )
        registrar_historial(conn, ticket_id, session["user_id"], f"Evaluó la atención con {puntaje}/5")
        conn.commit()
    finally:
        conn.close()

    flash("¡Gracias por tu evaluación!", "success")
    return redirect(url_for("ver_ticket", ticket_id=ticket_id))


@app.route("/tickets/<int:ticket_id>/solicitar-reapertura", methods=["POST"])
@roles_required("usuario")
def solicitar_reapertura(ticket_id):
    """HU-20: el funcionario reabre su ticket resuelto indicando el motivo; vuelve a En progreso y conserva su técnico."""
    conn = db.get_db()
    try:
        ticket = db.query_one(conn, "SELECT * FROM v_tickets WHERE id = %s", (ticket_id,))
        if ticket is None:
            abort(404)
        if ticket["usuario_id"] != session["user_id"]:
            abort(403)
        if ticket["estado"] != "resuelto":
            flash("Solo puedes reabrir un ticket que esté en estado Resuelto.", "warning")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        motivo = request.form.get("motivo", "").strip()
        if not motivo:
            flash("Debes indicar el motivo de la reapertura.", "danger")
            return redirect(url_for("ver_ticket", ticket_id=ticket_id))

        db.execute(
            conn,
            "UPDATE tickets SET estado_id = (SELECT id FROM estados WHERE codigo = 'en_progreso'), "
            "reapertura_solicitada = FALSE, actualizado_en = %s WHERE id = %s",
            (now_ts(), ticket_id),
        )
        registrar_historial(conn, ticket_id, session["user_id"], f"Solicitó la reapertura del ticket: {motivo}")
        registrar_historial(
            conn, ticket_id, session["user_id"],
            f"Cambió el estado de '{ESTADOS_LABEL['resuelto']}' a '{ESTADOS_LABEL['en_progreso']}'"
        )
        conn.commit()
    finally:
        conn.close()

    flash("El ticket se reabrió y vuelve a estar en progreso.", "success")
    return redirect(url_for("ver_ticket", ticket_id=ticket_id))


def _adjunto_no_disponible():
    return render_template("error.html", codigo=404, mensaje="El archivo solicitado no está disponible o fue eliminado."), 404


@app.route("/adjuntos/<path:filename>")
@login_required
def descargar_adjunto(filename):
    """HU-12: solo puede descargar el adjunto quien puede ver su ticket (solicitante, técnico asignado o administrador)."""
    conn = db.get_db()
    try:
        fila = db.query_one(
            conn,
            "SELECT t.usuario_id, t.tecnico_id FROM adjuntos a JOIN v_tickets t ON t.id = a.ticket_id WHERE a.ruta = %s",
            (filename,),
        )
    finally:
        conn.close()
    if fila is None:
        return _adjunto_no_disponible()
    rol = session["rol"]
    if rol == "usuario" and fila["usuario_id"] != session["user_id"]:
        abort(403)
    if rol == "tecnico" and fila["tecnico_id"] != session["user_id"]:
        abort(403)
    if not os.path.isfile(os.path.join(UPLOAD_DIR, filename)):
        return _adjunto_no_disponible()
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=True)


# --------------------------------------------------------------------------
# Administración de usuarios (solo administrador)
# --------------------------------------------------------------------------

@app.route("/admin/usuarios")
@roles_required("administrador")
def admin_usuarios():
    conn = db.get_db()
    try:
        usuarios = db.query_all(conn, "SELECT * FROM v_usuarios ORDER BY rol, nombre")
        return render_template("admin_usuarios.html", usuarios=usuarios)
    finally:
        conn.close()


@app.route("/admin/usuarios/nuevo", methods=["GET", "POST"])
@roles_required("administrador")
def admin_nuevo_usuario():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        rol = request.form.get("rol")
        direccion = request.form.get("direccion", "").strip()

        errores = []
        if not nombre:
            errores.append("El nombre es obligatorio.")
        if not email or "@" not in email:
            errores.append("Ingresa un correo válido.")
        if len(password) < 6:
            errores.append("La contraseña debe tener al menos 6 caracteres.")
        if rol not in ("usuario", "tecnico", "administrador"):
            errores.append("Rol no válido.")

        conn = db.get_db()
        try:
            existente = db.query_one(conn, "SELECT id FROM v_usuarios WHERE email = %s", (email,))
            if existente:
                errores.append("Ya existe un usuario con ese correo.")

            if errores:
                for e in errores:
                    flash(e, "danger")
                return render_template("admin_nuevo_usuario.html")

            try:
                db.execute(
                    conn,
                    "INSERT INTO usuarios (nombre, email, password_hash, rol_id, direccion_id, creado_en) "
                    "VALUES (%s, %s, %s, (SELECT id FROM roles WHERE codigo = %s), %s, %s)",
                    (nombre, email, generate_password_hash(password), rol, db.direccion_id(conn, direccion), now_ts()),
                )
                conn.commit()
            except psycopg2.IntegrityError:        # otra solicitud creó ese correo justo antes
                conn.rollback()
                flash("Ya existe un usuario con ese correo.", "danger")
                return render_template("admin_nuevo_usuario.html")
        finally:
            conn.close()

        flash("Usuario creado correctamente.", "success")
        return redirect(url_for("admin_usuarios"))

    return render_template("admin_nuevo_usuario.html")


@app.route("/admin/usuarios/<int:usuario_id>/estado", methods=["POST"])
@roles_required("administrador")
def admin_toggle_usuario(usuario_id):
    conn = db.get_db()
    try:
        usuario = db.query_one(conn, "SELECT * FROM v_usuarios WHERE id = %s", (usuario_id,))
        if usuario is None:
            abort(404)
        if usuario_id == session["user_id"]:
            flash("No puedes deshabilitar tu propia cuenta.", "warning")
            return redirect(url_for("admin_usuarios"))

        nuevo_estado = not usuario["activo"]
        db.execute(conn, "UPDATE usuarios SET activo = %s WHERE id = %s", (nuevo_estado, usuario_id))
        conn.commit()
    finally:
        conn.close()

    flash("Estado del usuario actualizado.", "success")
    return redirect(url_for("admin_usuarios"))


@app.route("/admin/usuarios/<int:usuario_id>/rol", methods=["POST"])
@roles_required("administrador")
def admin_cambiar_rol(usuario_id):
    """HU-03 CA3: el administrador modifica el rol de un usuario existente."""
    nuevo_rol = request.form.get("rol")
    if nuevo_rol not in ("usuario", "tecnico", "administrador"):
        flash("Rol no válido.", "danger")
        return redirect(url_for("admin_usuarios"))
    if usuario_id == session["user_id"]:
        flash("No puedes cambiar tu propio rol.", "warning")
        return redirect(url_for("admin_usuarios"))

    conn = db.get_db()
    try:
        usuario = db.query_one(conn, "SELECT * FROM v_usuarios WHERE id = %s", (usuario_id,))
        if usuario is None:
            abort(404)
        db.execute(conn, "UPDATE usuarios SET rol_id = (SELECT id FROM roles WHERE codigo = %s) WHERE id = %s", (nuevo_rol, usuario_id))
        conn.commit()
    finally:
        conn.close()

    flash("Rol del usuario actualizado.", "success")
    return redirect(url_for("admin_usuarios"))


# --------------------------------------------------------------------------
# Administración de categorías de soporte (HU-21)
# --------------------------------------------------------------------------

@app.route("/admin/categorias")
@roles_required("administrador")
def admin_categorias():
    conn = db.get_db()
    try:
        categorias = db.query_all(conn, "SELECT * FROM categorias ORDER BY nombre")
        return render_template("admin_categorias.html", categorias=categorias)
    finally:
        conn.close()


@app.route("/admin/categorias/nueva", methods=["GET", "POST"])
@roles_required("administrador")
def admin_nueva_categoria():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()

        if not nombre:
            flash("El nombre de la categoría es obligatorio.", "danger")
            return render_template("admin_nueva_categoria.html")

        conn = db.get_db()
        try:
            existente = db.query_one(conn, "SELECT id FROM categorias WHERE lower(nombre) = lower(%s)", (nombre,))
            if existente:
                flash("Ya existe una categoría con ese nombre.", "danger")
                return render_template("admin_nueva_categoria.html")

            try:
                db.execute(conn, "INSERT INTO categorias (nombre, activa) VALUES (%s, TRUE)", (nombre,))
                conn.commit()
            except psycopg2.IntegrityError:        # otra solicitud creó esa categoría justo antes
                conn.rollback()
                flash("Ya existe una categoría con ese nombre.", "danger")
                return render_template("admin_nueva_categoria.html")
        finally:
            conn.close()

        flash("Categoría creada correctamente.", "success")
        return redirect(url_for("admin_categorias"))

    return render_template("admin_nueva_categoria.html")


@app.route("/admin/categorias/<int:categoria_id>/estado", methods=["POST"])
@roles_required("administrador")
def admin_toggle_categoria(categoria_id):
    conn = db.get_db()
    try:
        categoria = db.query_one(conn, "SELECT * FROM categorias WHERE id = %s", (categoria_id,))
        if categoria is None:
            abort(404)

        nuevo_estado = not categoria["activa"]
        db.execute(conn, "UPDATE categorias SET activa = %s WHERE id = %s", (nuevo_estado, categoria_id))
        conn.commit()
    finally:
        conn.close()

    flash("Estado de la categoría actualizado.", "success")
    return redirect(url_for("admin_categorias"))


# --------------------------------------------------------------------------
# Manejo de errores
# --------------------------------------------------------------------------

@app.errorhandler(400)
def solicitud_invalida(e):
    return render_template("error.html", codigo=400,
                           mensaje="La solicitud no es válida o expiró. Vuelve a cargar la página e inténtalo de nuevo."), 400


@app.errorhandler(403)
def forbidden(e):
    return render_template("error.html", codigo=403,
                            mensaje="No tienes permiso para acceder a esta página."), 403


@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", codigo=404,
                            mensaje="La página o el recurso solicitado no existe."), 404




# --------------------------------------------------------------------------
# Arranque
# --------------------------------------------------------------------------

if __name__ == "__main__":
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    db.init_db(seed_demo_data=True)
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"      # el modo de depuración debe activarse a propósito
    app.run(debug=debug_mode, host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)))
