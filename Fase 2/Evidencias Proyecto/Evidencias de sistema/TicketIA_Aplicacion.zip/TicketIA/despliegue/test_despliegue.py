"""
Verificaciones del despliegue de TicketIA (servidor de producción, HTTPS y configuración).

Se ejecutan aparte de las pruebas de las historias:   python -m pytest despliegue -v
Usan la base de pruebas (ticketia_test), igual que tests/, y la recrean desde cero.
"""
import importlib
import os
import re
import socket
import subprocess
import sys
import time
import urllib.request

os.environ["DB_NAME"] = os.environ.get("TEST_DB_NAME", "ticketia_test")
for destino, origen in (("DB_HOST", "TEST_DB_HOST"), ("DB_PORT", "TEST_DB_PORT"), ("DB_USER", "TEST_DB_USER"), ("DB_PASSWORD", "TEST_DB_PASSWORD")):
    if os.environ.get(origen):
        os.environ[destino] = os.environ[origen]
os.environ["SESSION_COOKIE_SECURE"] = "1"

import psycopg2
import pytest
import yaml

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)


def _conexion():
    return psycopg2.connect(host=os.environ.get("DB_HOST", "localhost"), port=os.environ.get("DB_PORT", "5432"), dbname=os.environ["DB_NAME"],
                            user=os.environ.get("DB_USER", "ticketia_user"), password=os.environ.get("DB_PASSWORD", "ticketia_pass"))


def _base_vacia():
    conn = _conexion(); conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    conn.close()


def _contar(tabla):
    conn = _conexion()
    with conn.cursor() as cur:
        cur.execute(f"SELECT COUNT(*) FROM {tabla}")
        n = cur.fetchone()[0]
    conn.close()
    return n


def _cargar_wsgi(**variables):
    for k, v in variables.items():
        os.environ[k] = v
    import app as modulo_app
    importlib.reload(modulo_app)
    if "wsgi" in sys.modules:
        del sys.modules["wsgi"]
    return importlib.import_module("wsgi")


# ------------------------------------------------------------------ punto de entrada de producción
def test_wsgi_crea_las_tablas_y_expone_la_aplicacion():
    _base_vacia()
    w = _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="0")
    assert hasattr(w, "app") and w.app.name
    for tabla in ("usuarios", "tickets", "categorias", "historial", "comentarios", "adjuntos"):
        assert _contar(tabla) >= 0


def test_wsgi_carga_las_cuentas_de_demostracion_si_se_pide():
    _base_vacia()
    _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="0")
    assert _contar("usuarios") >= 5


def test_wsgi_no_carga_cuentas_de_demostracion_si_se_desactiva():
    _base_vacia()
    _cargar_wsgi(SEED_DEMO_DATA="0", TRUST_PROXY="0")
    assert _contar("usuarios") == 0


def test_wsgi_se_puede_cargar_dos_veces_sin_duplicar_datos():
    _base_vacia()
    _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="0")
    antes = _contar("usuarios")
    _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="0")
    assert _contar("usuarios") == antes


# ------------------------------------------------------------------ HTTPS detrás de un proxy o túnel
def test_con_proxy_de_confianza_se_leen_las_cabeceras_https():
    from werkzeug.middleware.proxy_fix import ProxyFix
    w = _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="1")
    assert isinstance(w.app.wsgi_app, ProxyFix)


def test_sin_proxy_de_confianza_no_se_leen_las_cabeceras():
    from werkzeug.middleware.proxy_fix import ProxyFix
    w = _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="0")
    assert not isinstance(w.app.wsgi_app, ProxyFix)


def test_la_cookie_de_sesion_es_segura_con_https():
    w = _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="1")
    r = w.app.test_client().get("/login", headers={"X-Forwarded-Proto": "https"}, base_url="https://demo.ejemplo.test")
    cookies = r.headers.getlist("Set-Cookie")
    assert cookies and all("Secure" in c and "HttpOnly" in c and "SameSite=Lax" in c for c in cookies)


def test_la_pantalla_de_acceso_responde_con_las_cuentas_de_demostracion_ocultas():
    w = _cargar_wsgi(SEED_DEMO_DATA="1", TRUST_PROXY="1", MOSTRAR_CUENTAS_DEMO="0")
    html = w.app.test_client().get("/login", base_url="https://demo.ejemplo.test").get_data(as_text=True)
    assert "admin123" not in html and "tecnico123" not in html


# ------------------------------------------------------------------ servidor de producción real (waitress)
def _puerto_libre():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def test_el_servidor_de_produccion_arranca_y_atiende_el_login():
    _base_vacia()
    puerto = _puerto_libre()
    entorno = dict(os.environ, SEED_DEMO_DATA="1", TRUST_PROXY="0", SESSION_COOKIE_SECURE="0", PORT=str(puerto), SECRET_KEY="clave-de-prueba-larga-y-aleatoria-123")
    proc = subprocess.Popen([sys.executable, "-m", "waitress", f"--listen=127.0.0.1:{puerto}", "wsgi:app"], cwd=RAIZ, env=entorno, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        cuerpo, estado = "", None
        for _ in range(40):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{puerto}/login", timeout=2) as r:
                    estado, cuerpo = r.status, r.read().decode("utf-8")
                break
            except Exception:
                time.sleep(0.5)
        assert estado == 200 and "Iniciar sesión" in cuerpo
        assert "Werkzeug" not in cuerpo and "development server" not in cuerpo.lower()
    finally:
        proc.terminate()
        proc.wait(timeout=10)


# ------------------------------------------------------------------ archivos de configuración
def _leer(nombre):
    with open(os.path.join(RAIZ, nombre), encoding="utf-8") as f:
        return f.read()


def test_el_dockerfile_usa_el_servidor_de_produccion_y_no_depende_de_apt():
    d = _leer("Dockerfile")
    assert "waitress-serve" in d and "wsgi:app" in d
    assert not re.search(r"^RUN apt", d, re.M) and "python app.py" not in d


def test_waitress_esta_en_los_requisitos():
    assert re.search(r"^waitress==", _leer("requirements.txt"), re.M)


def test_el_compose_de_produccion_no_expone_la_base_de_datos():
    c = yaml.safe_load(_leer("docker-compose.produccion.yml"))
    assert "ports" not in c["services"]["db"]


def test_el_compose_de_produccion_exige_clave_y_contrasena():
    texto = _leer("docker-compose.produccion.yml")
    assert "${SECRET_KEY:?" in texto and texto.count("${DB_PASSWORD:?") >= 2


def test_el_compose_de_produccion_guarda_los_adjuntos_en_un_volumen_y_asume_https():
    c = yaml.safe_load(_leer("docker-compose.produccion.yml"))
    web = c["services"]["web"]
    assert any(v.endswith(":/app/uploads") for v in web["volumes"])
    assert web["environment"]["TRUST_PROXY"] == "1" and web["environment"]["FLASK_DEBUG"] == "0"


def test_el_compose_de_desarrollo_sigue_igual_para_las_demostraciones_locales():
    c = yaml.safe_load(_leer("docker-compose.yml"))
    assert "5000:5000" in c["services"]["web"]["ports"]


def test_el_generador_de_qr_crea_la_imagen(tmp_path):
    r = subprocess.run([sys.executable, os.path.join(RAIZ, "generar_qr.py"), "https://demo.ejemplo.test"], cwd=tmp_path, capture_output=True, text=True)
    assert r.returncode == 0 and (tmp_path / "qr_ticketia.png").stat().st_size > 500


def test_el_generador_de_qr_rechaza_una_direccion_invalida(tmp_path):
    r = subprocess.run([sys.executable, os.path.join(RAIZ, "generar_qr.py"), "no-es-una-url"], cwd=tmp_path, capture_output=True, text=True)
    assert r.returncode != 0 and not (tmp_path / "qr_ticketia.png").exists()
